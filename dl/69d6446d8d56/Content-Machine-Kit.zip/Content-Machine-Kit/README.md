# Content Machine Kit: the Claude skills that make faceless reels

This is the system behind our account: Claude finds what's winning, writes the script, voices it, builds every scene as code, renders the video and writes the caption. No camera, no editor.

> Honest bit: these are working skills and scripts, not a promise of views or income. You still choose the ideas and approve each video. AI voice and research tools have their own costs (listed below).

## What's inside
| Folder | Agent(s) | What it does |
|---|---|---|
| `skills/content-scout` | Scout · Hook ranker · Demand scanner | Finds outlier posts in your niche (views ÷ the account's normal), ranks winning hooks, finds which topics have demand, and writes idea cards. |
| `skills/video-maker` | Script writer · Voice · Scene builder · Renderer | Turns an idea into a finished 1080×1920 MP4: script → AI voice → word timings → HTML scenes (two looks: Dark Orange and Cobalt Light) → render with music and sound effects. Includes the measured viral playbook (hook types, pace, music level, CTA timing). |
| `skills/captions` | Caption writer | 21 hook formulas, plus the "value caption" rule: steps + data + a specific comment CTA. |
| `CLAUDE.md` | (you) | Tells Claude Code how the agents run together. Just say "make today's video". |

## Setup (about 30 minutes)
1. Install **Claude Code**, **Node 18+**, **Python 3.10+** and **ffmpeg**.
2. `npm i playwright` (with `npx playwright install chromium`), then `pip install faster-whisper numpy`.
3. Copy the `skills/` folders into your Claude Code skills folder (`~/.claude/skills/`) or keep them in this project.
4. Voice: any text-to-speech you like. The skill was built with an ElevenLabs-style voice via Higgsfield (about 0.3 credits per video). Put the MP3 in your project folder.
5. Optional for the scout: an Instagram Business account token (for public competitor data) and an Upload-Post or Apify key for TikTok numbers. Put them in a `.env` file. Never paste keys in chat.
6. Open the folder in Claude Code and say: **"Read CLAUDE.md and set me up."**

## Your daily loop
1. "Scout my niche: <your niche>" → idea cards ranked by proof.
2. "Make a hook preview for idea #1" → check the first 8 seconds.
3. "Finish it" → MP4 + caption + cover.
4. Post it, and log the 48-hour numbers so the skills learn what works for you.

Costs (Nov 2026): Claude plan (your choice), AI voice about £0.10–0.30 per video, everything else free.
