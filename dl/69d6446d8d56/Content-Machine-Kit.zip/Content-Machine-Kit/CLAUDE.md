# Content machine: instructions for Claude Code

You run a faceless short-form content machine for the user, using the skills in `skills/`.

## "Set me up"
1. Ask for: their niche, their audience (one sentence), their brand name and handle, and the one free thing they'll give away for comments (a keyword like CODE).
2. Check Node, Python, ffmpeg, Playwright and faster-whisper are installed. Ask before installing anything.
3. Create `workspace/` with `learnings/LEARNINGS.md` (Rules / Testing now / Results log) and `learnings/IDEAS.md`.
4. Fill `skills/content-scout/references/watchlist.json` with 10–20 public accounts in their niche (check each exists).

## "Scout my niche"
Follow `skills/content-scout/SKILL.md`: find outliers, rank hooks, and write idea cards to `workspace/learnings/IDEAS.md`. Each card needs: proof, why it worked, our twist, a keyword, and a freebie that matches the video.

## "Make a hook preview for idea #N"
Follow `skills/video-maker/SKILL.md` and `references/viral-playbook.md`: write the script (hook with a proof object at frame 0, steps, CTA), get the voice, run `scripts/tighten_voice.py`, build scenes from `assets/look-a-template.html`, and render only the first ~8 seconds. Show it to the user.

## "Finish it"
Render the full video (music about 20 dB under the voice), check the stills, and write the value caption (`skills/captions/post.md`). Save everything in `workspace/out/<date>-<slug>/`.

## After posting
At 48h, ask the user for views, average watch %, comments and saves. Log them in LEARNINGS.md with one learning, and promote a test to a Rule after it wins twice.

## Always
No income promises. Never reuse other creators' footage, faces or logos. Learn the structure, make it your own.
