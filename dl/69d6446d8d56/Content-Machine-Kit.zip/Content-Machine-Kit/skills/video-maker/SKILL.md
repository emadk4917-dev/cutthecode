---
name: "cut-the-code-video"
description: Produce your brand short-form vertical videos (TikTok, Instagram Reels, YouTube Shorts) in the house "UI explainer" style. Clean product-UI motion graphics illustrate every sentence of a natural voiceover, with word-by-word captions, tilted stickers, pixel-dissolve transitions between light and dark scenes, ducked trending music and UI sound effects, ending on a "Comment CODE" CTA. Use this whenever the user wants a new video, reel, short or TikTok for your brand, wants a script turned into a video, wants another video "in the same style", asks to recut or redo a video, or mentions the motion-graphics template, the your AI voice voice, or the video pipeline, even if they don't say "skill".
---

# your brand video

This skill turns a script into a finished 1080×1920 MP4 in the house style. The user approved this style after several rounds of feedback, so treat it as the standard. The bar is "best in the game": every frame should earn attention, and the first two seconds matter most.

Read `references/viral-playbook.md` before writing any script: it holds the hook types, story structure, retention devices and the three formats (Nate-style value reel, Viral Teardown, Faceless motion) learned from the data. Then read `references/style-guide.md` before designing scenes. It holds the exact tokens, motion rules, scene recipes and bugs we've already hit.

## What the user cares about
- **The first 0–2 seconds.** Frame 0 already shows tension: the focal object plus a problem sticker, never an empty fade-in.
- **Fast and clean.** The image changes every 1–1.5s, but the layout stays uncluttered: one focal card per sentence.
- **A human voice.** your AI voice, read naturally. The user disliked forced pauses and over-acted emphasis, so write normal sentences and don't use "..." for drama.
- **Music sits in the background,** about 20 dB under the voice (see viral-playbook §8 and §10). The user found 10 dB under too loud.
- **Honesty.** Never promise the viewer income. "Businesses typically pay £150/month for this" is fine; "you'll make £3k" is not. No other creators' footage or faces.

## Research input (do this first)
Before writing a script, read the latest `./workspace/research/<date>/` files from the content-scout skill: `idea-cards.md` (what to make), `hook_bank.md` (which opening pattern is winning) and `tiktok_demand.md` (which topics have demand). Pick the top idea, use a winning hook pattern for the first 2 seconds, and note in the delivery which idea card and hook pattern the video is testing, so the evening review can learn from it.

## Pipeline

### 1. Script (about 70–95 words, 25–35s)
Pick a format from `references/viral-playbook.md` (value reel, Teardown, or Faceless motion) and a hook type; write 3 hook variants and keep the strongest. Structure: **hook with proof object in frame 0 (0–2s) → promise / "here's how" (by 4s) → 2–4 numbered steps, one sentence each → twist or proof beat → "Comment WORD, and I'll send you …"**. Our reels lose ~60% of viewers in the first second, so the hook gets the most work. One idea per sentence, because each sentence becomes one scene. The CTA keyword must match a lead magnet that actually exists (currently the free "10-Minute Website Prompt Pack" for CODE). Show the script to the user before generating audio if the topic is new.

### 2. Voice (Higgsfield, about 0.3 credits per line)
- Generate the whole script as **one take**, so it flows naturally: `generate_audio` with model `text2speech_v2`, variant `elevenlabs`, `voice_type: preset`, `voice_id: <your preset voice id>` (your AI voice).
- Download the result from Higgsfield's CDN (`d8j0ntlcm91z4.cloudfront.net` must be in the environment's allowed hosts), then run:
  `bash scripts/prep_voice.sh take.mp3 <project_dir>`
  This trims, speeds it up 4%, normalises, and writes `vo.wav` and `words.json` (word-level timings from faster-whisper).
- Fix `words.json` by hand: "clawed" → "Claude", "150" → "£150", and so on.

### 3. Scenes
- Copy `assets/scene-template.html` to `<project_dir>/scene.html` and copy `assets/sfx/` to `<project_dir>/sfx/`.
- The template is a working example (the "website in 10 minutes" video). Keep its engine: `setup()`, `render(t)`, the captions, backgrounds, pixel dissolve, `popIn`, `stick` and `tagIn` helpers, and the SFX list. Rewrite the scene markup and per-scene blocks for the new script.
- In `setup()`, define the `SC` list `[id, start, end, 'L'|'D']`, anchoring each scene start on a spoken word with `at('word', n)`. Pick a scene recipe for each sentence from the style guide.
- Anchor every sticker, row highlight, chip and counter on its word's timestamp. Add matching entries to `SFX` (`[time, 'pop'|'hit'|'whoosh'|'success'|'click'|'ding', volume]`).
- Update the `ACC` accent-word set for the new script.

### 4. Check, then render
- Render check frames first: `node scripts/render.js <project_dir> --stills 0 1 <one time per scene>`. Tile them into a contact sheet and **look at it**. Check frame 0, overlaps, hidden scenes bleeding through, orphan caption words, and anything outside the safe area (y 520–1500 for content).
- Fix, then do the full render:
  `node scripts/render.js <project_dir> --music <track.mp3> --music-start 15 --out <name>.mp4`
- **Music:** the default is TikTok Commercial Music Library "Classic deep house" (Yorm). Preview URL: `https://sf16-ies-music-sg.tiktokcdn.com/obj/tos-alisg-ve-2774/oQeXcgQnjBKspfr8DEv5ICQUtBmvbdPgWZo9rl`, which needs that host allowed. To find this week's trending licensed tracks, use `tiktok_music_trending` (country GB) on the connected account.
- **For TikTok,** also render a version without `--music` and attach the sound in the publish card.

### 5. Deliver
Run the pre-approval checklist in `references/viral-playbook.md` first. Always deliver a full value caption with the video (the steps shown, each with a number, a proof line, then 'Comment WORD and I'll send you <exact thing>'). See the instagram-agent skill's `references/post.md`, under "Owner rule". Never ship a video with a thin or empty caption.
Send the MP4 with a short scene-by-scene summary, the credits used, and posting notes (music volume, which version goes to which platform). Ask what to change, and keep the structure unless the user says otherwise.

## Environment notes
- Needs Playwright and Chromium, ffmpeg, Python with faster-whisper (installed on first use; the model comes from huggingface.co), and Google Fonts reachable.
- If downloads from Higgsfield or TikTok are blocked, the host needs adding to the cloud environment's allowed hosts, and the user may need to approve the download once.
- Instagram links can't be fetched; they need a login. Ask the user to upload reference reels as files. To study a reference, sample frames with ffmpeg (`fps=4` for the first 4s, `fps=1` for the whole video, tiled into contact sheets) and transcribe it with `scripts/transcribe.py` to get its pacing.


## Read the learnings first
Before writing anything, read `your-workspace/learnings/LEARNINGS.md` and follow its Rules. Say which test the piece is part of. After posting, the 48h stats go into its Results log.

## Current production standard (22 Nov 2026; overrides older steps above where they conflict)
1. **Before scripting:** read `your-workspace/learnings/LEARNINGS.md`, `learnings/IDEAS.md`, `FUNNEL-STANDARD.md` and `CALENDAR.md`. Pick the top idea that isn't made yet. Every video must have its keyword funnel built (campaign-launcher skill) before it posts.
2. **Look A "Dark Orange" is the default** (`assets/look-a-template.html` = the "Claude killed editors" build; `assets/look-a-gta6-*-builder.py` = the GTA 6 build, a good pattern for hook + 4 steps + CTA + end card). Look B (cobalt light) is the A/B alternative.
3. **Formats that win, measured:** stakes hook + numbered steps; system **map** (one big canvas, camera flying node to node as each part is named; the @skilltreeos data shows comments 1.6–3.3× likes); teardown; faceless motion. Frame 0 always shows a moving proof object (counter, live stream, map).
4. **Voice:** generate one your AI voice take, then `python scripts/tighten_voice.py take.mp3 <dir> 1.10 -30` (caps pauses, targets ≥3.4 words/sec; your AI voice tops out around 3.4–3.7). Fix words.json (Claude Code / CODE / keyword capitals).
5. **Hook preview first:** render only the first ~8–9 seconds (`words.json` trimmed, `--end-card 0.4`), send it to the owner, and finish the full video only after the hook is approved. While waiting, build the funnel.
6. **Render:** `node render.js <dir> --music bed.mp3 --music-start 0 --music-vol 0.09` (bed = `your-workspace/videos/test-02/bed.mp3`, about 20 dB under the voice). Check stills for overlaps and empty lower halves (content should fill y 560–1400). Also make a <10 MB copy (`-b:v 2600k`) for browser uploads.
7. **Deliver:** a value caption (steps + data + specific CTA), a cover, `scheduled/<date>-<slug>/POST.md`. Schedule TikTok in TikTok Studio on the Mac Chrome ("Browser 2"); type captions in chunks and verify with innerText.
8. **Honesty in visuals:** label mock numbers "illustrative", show rate caveats, never fake discounts or fake comment walls.
