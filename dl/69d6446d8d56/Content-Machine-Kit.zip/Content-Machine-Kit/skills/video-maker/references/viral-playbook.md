# Viral playbook: what the data says (Nov 2026)

Learned from our own analytics, the content-scout winners, 7 reference reels (Nate Herk 1M+, wanted.engineer, getripping and others) and the teardown research. Read this before writing any script. It overrides older habits in SKILL.md where they disagree.

## 1. The numbers we must beat
- **Our reels lose about 60% of viewers in the first second.** Fixing the first frame is worth more than anything else in the edit.
- Winners in our niche are **15–30s**, open on a **bold number or stakes headline with the Claude logo in frame 0**, and end on **one comment word**. Comment-word giveaways pull huge comment counts (TEAMS: 21,783 comments; getripping: more comments than likes). Trend-jacks on a fresh Claude release outperform by about 46×.
- Winner bar for the scout: score 60+, at least 5× the account's normal views or 100k+, and 21 days old or less.

## 2. The 5 hook types that win (pick one, write 3 variants, keep the best)
| Type | Pattern | Example |
|---|---|---|
| Stakes / kill | "Claude just killed [job]." | "Claude just killed video editors." |
| Big number | "[Number] views/£ in [time]." | "This page got 23M views in 14 days." |
| Mystery | "Nobody [expected thing]. [Big result]." | "Nobody filmed this. 1,700 comments." |
| Teardown | "This [reel/page] did [number]. Here's why." | "This 27-second reel did 1M views." |
| Leak / secret | "[Thing] leaked / nobody talks about this." | "Claude's secret content setting." |

Rules: the hook is **spoken and shown at the same time**, 4–8 words, and the frame already contains the proof object (the view counter, the logo, the result). No greeting, no logo intro, no "in this video".

## 3. Story structure (25–35s, about 70–95 words)
1. **0–2s Hook:** stakes or number + proof object on screen.
2. **2–4s Promise:** "Here's how to do it in [time]" / "Here's exactly how." This opens the loop.
3. **4–22s Payoff in numbered steps (2–4):** one sentence each, each with a step sticker (#1, #2…) and a visible result. Nate's format: say the step, show it.
4. **22–27s Twist or proof:** a number, a before/after, a funnel, "and it does X too". This is what makes people comment.
5. **27–32s CTA:** "Comment WORD and I'll send you [the exact thing]." Word said out loud, typed on screen, and repeated as the first line of the caption.

## 4. Keep them on their toes (retention devices)
- **Something changes every 1–1.5s:** cut, punch-in, sticker, counter, card.
- **Progress bar or step strip** (e.g. `01 02 03 04` chips or a "Day 1 → Day 14" scrubber) so viewers know there's an end and wait for it.
- **Open loop:** promise a payoff in the hook and pay it off last ("…and the third one is the reason it got 1M views").
- **Pattern interrupt** at about 40% and 70%: switch light ↔ dark, zoom to full-screen number, or a "$?" reveal card.
- **Specific numbers** everywhere (317k, 13 skills, £150/month). Specifics feel like proof.
- **Comment bait that isn't the CTA:** a slightly debatable line ("most people get this wrong") or a question ("which one surprised you?").

## 5. Formats we can run
### A. Nate-style value reel (talking head or avatar optional)
Stakes hook → "Here's how" → 2–3 numbered steps with real tool names → "Comment WORD". Split screen: proof/B-roll on top 55%, presenter (or a motion card) below. Coloured accent words.

### B. Viral Teardown
"This reel did [X] views…" → "…and it feeds an estimated [£/$] business" → 3 stickers for why it worked (hook, steps, comment word) → animated funnel (Reel → Comment → DM → free group → paid tier) → "Here's how to make it with Claude" → CTA. Show only cropped screenshots of the subject with an @credit, never their full footage. Every money figure says "estimated" and its source.

### C. Faceless motion (getripping style, no camera)
Full motion graphics: dark grid, 3D-extruded bars and cards in the accent colour, mock app UI cards, counters ticking, a step strip or day scrubber, boxed accent word in captions, AI voice. Label mock data "illustrative". This is our default when nobody is filming.

## 6. Design upgrades (apply to every video)
- **Frame 0 = cover:** big number or stakes line + Claude-style orange starburst or our `</>` mark (never Anthropic's actual logo) + the proof object.
- **Captions:** 2–4 words, the single key word boxed or coloured in the accent colour, numbers always accented.
- **One accent colour per series** so the grid is recognisable; reuse the same cover layout every time (Nate: white bg, blue title, face, logos).
- **Step stickers** (#1, #2) on each step; "TEARDOWN" badge in the corner for format B.
- **Sound:** whoosh on every punch-in, ding on number reveals, hit on stickers.

## 7. Pre-approval checklist
- [ ] Hook is one of the 5 types, spoken and shown, proof object in frame 0
- [ ] Promise by 4s
- [ ] Visual change every ≤1.5s, step strip or progress bar visible
- [ ] Specific numbers, honest (no income promises; estimates labelled)
- [ ] Twist/proof beat before the CTA
- [ ] One comment word, said, shown and in the caption's first line; the lead magnet exists
- [ ] 25–35s
- [ ] Cover matches the series template

## 8. Measured targets (from WINNERS-BREAKDOWN.md, 22 Nov 2026)
| Metric | Winners | Our target |
|---|---|---|
| First spoken word | 0.0s | 0.0s |
| Pace | 3.7–4.2 words/sec | ≥3.5: TTS speed-up 1.10 **and** pauses between sentences capped at ~0.2s (cut silences under -30 dB longer than 0.28s) |
| Visual change (motion graphics) | every 0.8–1.5s | ≤1.0s |
| Music under the voice | 16–23 dB | ~20 dB: `--music-vol 0.09` on a -13 LUFS bed, ducked under speech |
| Comment word | last 6%, or mid + end on 40s+ | last 10%, with 4 touches (said, full-screen, typed in a comment box, caption line 1) |

## 9. Two looks, A/B testing phase
We're testing, so alternate looks and let the numbers decide (track 1-second hold, average watch % and comments per 1k views per look):
- **Look A, "Dark Orange" (new default, test-02):** `#0C0C0E` base with a 90px faint grid, film grain and a warm top glow. One accent, Claude orange `#FF7A3D`. Inter 600 captions top-left in sentence case; **one key word per line boxed in orange, set in italic Instrument Serif**. JetBrains Mono for labels and counters. Cards are dark `#151518` with a hairline border. Use: big mono counters, phone rows, case-file "?" cards, a spotlight cone on the reveal, a 4-segment step bar at y≈1430, and a full-screen boxed keyword for the CTA. Reference build: `your-workspace/videos/test-02/scene.html`.
- **Look B, "Cobalt Light" (original):** `style-guide.md` and `assets/scene-template.html`.
- **Mix:** Look B's light scenes can be used as a pattern interrupt inside Look A, or the other way round. After about 8 posts, double down on whichever look gets ≥1.5× the other's 1-second hold.

## 10. Music
The default bed is now a custom ElevenLabs Music track (Higgsfield `elevenlabs_music_v2_5`, instrumental, minimal dark tech-house at 118 BPM, beat from 0s, no melody). Saved as `your-workspace/videos/test-02/bed.mp3`. Start it at 0s (no intro). For TikTok, export a no-music version and add a trending sound in the app at 10–15%.
