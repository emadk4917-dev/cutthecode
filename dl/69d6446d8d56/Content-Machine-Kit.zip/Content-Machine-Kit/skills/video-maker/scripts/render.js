// Render a your brand video project to MP4 (frames + voice + SFX + ducked music).
//
// Usage:
//   node render.js <project_dir> [--fps 30] [--music music.mp3] [--music-start 15] [--end-card 2.2] [--out name.mp4]
//   node render.js <project_dir> --stills 0 2.5 9.9      # render check frames only (still-<t>.png)
//
// <project_dir> must contain:
//   scene.html   - page exposing window.setup(words,total) and window.render(t); setup() should fill window.SFX
//   words.json   - [[start,end,"word"],...] from transcribe.py (fixed up by hand where needed)
//   vo.wav       - the voiceover the words were transcribed from
//   sfx/*.wav    - sound files referenced by window.SFX entries [time, name, volume]
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');

const args = process.argv.slice(2);
const dir = path.resolve(args[0] || '.');
const opt = (k, d) => { const i = args.indexOf(k); return i > -1 ? args[i + 1] : d; };
const fps = +opt('--fps', 30), music = opt('--music', null), musicStart = +opt('--music-start', 15);
const endCard = +opt('--end-card', 2.2), out = opt('--out', 'video.mp4');
const si = args.indexOf('--stills'); const stills = si > -1 ? args.slice(si + 1).map(Number) : [];

const words = JSON.parse(fs.readFileSync(path.join(dir, 'words.json')));
const total = +(words[words.length - 1][1] + 0.35 + endCard).toFixed(2);

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  await p.goto('file://' + path.join(dir, 'scene.html'), { waitUntil: 'networkidle' });
  await p.evaluate(() => document.fonts.ready);
  await p.evaluate(([w, t]) => window.setup(w, t), [words, total]);
  const st = p.locator('#stage');
  if (stills.length) {
    for (const s of stills) { await p.evaluate(t => render(t), s); await st.screenshot({ path: path.join(dir, `still-${s}.png`) }); }
    await b.close(); return;
  }
  const sfx = await p.evaluate(() => window.SFX || []);
  const fd = path.join(dir, 'frames'); fs.rmSync(fd, { recursive: true, force: true }); fs.mkdirSync(fd);
  const n = Math.ceil(total * fps);
  for (let i = 0; i < n; i++) {
    await p.evaluate(t => render(t), i / fps);
    await st.screenshot({ path: path.join(fd, `f${String(i).padStart(5, '0')}.jpg`), type: 'jpeg', quality: 93 });
    if (i % 200 === 0) console.log('frame', i, '/', n);
  }
  await b.close();

  // Audio: voice (100%) + SFX (quiet) + music (~-15dB, ducked under the voice)
  const ins = ['-i vo.wav'], flt = [`[0]aformat=sample_rates=44100:channel_layouts=stereo,apad,atrim=0:${total}[v]`], mix = [];
  sfx.forEach((e, k) => {
    ins.push(`-i sfx/${e[1]}.wav`); const d = Math.max(0, Math.round(e[0] * 1000));
    flt.push(`[${k + 1}]aformat=sample_rates=44100:channel_layouts=stereo,adelay=${d}|${d},volume=${(e[2] * 0.55).toFixed(2)}[s${k}]`); mix.push(`[s${k}]`);
  });
  let inputsCount = 1 + sfx.length;
  if (music) {
    const m = sfx.length + 1; ins.push(`-ss ${musicStart} -t ${total} -i "${path.resolve(music)}"`);
    flt.push(`[v]asplit=2[vv][sc]`);
    flt.push(`[${m}]aformat=sample_rates=44100:channel_layouts=stereo,volume=0.17,afade=t=in:d=0.05,afade=t=out:st=${(total - 1.2).toFixed(2)}:d=1.2[mu]`);
    flt.push(`[mu][sc]sidechaincompress=threshold=0.03:ratio=5:attack=15:release=300[md]`);
    flt.push(`[vv][md]${mix.join('')}amix=inputs=${2 + sfx.length}:normalize=0,alimiter=limit=0.92[a]`);
  } else {
    flt.push(`[v]${mix.join('')}amix=inputs=${inputsCount}:normalize=0,alimiter=limit=0.92[a]`);
  }
  fs.writeFileSync(path.join(dir, 'filter.txt'), flt.join(';'));
  execSync(`cd "${dir}" && ffmpeg -y -v error ${ins.join(' ')} -filter_complex_script filter.txt -map "[a]" -t ${total} mix.wav`);
  execSync(`cd "${dir}" && ffmpeg -y -v error -framerate ${fps} -i frames/f%05d.jpg -i mix.wav -c:v libx264 -pix_fmt yuv420p -crf 17 -preset medium -c:a aac -b:a 192k -shortest -movflags +faststart "${out}"`);
  fs.rmSync(fd, { recursive: true, force: true });
  console.log('done', path.join(dir, out), total + 's');
})();
