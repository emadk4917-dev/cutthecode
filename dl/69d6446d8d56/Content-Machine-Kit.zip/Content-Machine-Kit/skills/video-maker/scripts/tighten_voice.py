"""Speed up a TTS take and cap pauses so the reel hits winner pace (3.5-4.2 words/sec).
Usage: python tighten_voice.py take.mp3 out_dir [tempo=1.10] [threshold_db=-30]
Writes out_dir/vo.wav (44.1k mono, -14 LUFS) and out_dir/words.json (word timings).
"""
import json, subprocess, sys, wave, os
import numpy as np

take, out = sys.argv[1], sys.argv[2]
tempo = float(sys.argv[3]) if len(sys.argv) > 3 else 1.10
th = float(sys.argv[4]) if len(sys.argv) > 4 else -30
here = os.path.dirname(os.path.abspath(__file__))
raw = os.path.join(out, "vo_raw.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", take, "-af",
                f"silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,atempo={tempo},loudnorm=I=-14:TP=-1.5",
                "-ar", "44100", "-ac", "1", raw], check=True)
r = wave.open(raw); sr = r.getframerate(); a = np.frombuffer(r.readframes(r.getnframes()), dtype=np.int16).astype(np.float32); r.close()
hop = int(sr * .01); n = len(a) // hop
db = 20 * np.log10(np.sqrt(np.mean((a[:n * hop] / 32768).reshape(n, hop) ** 2, axis=1)) + 1e-9)
q = db < th; cuts = []; i = 0
while i < n:
    if q[i]:
        j = i
        while j < n and q[j]: j += 1
        if j - i >= 28 and i > 0 and j < n: cuts.append((i + 8, j - 9))
        i = j
    else: i += 1
keep, prev = [], 0
for s, e in cuts: keep.append((prev * hop, s * hop)); prev = e
keep.append((prev * hop, len(a)))
fade = int(.008 * sr); parts = []
for s, e in keep:
    seg = a[s:e].copy(); seg[:fade] *= np.linspace(0, 1, fade); seg[-fade:] *= np.linspace(1, 0, fade); parts.append(seg)
o = np.concatenate(parts).astype(np.int16)
w = wave.open(os.path.join(out, "vo.wav"), "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(o.tobytes()); w.close()
v16 = os.path.join(out, "vo16.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", os.path.join(out, "vo.wav"), "-ac", "1", "-ar", "16000", v16], check=True)
subprocess.run([sys.executable, os.path.join(here, "transcribe.py"), v16, os.path.join(out, "words.json")], check=True)
os.remove(v16); os.remove(raw)
W = json.load(open(os.path.join(out, "words.json")))
print(f"{len(cuts)} pauses capped; {len(o)/sr:.2f}s; {len(W)/W[-1][1]:.2f} words/sec")
print(" ".join(f"[{x[0]}]{x[2]}" for x in W))
