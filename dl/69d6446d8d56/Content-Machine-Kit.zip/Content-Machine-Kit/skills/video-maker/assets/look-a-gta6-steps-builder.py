"""Extend the GTA 6 hook into the full video (steps 1-4, CTA, end card). Run after parts.py."""
s = open('scene.html', encoding='utf-8').read()

CSS = r'''
.tline{position:relative;height:150px;margin:10px 0 0;background:rgba(255,255,255,.04);border-radius:12px;overflow:hidden}
.mk{position:absolute;top:0;bottom:0;width:6px;background:#FF7A3D;border-radius:3px}
.mrow{display:flex;align-items:center;gap:18px;padding:24px 22px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);font-size:29px;font-weight:600}
.mrow .sc{font-family:'JetBrains Mono',monospace;font-weight:800;color:#FF7A3D;width:70px}
.mrow .tm{font-family:'JetBrains Mono',monospace;color:#8C8A92;width:130px;flex:none;font-size:22px}
.srow{display:flex;align-items:center;gap:16px;padding:26px 22px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);font-size:28px;font-weight:600}
.srow .st{margin-left:auto;font-family:'JetBrains Mono',monospace;font-weight:800;font-size:22px;padding:8px 12px;border-radius:10px}
.st.skip{background:rgba(255,77,77,.14);color:#FF6B6B;border:1.5px solid rgba(255,77,77,.5)}
.st.keep{background:rgba(110,231,168,.12);color:#6EE7A8;border:1.5px solid rgba(110,231,168,.5)}
.wide{position:absolute;left:72px;width:936px;height:526px;top:600px;border-radius:22px;overflow:hidden;background:linear-gradient(180deg,#1B0F2E 0%,#5A1E4A 45%,#FF7A3D 78%,#FFB070 100%);border:1px solid rgba(255,255,255,.1)}
.cropbox{position:absolute;top:0;bottom:0;border:5px solid #FF7A3D;box-shadow:0 0 0 2000px rgba(0,0,0,.55);border-radius:10px}
.vphone{position:absolute;width:330px;height:640px;border-radius:40px;background:#050506;border:2px solid #2A2A30;padding:10px;box-sizing:border-box;overflow:hidden}
.vphone .scr{position:relative;width:100%;height:100%;border-radius:30px;overflow:hidden;background:linear-gradient(180deg,#1B0F2E 0%,#5A1E4A 45%,#FF7A3D 78%,#FFB070 100%)}
.vcap{position:absolute;left:14px;right:14px;top:190px;text-align:center;font-weight:900;font-size:30px;line-height:1.1;color:#fff;text-shadow:0 3px 0 #000,0 0 12px rgba(0,0,0,.6)}
.vcap i{font-style:normal;color:#FFD166}
.rule{display:flex;align-items:center;gap:14px;font-size:29px;font-weight:600;padding:26px 20px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06)}
.rule b{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#2A2A30;color:#8C8A92;font-size:22px}
.lrow{display:grid;grid-template-columns:1.6fr 1fr 1fr;gap:10px;padding:26px 22px;border-radius:12px;background:rgba(255,255,255,.035);font-family:'JetBrains Mono',monospace;font-size:23px;font-weight:700}
.inp{display:flex;align-items:center;gap:16px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:16px 18px}
.av{width:58px;height:58px;border-radius:50%;background:#FF7A3D;color:#0C0C0E;display:flex;align-items:center;justify-content:center;font-family:'JetBrains Mono',monospace;font-weight:800;font-size:20px;letter-spacing:-2px;flex:none}
#endc{position:absolute;left:72px;right:72px;top:620px;display:flex;flex-direction:column;gap:34px}
'''

BODY = r'''
  <div class="scene" id="sD">
    <div class="abs" style="left:72px;top:560px"><span class="lbl" style="color:var(--acc)">Step 01 / 04</span><span class="lbl"> · Find the hype</span></div>
    <div class="card abs" id="dCard" style="left:72px;top:610px;width:936px;padding:26px 30px;box-sizing:border-box">
      <div style="display:flex;justify-content:space-between"><span class="lbl">vod_day3.mp4 · 4h 12m · chat.json</span><span class="pill" id="dScan">scanning 0%</span></div>
      <div class="tline" id="tline"><div id="tscan" style="position:absolute;top:0;bottom:0;width:3px;background:#F4F1EA"></div></div>
      <div class="lbl" style="margin:22px 0 12px">Top moments · chat spike + volume + hype words</div>
      <div id="mlist" style="display:flex;flex-direction:column;gap:10px"></div>
    </div>
  </div>

  <div class="scene" id="sE">
    <div class="abs" style="left:72px;top:560px"><span class="lbl" style="color:var(--acc)">Step 02 / 04</span><span class="lbl"> · Already posted?</span></div>
    <div class="card abs" id="eCard" style="left:72px;top:610px;width:936px;padding:26px 30px;box-sizing:border-box">
      <div class="inp" style="margin-bottom:18px"><span style="font-size:30px">🔍</span><div id="eq" style="font-weight:600;font-size:28px;color:#F4F1EA"></div></div>
      <div class="lbl" style="margin-bottom:12px">TikTok + Shorts · last 48h</div>
      <div id="slist" style="display:flex;flex-direction:column;gap:10px"></div>
    </div>
    <div class="sticker" id="eSt" style="left:520px;top:1290px">0 duplicates posted</div>
  </div>

  <div class="scene" id="sF">
    <div class="abs" style="left:72px;top:560px"><span class="lbl" style="color:var(--acc)">Step 03 / 04</span><span class="lbl"> · Cut, caption, follow the rules</span></div>
    <div class="wide" id="fWide"><div class="sun" style="top:160px"></div><div class="cropbox" id="crop" style="left:318px;width:300px"></div></div>
    <div class="vphone" id="fPhone" style="left:72px;top:620px;transform-origin:top left"><div class="scr"><div class="sun" style="top:200px;width:200px;height:200px;margin-left:-100px"></div><div class="vcap" id="vcap"></div></div></div>
    <div class="abs" id="fRules" style="left:420px;top:680px;width:588px;display:flex;flex-direction:column;gap:12px"></div>
  </div>

  <div class="scene" id="sG">
    <div class="abs" style="left:72px;top:560px"><span class="lbl" style="color:var(--acc)">Step 04 / 04</span><span class="lbl"> · Post + track</span></div>
    <div class="card abs" id="gCard" style="left:72px;top:610px;width:936px;padding:26px 30px;box-sizing:border-box">
      <div class="lrow" style="background:none;color:#8C8A92;font-size:18px">CLIP<span>VIEWS</span><span>EST. AT RATE</span></div>
      <div id="llist" style="display:flex;flex-direction:column;gap:10px"></div>
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:22px"><span class="lbl">Total views tracked</span><span class="big" id="gTot" style="font-size:96px;color:var(--acc)">0</span></div>
      <div class="lbl" style="font-size:16px;margin-top:6px">illustrative numbers · paid only on approved views · caps apply</div>
    </div>
  </div>

  <div class="scene" id="sH">
    <div class="abs" id="hBig" style="left:0;right:0;top:600px;text-align:center"><span style="font-family:'Instrument Serif',serif;font-style:italic;font-size:300px;line-height:1;background:var(--acc);color:#0C0C0E;padding:0 40px;border-radius:30px;display:inline-block">CLIP</span></div>
    <div class="card abs" id="hCmt" style="left:72px;top:1000px;width:936px;padding:24px;box-sizing:border-box"><div class="lbl" style="margin-bottom:16px">Add a comment</div><div class="inp"><div class="av">&lt;/&gt;</div><div id="typed" style="flex:1;font-family:'JetBrains Mono',monospace;font-weight:800;font-size:42px;color:var(--acc);letter-spacing:3px"></div><div class="av" style="background:#2A2A30;color:#F4F1EA">➤</div></div></div>
    <div class="card abs" id="hDm" style="left:72px;top:1230px;width:936px;padding:22px 26px;box-sizing:border-box;display:flex;align-items:center;gap:18px"><span class="pill">PDF</span><span style="font-weight:700;font-size:28px">The Claude Clipping Setup</span><span class="lbl" style="margin-left:auto;color:var(--acc)">sent ✓</span></div>
  </div>

  <div class="scene" id="sI">
    <div id="endc">
      <div class="lbl" style="color:var(--acc)">your brand</div>
      <div style="font-weight:700;font-size:84px;line-height:1.05;letter-spacing:-2.5px">Comment <span style="font-family:'Instrument Serif',serif;font-style:italic;font-weight:400;font-size:100px;background:var(--acc);color:#0C0C0E;padding:0 16px;border-radius:12px">CLIP</span><br>for the full setup.</div>
      <div style="font-weight:600;font-size:40px;color:var(--mut);line-height:1.25">Authorised campaigns only. Follow for a new Claude build every day.</div>
      <div class="lbl" style="font-size:26px;color:var(--txt)">@yourbrand</div>
    </div>
  </div>
'''

SETUP = r'''
  const tD=at('step',1),tE=at('step',2),tF=at('step',3),tG=at('step',4),tH=at('comment'),tEnd=W[W.length-1][1]+.4;
  SC=[['sA',0,tB],['sB',tB,tC],['sC',tC,tD],['sD',tD,tE],['sE',tE,tF],['sF',tF,tG],['sG',tG,tH],['sH',tH,tEnd],['sI',tEnd,TOTAL+1]];
  const MK=[[.08,'02:14:07','Heist escape, 3-car pileup',94],[.31,'00:41:52','"He did NOT see that coming"',91],[.55,'03:02:33','Cop chase off the pier',87],[.79,'01:18:20','Chat vs streamer bet',82]];
  $('tline').innerHTML+=Array.from({length:26},(_,i)=>`<div class="mk" id="tk${i}" style="left:${(rnd(i+3)*96+1).toFixed(1)}%;height:${20+rnd(i+40)*60}%;top:auto;bottom:0;opacity:.35;background:#6E6A78"></div>`).join('')+MK.map((m,i)=>`<div class="mk" id="mk${i}" style="left:${m[0]*100}%;opacity:0"></div>`).join('');
  $('mlist').innerHTML=MK.map((m,i)=>`<div class="mrow" id="mr${i}"><span class="sc">${m[3]}</span><span class="tm">${m[1]}</span><span>${m[2]}</span></div>`).join('');
  const SR=[['"heist escape pileup" · @streamer','posted 6×','skip'],['"did NOT see that coming"','posted 0×','keep'],['"cop chase pier"','posted 3×','skip'],['"chat vs streamer bet"','posted 0×','keep']];
  $('slist').innerHTML=SR.map((r,i)=>`<div class="srow" id="sr${i}"><span>${r[0]}</span><span class="lbl" style="margin-left:auto;margin-right:10px">${r[1]}</span><span class="st ${r[2]}">${r[2]==='keep'?'✓ KEEP':'✕ SKIP'}</span></div>`).join('');
  $('fRules').innerHTML=[['9:16 vertical crop','vertical'],['Word-by-word captions','captions'],['Required #tags + link','follows'],['Length 15–45s','rules']].map((r,i)=>`<div class="rule" id="ru${i}"><b id="rb${i}">${i+1}</b><span>${r[0]}</span></div>`).join('');
  $('llist').innerHTML=[['did-not-see.mp4',41200],['chat-bet.mp4',18700],['pier-chase-v2.mp4',9400]].map((r,i)=>`<div class="lrow" id="lr${i}" data-v="${r[1]}"><span>${r[0]}</span><span id="lv${i}">0</span><span id="lp${i}" style="color:#FF7A3D">$0.00</span></div>`).join('');
  window.STEPS=[tD,tE,tF,tG,tH];
'''

SFX2 = r'''
  add(tD-.2,'whoosh',.7);[0,1,2,3].forEach(i=>add(at('finds')+.1+i*.3,'pop',.45));add(at('crazy'),'hit',.7);
  add(tE-.2,'whoosh',.7);[0,1,2,3].forEach(i=>add(at('checks')+.4+i*.3,'click',.5));add(at('already'),'success',.6);
  add(tF-.2,'whoosh',.7);add(at('vertical'),'hit',.7);[0,1,2,3].forEach(i=>add(at('vertical')+.3+i*.45,'success',.35));
  add(tG-.2,'whoosh',.7);[0,1,2].forEach(i=>add(at('posts')+.1+i*.25,'pop',.45));add(at('view'),'ding',.6);
  add(tH-.2,'whoosh',.7);add(tH,'hit',.9);for(let i=0;i<4;i++)add(at('clip',2)+.25+i*.1,'click',.6);add(at('send'),'ding',.5);add(tEnd-.2,'whoosh',.6);add(tEnd,'hit',.6);
'''

RENDER = r'''
  // D find
  {const a=SC[3][1],tf=at('finds'),tcz=at('crazy');popIn($('dCard'),t,a+.04);const k=p(t,a+.2,tcz+.4);$('dScan').textContent=k<1?'scanning '+Math.round(k*100)+'%':'✓ 4 moments';$('tscan').style.left=(k*100)+'%';
   for(let i=0;i<4;i++){const s0=tf+.1+i*.3;const m=$('mk'+i);m.style.opacity=t>=s0?1:0;m.style.height='100%';popIn($('mr'+i),t,s0,{dy:20,s0:.95})}}
  // E check
  {const a=SC[4][1],tc=at('checks');popIn($('eCard'),t,a+.04);const q='heist escape · did not see that coming · …';$('eq').textContent=q.slice(0,Math.floor(p(t,a+.1,tc+.3)*q.length));
   for(let i=0;i<4;i++){const s0=tc+.4+i*.3;popIn($('sr'+i),t,s0,{dy:16,s0:.96});const r=$('sr'+i);r.style.opacity=t<s0?0:(r.querySelector('.skip')&&t>=at('already')?.4:1)}stick($('eSt'),t,at('already')+.1,-4)}
  // F cut
  {const a=SC[5][1],tv=at('vertical');$('fWide').style.opacity=t<tv?1:Math.max(0,1-p(t,tv,tv+.4));$('fWide').style.transform=`scale(${1-.1*p(t,tv,tv+.4)})`;
   $('crop').style.left=(318+60*Math.sin((t-a)*2))+'px';const ph=$('fPhone');if(t<tv){ph.style.opacity=0}else{const k=back(p(t,tv,tv+.4));ph.style.opacity=1;ph.style.transform=`scale(${.7+.3*k})`}
   const words=['HE','DID','NOT','SEE','THAT','COMING'];const tc=at('captions');const n=cl(Math.floor((t-tc)/.12)+1,0,6);$('vcap').innerHTML=words.slice(0,n).map((w,i)=>i===2?`<i>${w}</i>`:w).join(' ');
   const tr=[at('vertical'),at('captions'),at('follows'),at('rules')];for(let i=0;i<4;i++){popIn($('ru'+i),t,tv+.1+i*.12,{dy:20});const ok=t>=tr[i]+.1;const b=$('rb'+i);b.textContent=ok?'✓':String(i+1);b.style.background=ok?'#6EE7A8':'#2A2A30';b.style.color=ok?'#0C0C0E':'#8C8A92'}}
  // G post + track
  {const a=SC[6][1],tp=at('posts'),tv=at('view');popIn($('gCard'),t,a+.04);let tot=0;for(let i=0;i<3;i++){const s0=tp+.1+i*.25;popIn($('lr'+i),t,s0,{dy:16});const v=+$('lr'+i).dataset.v;const k=eo(p(t,s0,tv+.6));const cur=Math.round(v*k);tot+=cur;$('lv'+i).textContent=cur.toLocaleString('en-GB');$('lp'+i).textContent='$'+(cur/1000).toFixed(2)}$('gTot').textContent=tot.toLocaleString('en-GB')}
  // H CTA
  {const a=SC[7][1],tc=at('clip',2);const k=back(p(t,a,a+.35));$('hBig').style.opacity=cl((t-a)/.08);$('hBig').style.transform=`scale(${1.5-.5*k}) rotate(${-3*k}deg)`;
   popIn($('hCmt'),t,tc+.15,{dy:60});const n=cl(Math.floor((t-tc-.25)/.1)+1,0,4);$('typed').innerHTML='CLIP'.slice(0,n)+(Math.floor(t*3)%2?'<span style="display:inline-block;width:4px;height:42px;background:#FF7A3D;vertical-align:-6px"></span>':'');popIn($('hDm'),t,at('send'),{dy:50})}
  // I end
  {popIn($('endc'),t,SC[8][1],{dy:40,s0:.94})}
  // step bar
  {const st=window.STEPS;const s=$('steps');s.style.display='block';s.style.opacity=t>=st[0]&&t<st[4]?1:0;const names=['Find','Check','Cut','Post'];let c=0;for(let i=0;i<4;i++){if(t>=st[i])c=i;$('sb'+i).style.width=(100*eo(p(t,st[i],st[i+1]-.1)))+'%'}$('stT').textContent=names[c];$('stN').textContent=(c+1)+' / 4'}
'''

s = s.replace('</style>', CSS + '</style>', 1)
s = s.replace('  <div id="steps"', BODY + '\n  <div id="steps"', 1)
s = s.replace("  SC=[['sA',0,tB],['sB',tB,tC],['sC',tC,TOTAL+1]];", SETUP, 1)
s = s.replace("  window.SFX=SFX;", SFX2 + "  window.SFX=SFX;", 1)
s = s.replace("const ACC=new Set(['opportunity','how','3','claude','whole']);", "const ACC=new Set(['opportunity','how','3','claude','whole','crazy','already','vertical','rules','every','clip','setup']);")
s = s.replace("  drawCap(t);drawFx(t);\n};", RENDER + "  drawCap(t);drawFx(t);\n};", 1)
# hide captions on end card
s = s.replace("function drawCap(t){const cap=$('cap');if(SC.length>7&&t>=SC[7][1])", "function drawCap(t){const cap=$('cap');if(SC.length>8&&t>=SC[8][1]){cap.innerHTML='';return}if(false)")
open('scene.html', 'w', encoding='utf-8').write(s)
print('ok', len(s), s.count('sI'))
