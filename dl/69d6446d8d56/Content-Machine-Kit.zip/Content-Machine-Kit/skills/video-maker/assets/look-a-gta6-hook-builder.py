"""Assemble the GTA 6 hook scene from the Look A engine in test-02/scene.html."""
src = open('../test-02/scene.html', encoding='utf-8').read()
head = src.split('</style>')[0]
js = src.split('<script>')[1].split('</script>')[0]
helpers = js.split('const ACC')[0]
engine = js[js.index("const bg=$('bg')"):js.index('window.render')]

CSS = r'''
.stream{position:absolute;left:60px;top:560px;width:960px;border-radius:26px;overflow:hidden;background:#0A0A0C;border:1px solid rgba(255,255,255,.1);box-shadow:0 40px 90px rgba(0,0,0,.6)}
.svid{position:relative;height:420px;overflow:hidden;background:linear-gradient(180deg,#1B0F2E 0%,#5A1E4A 45%,#FF7A3D 78%,#FFB070 100%)}
.sun{position:absolute;left:50%;top:205px;width:260px;height:260px;margin-left:-130px;border-radius:50%;background:radial-gradient(circle,#FFD7A0,#FF8A4D 60%,rgba(255,122,61,0) 70%)}
.city{position:absolute;left:0;right:0;bottom:0;height:170px}
.city i{position:absolute;bottom:0;background:#120A1C;display:block}
.palm{position:absolute;bottom:0;width:10px;background:#120A1C}
.palm:after{content:'';position:absolute;top:-34px;left:-40px;width:90px;height:44px;border-radius:50% 50% 0 0;background:#120A1C;transform:rotate(-8deg)}
.live{position:absolute;left:22px;top:20px;display:flex;gap:10px;align-items:center;z-index:3}
.live b{background:#FF2D55;color:#fff;font-weight:900;font-size:22px;padding:6px 12px;border-radius:8px;letter-spacing:1px}
.live span{background:rgba(0,0,0,.55);color:#fff;font-weight:700;font-size:22px;padding:6px 12px;border-radius:8px}
.chat{position:absolute;right:16px;top:16px;bottom:16px;width:330px;background:rgba(0,0,0,.55);border-radius:16px;overflow:hidden;padding:12px 16px;box-sizing:border-box}
.chat p{margin:0 0 9px;font-size:22px;font-weight:600;color:#F4F1EA;white-space:nowrap}
.chat p b{font-weight:800;margin-right:8px}
.sbar{padding:18px 24px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid rgba(255,255,255,.08)}
.graph{height:120px;padding:0 24px 18px}
.hl{position:absolute;font-family:'Instrument Serif',serif;font-style:italic;font-size:46px;color:#F4F1EA;background:#1C1C20;border:1px solid rgba(255,255,255,.14);padding:10px 22px;border-radius:14px;white-space:nowrap;box-shadow:0 20px 40px rgba(0,0,0,.5);z-index:8}
.hl small{font-family:'JetBrains Mono',monospace;font-style:normal;font-size:16px;color:#8C8A92;display:block;letter-spacing:1px}
#how{position:absolute;left:0;right:0;top:960px;text-align:center;z-index:9}
#rate{position:absolute;left:72px;right:72px;top:590px}
.stepchips{display:flex;gap:12px;margin-top:40px}
.stepchips div{flex:1;text-align:center;font-family:'JetBrains Mono',monospace;font-weight:800;font-size:28px;padding:30px 0;border-radius:16px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#8C8A92}
'''

BODY = r'''
<div id="stage">
  <canvas id="bg" width="1080" height="1920"></canvas>

  <div class="scene" id="sA">
    <div class="stream" id="aStream">
      <div class="svid"><div class="sun"></div>
        <div class="city" id="city"></div>
        <div class="live"><b>● LIVE</b><span id="viewers">184,203 watching</span></div>
        <div class="chat" id="chat"></div>
      </div>
      <div class="sbar"><div><div style="font-weight:800;font-size:28px">GTA 6 · day 3 · first heist</div><div class="lbl" style="margin-top:6px">chat messages / 10s</div></div><span class="pill" id="spike">SPIKE ×9</span></div>
      <div class="graph"><svg width="912" height="110" viewBox="0 0 912 110"><path id="gline" d="" fill="none" stroke="#FF7A3D" stroke-width="5" stroke-linejoin="round"/><path id="garea" d="" fill="rgba(255,122,61,.15)"/></svg></div>
    </div>
    <div class="hl" id="h0" style="left:60px;top:1215px"><small>EVERY FEED, THIS WEEK</small>"GTA 6 is a goldmine"</div>
    <div class="hl" id="h1" style="left:430px;top:1305px"><small>TRENDING</small>"Start clipping GTA 6"</div>
    <div class="hl" id="h2" style="left:130px;top:1395px"><small>EVERYONE</small>"Get paid from GTA 6"</div>
  </div>

  <div class="scene" id="sB">
    <div class="hl" id="b0" style="left:60px;top:600px">"GTA 6 is a goldmine"</div>
    <div class="hl" id="b1" style="left:420px;top:700px">"Start clipping GTA 6"</div>
    <div class="hl" id="b2" style="left:120px;top:800px">"Get paid from GTA 6"</div>
    <div id="how"><div class="lbl" style="margin-bottom:22px;color:var(--acc)">Case file · the actual method</div>
      <span style="font-family:'Instrument Serif',serif;font-style:italic;font-size:260px;line-height:1;background:var(--acc);color:#0C0C0E;padding:0 40px;border-radius:30px;display:inline-block" id="howw">how?</span>
      <div class="lbl" style="margin-top:26px">Steps shown: <span id="shown" style="color:var(--txt)">0</span></div></div>
  </div>

  <div class="scene" id="sC">
    <div id="rate">
      <div class="card" id="cCard" style="padding:34px 36px">
        <div style="display:flex;justify-content:space-between"><span class="lbl">Clip campaign · GTA 6</span><span class="pill">PAID PER VIEW</span></div>
        <div style="display:flex;align-items:baseline;gap:18px;margin:24px 0 8px"><span class="big" id="cNum" style="font-size:250px;color:var(--acc)">$0.00</span></div>
        <div style="font-weight:700;font-size:40px">per 1,000 views</div>
        <div class="lbl" style="margin-top:14px;font-size:17px">up to · rates vary by campaign · typical ≈ $1 · caps apply</div>
      </div>
      <div class="term" id="cTerm" style="margin-top:40px"><div class="tb"><i></i><i></i><i></i>&nbsp;claude-code</div><div class="bd" id="ctty" style="min-height:60px"></div></div>
      <div class="stepchips" id="cChips"><div>01 FIND</div><div>02 CHECK</div><div>03 CUT</div><div>04 POST</div></div>
    </div>
  </div>

  <div id="steps" style="display:none"><div class="row"><i><b id="sb0"></b></i><i><b id="sb1"></b></i><i><b id="sb2"></b></i><i><b id="sb3"></b></i></div><div class="t"><span class="lbl" id="stT"></span><span class="lbl" id="stN"></span></div></div>
  <div id="cap"></div>
  <canvas id="fx" width="1080" height="1920"></canvas>
</div>
'''

LOGIC = r'''
const ACC=new Set(['opportunity','how','3','claude','whole']);
function buildGroups(){let g=[];W.forEach((w,i)=>{g.push(i);if(/[.,:?!]$/.test(w[2])||g.length>=8){GROUPS.push(g);g=[]}});if(g.length)GROUPS.push(g);GROUPS=GROUPS.reduce((o,g)=>{if(g.length===1&&o.length&&!/^step$/i.test(norm(W[g[0]][2])))o[o.length-1]=o[o.length-1].concat(g);else o.push(g);return o},[])}
const CHAT=[['kai_','CLIP IT 😭'],['mo.ttv','W W W W'],['jessxo','NO WAY'],['ld_99','LMAOOOO'],['b3n','chat is he serious'],['vxn','CLIP THAT'],['ayo_t','💀💀💀'],['ricky','W HEIST'],['nadz','NAH THAT\'S CRAZY'],['tomo','clip it clip it'],['zee','W'],['pj','HAHAHA'],['luce','OMG'],['k1d','that was insane'],['ash','CLIP 🔥'],['dre','NO SHOT']];
const COL=['#FF7A3D','#7FD1FF','#B48CFF','#FFD166','#6EE7A8'];
window.setup=(words,total)=>{
  W=words;TOTAL=total;buildGroups();
  const tB=at('nobody'),tC=at('clipping');
  SC=[['sA',0,tB],['sB',tB,tC],['sC',tC,TOTAL+1]];
  let city='';for(let i=0;i<22;i++){const w=30+rnd(i)*50,h=40+rnd(i+9)*130;city+=`<i style="left:${i*46}px;width:${w}px;height:${h}px"></i>`}
  city+='<div class="palm" style="left:90px;height:150px"></div><div class="palm" style="left:540px;height:120px"></div>';
  $('city').innerHTML=city;
  const add=(t,f,v=1)=>SFX.push([+t.toFixed(3),f,v]);
  add(0,'hit',.8);add(.05,'pop',.5);[at('everyone'),at('money'),at('opportunity')].forEach((t,i)=>add(t+.05,'pop',.5));
  add(tB-.2,'whoosh',.7);add(at('how'),'hit',1);
  add(tC-.2,'whoosh',.7);add(at('3'),'hit',.9);add(at('3')+.35,'ding',.5);add(at('claude'),'pop',.6);[0,1,2,3].forEach(i=>add(at('whole')+.05+i*.12,'pop',.45));
  window.SFX=SFX;
};
'''

RENDER = r'''
window.render=t=>{
  drawBg(t);
  for(const [id,a,b] of SC){const on=t>=a&&t<b;const el=$(id);el.style.opacity=on?1:0;el.style.visibility=on?'visible':'hidden';if(on){const z=1+.03*p(t,a,b);const k=eo(p(t,a,a+.3));el.style.transform=`scale(${z*(.95+.05*k)})`}}
  // A: live stream, chat flooding, spike graph, headlines piling
  {const s=$('aStream');s.style.opacity=1;s.style.transform=`perspective(1600px) rotateX(${6-6*eo(p(t,0,.6))}deg)`;
   $('viewers').textContent=(184203+Math.floor(t*1731)).toLocaleString('en-GB')+' watching';
   const rate=t<1?6:18;const n=Math.floor(t*rate)+8;let h='';for(let i=Math.max(0,n-16);i<n;i++){const c=CHAT[i%CHAT.length];h+=`<p><b style="color:${COL[i%5]}">${c[0]}</b>${c[1]}</p>`}$('chat').innerHTML=h;
   let d='M0 100';const pts=[];for(let x=0;x<=60;x++){const tt=t-(60-x)*.05;let y=88-10*rnd(x+Math.floor(t*20));if(tt>.7)y-=Math.min(78,(tt-.7)*120)*(.6+.4*rnd(x));pts.push([x*15.2,Math.max(6,y)])}
   d=pts.map((q,i)=>(i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1)).join(' ');$('gline').setAttribute('d',d);$('garea').setAttribute('d',d+' L912 110 L0 110 Z');
   $('spike').textContent='SPIKE ×'+Math.max(1,Math.round(1+8*p(t,.6,2.4)));
   [['h0',0],['h1',at('money')],['h2',at('opportunity')]].forEach(([id,t0],i)=>{const el=$(id);if(t<t0){el.style.opacity=0;return}const k=back(p(t,t0,t0+.35));el.style.opacity=1;el.style.transform=`translateY(${(1-k)*60}px) rotate(${[-3,2,-1.5][i]}deg) scale(${.85+.15*k})`})}
  // B: headlines get struck, giant how?
  {const a=SC[1][1],th=at('how');['b0','b1','b2'].forEach((id,i)=>{const el=$(id);el.style.opacity=t>=a?(t>=th?.25:1):0;el.style.transform=`rotate(${[-3,2,-1.5][i]}deg)`;el.style.textDecoration=t>=a+.25+i*.12?'line-through':'none';el.style.textDecorationColor='#FF7A3D';el.style.textDecorationThickness='4px'});
   const hw=$('how');if(t<th){hw.style.opacity=0}else{const k=back(p(t,th,th+.32));hw.style.opacity=1;hw.style.transform=`scale(${1.7-.7*k}) rotate(${-3*k}deg)`}}
  // C: rate counter, claude terminal, 4 chips
  {const a=SC[2][1],t3=at('3'),tc=at('claude');popIn($('cCard'),t,a+.03,{dy:50});const k=eo(p(t,t3-.15,t3+.45));$('cNum').textContent='$'+(3*k).toFixed(2);
   popIn($('cTerm'),t,tc-.05,{dy:40});const full='> run clipping-agent --game "GTA 6"';const n=Math.floor(p(t,tc,tc+.9)*full.length);$('ctty').innerHTML='<span style="color:#FF7A3D">'+full.slice(0,Math.min(n,1))+'</span>'+full.slice(1,n)+'<span style="display:inline-block;width:14px;height:32px;background:#FF7A3D;vertical-align:-5px;margin-left:2px"></span>';
   const tw=at('whole');[...$('cChips').children].forEach((el,i)=>{popIn(el,t,tw+.05+i*.12,{dy:24,s0:.9});const on=t>=tw+.05+i*.12;el.style.color=on?'#0C0C0E':'#8C8A92';el.style.background=on?'#FF7A3D':'rgba(255,255,255,.05)'})}
  drawCap(t);drawFx(t);
};
'''
out = head + CSS + '</style></head><body>' + BODY + '<script>' + helpers + LOGIC + engine + RENDER + '</script></body></html>'
open('scene.html', 'w', encoding='utf-8').write(out)
print('ok', len(out))
