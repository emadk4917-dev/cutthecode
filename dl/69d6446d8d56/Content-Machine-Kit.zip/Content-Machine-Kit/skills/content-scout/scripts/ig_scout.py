#!/usr/bin/env python3
"""ig_scout.py - find what's winning on Instagram for accounts in our niche.

Uses the official Instagram Graph API "Business Discovery" (public business/creator accounts only;
personal accounts and hashtag search are not available without Meta app review).
The token is injected by the session proxy for graph.facebook.com.

Usage:
  python3 ig_scout.py check  user1 user2 ...          # which handles are readable + follower counts
  python3 ig_scout.py scan   [--watchlist FILE] [--per 25] [--out report.md] [--json out.json]
Outputs a ranked list of OUTLIER posts (engagement far above that account's own median),
plus every "comment WORD" call-to-action found (these are DM lead magnets that work).
"""
import argparse, json, os, re, statistics, sys, urllib.parse, urllib.request, datetime as dt

IG_USER = os.environ.get("IG_USER_ID", "17841480368905533")
BASE = "https://graph.facebook.com/v21.0/"
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_WL = os.path.join(HERE, "..", "references", "watchlist.json")

def bd(username, per):
    fields = (f"business_discovery.username({username}){{username,name,followers_count,media_count,"
              f"media.limit({per}){{caption,like_count,comments_count,permalink,media_type,media_product_type,timestamp}}}}")
    url = BASE + IG_USER + "?" + urllib.parse.urlencode({"fields": fields})
    req = urllib.request.Request(url, headers={"Authorization": "Bearer proxy-injected"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.load(r).get("business_discovery")
    except urllib.error.HTTPError as e:
        return {"error": json.loads(e.read() or b"{}").get("error", {}).get("message", str(e))}

CTA = re.compile(r"""comment\s+["'“”‘’]?([A-Za-z0-9]{2,20})["'“”‘’]?""", re.I)

def scan(handles, per):
    posts, accounts = [], []
    for h in handles:
        d = bd(h, per)
        if not d or "error" in d:
            accounts.append({"username": h, "error": (d or {}).get("error", "not readable")}); continue
        media = (d.get("media") or {}).get("data", [])
        eng = [m.get("like_count", 0) + 3 * m.get("comments_count", 0) for m in media]
        med = statistics.median(eng) if eng else 0
        accounts.append({"username": d["username"], "followers": d.get("followers_count"), "posts_read": len(media), "median_eng": med})
        for m, e in zip(media, eng):
            cap = m.get("caption") or ""
            cta = CTA.findall(cap)
            posts.append({
                "account": d["username"], "followers": d.get("followers_count") or 0,
                "type": m.get("media_product_type") or m.get("media_type"),
                "likes": m.get("like_count", 0), "comments": m.get("comments_count", 0),
                "eng": e, "outlier": round(e / med, 1) if med else 0.0,
                "comment_rate": round(m.get("comments_count", 0) / max(1, d.get("followers_count") or 1) * 1000, 2),
                "cta_words": sorted(set(w.upper() for w in cta)),
                "hook": cap.strip().split("\n")[0][:160], "caption": cap[:600],
                "permalink": m.get("permalink"), "date": (m.get("timestamp") or "")[:10]})
    posts.sort(key=lambda p: (p["outlier"], p["comments"]), reverse=True)
    return accounts, posts

def report(accounts, posts, top=25):
    L = [f"# Instagram scout report ({dt.date.today()})", "", "## Accounts scanned", "| Account | Followers | Posts read | Median engagement |", "|---|---|---|---|"]
    for a in accounts:
        L.append(f"| @{a['username']} | {a.get('followers','–')} | {a.get('posts_read','–')} | {a.get('median_eng', a.get('error',''))} |")
    L += ["", f"## Top {top} outliers (engagement vs the account's own median; likes + 3×comments)", ""]
    for i, p in enumerate(posts[:top], 1):
        L.append(f"{i}. **{p['outlier']}×** @{p['account']} · {p['type']} · {p['likes']} likes · {p['comments']} comments · {p['date']}"
                 + (f" · CTA: {', '.join(p['cta_words'])}" if p['cta_words'] else ""))
        L.append(f"   Hook: {p['hook']}")
        L.append(f"   {p['permalink']}")
    ctas = [p for p in posts if p["cta_words"]]
    ctas.sort(key=lambda p: p["comments"], reverse=True)
    L += ["", "## 'Comment WORD' lead magnets (sorted by comments)", ""]
    for p in ctas[:20]:
        L.append(f"- {', '.join(p['cta_words'])}: {p['comments']} comments (@{p['account']}): {p['hook'][:110]} {p['permalink']}")
    return "\n".join(L)

def main():
    a = argparse.ArgumentParser(); s = a.add_subparsers(dest="cmd", required=True)
    c = s.add_parser("check"); c.add_argument("users", nargs="+")
    k = s.add_parser("scan"); k.add_argument("--watchlist", default=DEFAULT_WL); k.add_argument("--per", type=int, default=25)
    k.add_argument("--out"); k.add_argument("--json"); k.add_argument("--top", type=int, default=25)
    a = a.parse_args()
    if a.cmd == "check":
        for u in a.users:
            d = bd(u, 1)
            print(f"{u}: " + (f"OK followers={d.get('followers_count')} posts={d.get('media_count')}" if d and "error" not in d else f"NOT READABLE ({(d or {}).get('error','')[:70]})"))
        return
    handles = [h["username"] if isinstance(h, dict) else h for h in json.load(open(a.watchlist))["accounts"]]
    accounts, posts = scan(handles, a.per)
    md = report(accounts, posts, a.top)
    if a.out: open(a.out, "w").write(md)
    if a.json: json.dump({"accounts": accounts, "posts": posts}, open(a.json, "w"), indent=1)
    print(md)

if __name__ == "__main__": main()
