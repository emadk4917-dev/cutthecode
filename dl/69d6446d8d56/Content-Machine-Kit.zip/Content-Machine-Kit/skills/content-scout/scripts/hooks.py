#!/usr/bin/env python3
"""hooks.py - turn an ig_scout JSON into a hook bank: which opening patterns win, weighted by outlier score.
Usage: python3 hooks.py scout.json [--out hook_bank.md]"""
import json, re, sys, argparse, collections
PATTERNS = [
 ("Comment-WORD giveaway", r"^comment\b"),
 ("Question / debate", r"\?\s*$|^(is|does|can|would|should|why|what|how)\b"),
 ("Number / list", r"^\d+|\b\d+ (ways|steps|tools|things|prompts|mistakes)\b"),
 ("I built / I made / I tried", r"^(i|we) (built|made|tried|tested|replaced|automated|used)\b"),
 ("Contrarian / stop doing", r"^(stop|don'?t|never|nobody|you'?re doing)\b"),
 ("News / just launched", r"\b(just|new|launched|released|announced|meet)\b"),
 ("Trend-jack (big topic)", r"\b(gta|apple|elon|openai|google|netflix|world cup)\b"),
 ("Story / emotion", r"^(when|the day|i remember|my )"),
 ("How to", r"^how (to|i)\b"),
]
def classify(h):
    h = h.lower().strip()
    hits = [n for n, rx in PATTERNS if re.search(rx, h)]
    return hits or ["Statement"]
a = argparse.ArgumentParser(); a.add_argument("scout"); a.add_argument("--out"); a = a.parse_args()
posts = json.load(open(a.scout))["posts"]
score = collections.defaultdict(lambda: [0, 0.0, 0, []])
for p in posts:
    for c in classify(p["hook"]):
        s = score[c]; s[0] += 1; s[1] += p["outlier"]; s[2] += p["comments"]
        if p["outlier"] >= 2: s[3].append(p)
rows = sorted(score.items(), key=lambda kv: kv[1][1] / kv[1][0], reverse=True)
L = ["| Hook pattern | Posts | Avg outlier | Avg comments | Best example |", "|---|---|---|---|---|"]
for name, (n, out, com, ex) in rows:
    best = max(ex, key=lambda p: p["outlier"]) if ex else None
    L.append(f"| {name} | {n} | {out/n:.1f}× | {com//n} | " + (f"\"{best['hook'][:70]}\" ({best['outlier']}×, @{best['account']})" if best else "–") + " |")
md = "\n".join(L)
if a.out: open(a.out, "w").write(md)
print(md)
