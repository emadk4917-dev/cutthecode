#!/usr/bin/env python3
"""tiktok_demand.py - measure TikTok demand for topics via Upload-Post's hashtag suggestions
(TikTok's own numbers: total posts and total views per hashtag). Key injected by the proxy.

views_per_post = demand per piece of content (higher = audience hungrier than supply).
Usage: python3 tiktok_demand.py [--topics FILE] [--out report.md] [--json out.json]
"""
import argparse, json, os, time, urllib.parse, urllib.request
HERE = os.path.dirname(os.path.abspath(__file__))
DEF = os.path.join(HERE, "..", "references", "topics.json")

def tags(q):
    u = "https://api.upload-post.com/api/uploadposts/suggestions?" + urllib.parse.urlencode(
        {"platform": "tiktok", "type": "hashtags", "q": q, "user": os.environ.get("UPLOADPOST_USER", "yourprofile")})
    r = urllib.request.Request(u, headers={"Authorization": "Apikey proxy-injected"})
    for attempt in range(3):
        try:
            d = json.load(urllib.request.urlopen(r, timeout=60))
            if d.get("hashtags"): return d["hashtags"]
        except Exception:
            pass
        time.sleep(2 + 3 * attempt)
    return []

def main():
    a = argparse.ArgumentParser(); a.add_argument("--topics", default=DEF); a.add_argument("--out"); a.add_argument("--json")
    a = a.parse_args()
    topics = json.load(open(a.topics))["topics"]
    rows = []
    for t in topics:
        time.sleep(1)
        hs = tags(t["tag"])
        exact = next((h for h in hs if h["name"] == t["tag"]), hs[0] if hs else None)
        if not exact: rows.append({**t, "views": 0, "posts": 0, "vpp": -1, "related": []}); continue
        rel = sorted([h for h in hs if h["name"] != exact["name"]], key=lambda h: h["view_count"], reverse=True)[:3]
        rows.append({**t, "views": exact["view_count"], "posts": exact["post_count"],
                     "vpp": round(exact["view_count"] / max(1, exact["post_count"])),
                     "related": [f"#{h['name']} ({h['view_count']/1e6:.1f}M)" for h in rel]})
    rows.sort(key=lambda r: r["vpp"], reverse=True)
    L = ["| # | Topic | Hashtag | Total views | Posts | Views per post | Sell it as |", "|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        if r['vpp'] < 0:
            L.append(f"| – | {r['name']} | #{r['tag']} | no data (TikTok returned nothing; try another tag) | | | {r.get('offer','')} |"); continue
        L.append(f"| {i} | {r['name']} | #{r['tag']} | {r['views']/1e6:,.1f}M | {r['posts']:,} | {r['vpp']:,} | {r.get('offer','')} |")
    md = "\n".join(L)
    if a.out: open(a.out, "w").write(md)
    if a.json: json.dump(rows, open(a.json, "w"), indent=1)
    print(md)
if __name__ == "__main__": main()
