# Idea card template

```
### [Score 8/10] <working title>
Source: @account · <permalink> · 6.7× outlier · 301 comments · <date>
Why it worked: <mechanism in one line>
Our hooks:
 1. …
 2. …
 3. …
Outline (UI-explainer, ~35s): hook scene → 3 steps → proof/number → CTA
Scene recipes: <from cut-the-code-video style guide>
CTA: Comment <WORD> → <lead magnet> (exists / NEW: build it)
Warms up: <offer, e.g. £27 Quickstart>
Notes: <risks, compliance>
```
