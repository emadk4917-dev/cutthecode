# Offers and angles we push

## Live offers (links in the master prompt)
- Free: 10-Minute Website Prompt Pack (CTA word: CODE)
- £27 Claude Code Quickstart → £67 Website Agency Kit → £197 1:1 call → £497 Done-For-You

## Big angle to develop: "The AI content machine"
The user's pitch, cleaned up and compliant:
- What it is: a Claude skill that turns a script (or a long video) into finished short-form videos with motion graphics, captions, voice and music, then posts them to Instagram, TikTok, YouTube Shorts and X automatically.
- Proof we can show honestly: our own pipeline. "This video was made by Claude. Nobody edited it." Show the real cost we pay (Claude plan + Higgsfield + Upload-Post, roughly £100–£130 a month at today's prices; check before quoting) vs typical editor rates (quote real market ranges and say they are typical, e.g. per-video editor prices on freelance sites).
- Volume line (true and checkable): "10 videos a day across 4 platforms is 40 posts a day."
- Long-form → clips: the skill can cut a long video into shorts (to build when demand is proven).
- CTA idea: "Comment MACHINE and I'll send you how it's built" → lead magnet = a free breakdown PDF/video of the pipeline, upsell = the skill/template as a paid product (price to test: £47–£97) or Done-For-You setup.
- NEVER say: "it can generate an extra $5,000–$20,000 in revenue" or any income/revenue promise. Allowed alternatives: "more content than a full-time editor", "the cost of a takeaway a week", "post every day without editing".

## Patterns that work in this niche (update from scout reports)
- "Comment WORD and I'll send it over" as the whole caption (e.g. 301 comments on a 46k account).
- Show the finished result in frame 1, then "here's how".
- Cost comparisons (tool vs hiring).
- "I built X in Y minutes" with the screen visible.
