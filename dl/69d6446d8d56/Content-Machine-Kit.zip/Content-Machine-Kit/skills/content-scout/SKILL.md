---
name: content-scout
description: Finds what's winning right now on Instagram, TikTok and YouTube Shorts in the your brand niche (Claude, AI automation, AI content machines, AI for small businesses, "build with AI" offers) and turns it into ranked, original content ideas and DM-bait offers. It scans competitor/creator accounts with the Instagram Business Discovery API, spots outlier posts and "comment WORD" lead magnets, researches TikTok/YouTube trends, and writes idea cards (hook, why it works, our original script angle, CTA keyword, lead magnet) for the daily content run. Use whenever the user asks for content ideas, research, trends, competitor analysis, "what's working", viral hooks, better offers or lead magnets, or wants to find content people will comment or DM for, even if they don't say "skill".
---

# Content Scout (your brand)

Goal: stop guessing. Every idea we make should be a better, original version of something that is **already proven** to get comments and DMs in our niche, pointed at an offer we can actually deliver.

Read `references/offer-angles.md` before writing ideas. It holds the offers we push (including the "AI content machine" angle) and the compliance rules.

## The loop (run it in this order)

### 1. Scan Instagram (proven data, ~2 min)
```bash
python3 -I scripts/ig_scout.py scan --per 25 --top 25 --out /tmp/ig_scout.md --json /tmp/ig_scout.json
```
- Ranks every recent post by **outlier score** = engagement ÷ that account's own median (likes + 3×comments). 3×+ is a real winner; 5×+ is a format to copy the *structure* of.
- Lists every **"Comment WORD"** call to action with its comment count: these are lead magnets the audience demonstrably wants.
- Only public business/creator accounts can be read (Instagram's rule). Hashtag search is not available.

### 1b. Hook bank (which openings win)
```bash
python3 -I scripts/hooks.py /tmp/ig_scout.json --out /tmp/hook_bank.md
```
Classifies every post's first line (comment-giveaway, question/debate, number/list, "I built…", contrarian, news, trend-jack, how-to, story) and ranks patterns by average outlier score and comments. The video and carousel skills pick their hook pattern from the top of this table.

### 1c. What can we SELL? TikTok demand scan (real TikTok numbers)
```bash
python3 -I scripts/tiktok_demand.py --out /tmp/tiktok_demand.md --json /tmp/tiktok_demand.json
```
For every topic in `references/topics.json` (AI receptionists, voice agents, UGC ads, avatars, clipping, MCP servers, vibe-coded apps, 24/7 hosted agents, n8n…) it pulls TikTok's own total views and post counts for the hashtag (via Upload-Post) and ranks by **views per post** = audience demand per piece of content. High views-per-post + something we can build = a content pillar AND a product. Keep adding topics; think beyond websites and chatbots (anything Claude can build, host or run for a business). Some hashtags return no data; try a variant tag.

### 2. Grow and prune the watchlist (weekly)
- Find new accounts: WebSearch for things like "top AI automation creators Instagram", "Claude Code tutorial creator", "AI agency owner reels", "AI content creation faceless". Collect handles.
- Verify: `python3 -I scripts/ig_scout.py check handle1 handle2 …`, then add the readable ones to `references/watchlist.json` with a one-line "why".
- Keep 15–40 accounts. Mix sizes: big accounts show what scales, small accounts with outliers show what works without an audience (more useful for us).
- Remove accounts that haven't produced a 3× outlier in a month.

### 3. TikTok + YouTube Shorts research
Current access, honestly:
- TikTok: hashtag demand numbers (above) + trending sounds. Per-video data for other creators (top videos for a keyword, their views/comments, captions, the first 3 seconds) needs a scraper: **upgrade = Apify** (API token saved as a network secret for api.apify.com; actors like TikTok search/hashtag scrapers, pay-per-result).
- YouTube: **upgrade = a free YouTube Data API key** (Google Cloud), saved as a network secret for www.googleapis.com with header X-Goog-Api-Key. Then search by keyword, sort by views, read view/like/comment counts and transcripts (the real first-3-seconds hook) of Shorts in our niche.
- Until those exist:
- WebSearch / web-fetch agent: "TikTok Creative Center trending hashtags AI", "trending Claude AI TikTok this week", YouTube "Claude Code" sorted by recent with high views. Note titles, hooks, view counts, formats.
- If the user uploads reference videos: sample frames with ffmpeg and transcribe (see cut-the-code-video skill), or use Higgsfield `video_analysis_create` / `virality_predictor` on them.
- Trending sounds: Higgsfield `tiktok_music_trending` (GB).
- Never download or repost other creators' footage. We learn the *structure*, then build our own visuals.

### 4. Turn winners into idea cards
For each of the top ~10 winners, write an idea card (see `references/idea-card.md`):
- **Source + proof**: link, outlier score, comments.
- **Why it worked**: the mechanism (curiosity gap, big-number promise, before/after, "you're doing it wrong", free asset, social proof, controversy, speed).
- **Our original version**: new hook (3 options), 1-line script outline in our UI-explainer style, which scene recipes to use.
- **CTA keyword + lead magnet**: which existing asset it sends (free prompt pack = CODE), or a NEW lead magnet worth building if the data shows demand (e.g. "Comment MACHINE for the skill").
- **Offer link**: which paid product it warms people up for.
- **Score** 1–10 = proof × fit × ease (can our pipeline make it today?).

### 5. Deliver
- Append the cards (best first) to Google Drive "your brand/Strategy/Research inbox" (date-stamped), and save the raw report to `./workspace/research/<date>/`.
- The daily content run reads the Research inbox first and makes the top-scored ideas.
- If 3+ winners point to the same NEW lead magnet or offer, flag it to the user as "build this next" with the evidence.

## Rules
- Original work only: never copy captions word for word, never use other creators' footage, faces, music or logos.
- No income promises in hooks or captions (UK ASA/CAP). "Agencies charge £X for this" or "this replaced a £Y/month editor for me" (only if true) are fine; "you'll make £5k–£20k" is not. See offer-angles.md.
- Don't follow, like, comment or DM from automation. This skill only reads.

## Interpret, don't just collect (owner rule, 22 Nov 2026)
Numbers alone are not the output. For every winner, work out **what is going on and how it is positioned** so we can do the same and make money. For each top winner, answer:
1. **The promise:** what does the viewer get, in one line? Is it a tip or a *complete system* ("my entire setup")? Systems pull 0.25–0.35% of views as comments; tips pull far less.
2. **Who it targets:** beginner, creator, business owner? What pain or desire does the hook press?
3. **The offer behind the keyword:** open the bio link and the DM flow if visible. What do they actually send (PDF, free community, tool trial)? What do they sell after it (community subscription, course, SaaS, agency)? Estimate the funnel (e.g. Nate Herk: reel → comment → DM → free Skool 450k → AIS+ 3,500 × $129/mo).
4. **Why people comment:** freebie size, a word that matches the hook, the word said/shown/typed 4 times, mid-video ask, a debatable claim.
5. **Structure and measured craft:** first-frame proof object, words/sec, visual change rate, music level, CTA position (the methods are in `your-workspace/WINNERS-BREAKDOWN.md`).
6. **Our version and our money path:** which freebie (existing or to build), which paid product it warms up, and an honest number we can show.
Write this as a "positioning teardown" section at the top of each research report, before the idea cards. Worked examples: `your-workspace/TEARDOWN-PLAYBOOK.md` (Nate Herk, getripping) and `your-workspace/WINNERS-BREAKDOWN.md`.

## Learn and adapt (the skill must get better over time)
- **Before every run:** read `your-workspace/learnings/LEARNINGS.md` (Rules, Testing now, Results log, Opportunity radar). Every idea card names the rule it follows and the test it runs.
- **After every post (at 48h):** pull its stats (IG insights / TikTok Studio / YouTube Studio, or `ig.py stats`). Append a row to the Results log with one learning sentence: what it tells us, compared to our median.
- **Weekly (Sunday):** promote a test to a Rule after it wins ≥2 times (≥1.5× median on its metric). Retire what lost twice. Re-rank the Opportunity radar.
- **Opportunity radar (every run):** search for what's happening *now*: game, film and music launches, platform changes, new Claude/AI features, shopping events, viral creator formats. For each, ask: "Everyone is talking about X. What can a normal person *build or run with Claude* to take part, honestly?" Write it as an idea card with the trend's window (how many days it stays hot). Example: GTA 6 launch → a Claude clipping setup for paid, authorised clip campaigns.
- **Implement as we go:** the top-scoring idea card each day goes into production (script → video → value caption → schedule). Don't just file it.

## Profile deep-dive procedure (how the @skilltreeos teardown was done; repeat for any account the owner sends)
1. In the Mac Chrome ("Browser 2", logged in to @yourbrand), open the profile and read the bio, the link-in-bio list and the follower/post counts.
2. Collect every post URL (`a[href*="/reel/"], a[href*="/p/"]`). For each, read the caption (keyword + promised freebie) and the 4 numbers (likes, comments, reposts, shares).
3. Compute **comments ÷ likes** (≥1.0 means the keyword/freebie is doing the work) and shares ÷ likes (saveable systems).
4. Open their site and pricing page: what's the paid product, its price and model (SaaS, course, community, agency)? That's the money path.
5. Uploaded reels: frames (`fps=1` sheet + first 4s at `fps=4`), transcript, words/sec, visual change rate, music level (`your-workspace/WINNERS-BREAKDOWN.md` method).
6. Output a teardown (`your-workspace/<NAME>-TEARDOWN.md`): a data table, what they're doing, their weak spots, **our twist**, then 3–5 idea cards in IDEAS.md, each with a keyword, the freebie that matches the video, a £27/£46 kit, and a top tier.
7. Rank ideas by expected money: comments/like ratio of the source × how directly the freebie leads to a kit we already have or can build in a day × timeliness.
