# /ig-viral: learn from what's winning, write something original

**Input:** a niche keyword (default: a niche keyword from audience.md) or a specific account.
**Output:** a breakdown of the top 3–5 reels, then 1–3 **original** scripts in our voice and in the house video style.

## Step 1: find the winners
Pick whichever route is available:
- **Browser (best):** Claude in Chrome, logged in as the user. Search Instagram for the keyword, open the Reels tab, sort by most viewed or liked, and capture each video's hook (first line on screen and spoken), length, format and view count.
- **User uploads:** reel files the user saves and sends. Pull frames with ffmpeg (`fps=4` for the first 4s, `fps=1` overall, tiled) and transcribe with faster-whisper (the cut-the-code-video skill includes `scripts/transcribe.py`).
- **Web search:** for articles and roundups of top-performing reels in the niche this month.

## Step 2: break each one down
| Field | What to capture |
|---|---|
| Hook | The exact opening line, and which of the 21 formulas it uses |
| Structure | e.g. Problem → 30-second check → the fix |
| Visual | Talking head, UI motion graphics, screen recording, B-roll |
| Pace | Words per second, cuts per second |
| CTA | The keyword, and what's offered |
| Why it worked | One sentence: the real reason people watched and saved |

## Step 3: write the original version
- **Keep the *reason it worked*, not the words.** Change the topic, angle and examples to ours.
- Write in voice.md's voice, for audience.md's people.
- Make it 90–120 words, mapped to scenes the cut-the-code-video skill can build.
- Add our CTA and keyword.

**Never reuse another creator's footage, script lines, or name in a way that suggests endorsement.**
