# /ig-post: captions with the 21 hook formulas

**Input:** what the post is about (or the script or video), and the format (reel, carousel or image).
**Output:** 3 hook options (each naming its formula), a full caption, a CTA, and a hashtag set (from /ig-hashtag).

## Process
1. Read voice.md and audience.md.
2. Pick the 3 formulas that best fit the topic, using different formula *types*, not 3 lists.
3. Write each hook in 12 words or fewer. It must make sense with the sound off and the video unseen.
4. Write the caption:
   - **Line 1:** the hook. It's all people see before "more", so it does the work.
   - **Lines 2–6:** the value. Short lines, the specific prompt, number or step.
   - **One honest line:** the catch or the effort involved.
   - **CTA:** "Comment CODE and I'll send you the prompts." (or the post's keyword)
   - Optionally, one line inviting a reply, e.g. "What would you build first?"
5. Keep it under 150 words for reels. Carousels can go to 220.
6. Mark the recommended hook, and say why in one line.

## The 21 hook formulas
1. **The mistake:** "Stop doing X with Claude." / "You're using Claude wrong."
2. **The impossible result:** "Claude built this from one sentence."
3. **Price reveal:** "Businesses pay £150 a month for this. Claude built it in 10 minutes."
4. **If I started from zero:** "If I had to start from £0 with just Claude, I'd do this."
5. **The list:** "3 things Claude can do that nobody's talking about."
6. **Before → after:** "This plumber's website is from 2009. Watch."
7. **Day N story:** "Day 14 of letting AI run my business. Revenue: £__."
8. **Contrarian:** "Learning to code to make money is a waste of time in 2026."
9. **Secret or underused:** "The Claude feature 90% of people never use."
10. **Challenge:** "Claude vs a £2,000 agency. Same brief."
11. **POV:** "POV: your AI just finished your work before you woke up."
12. **Question:** "Why does every local business near you have a terrible website?"
13. **Warning:** "Don't sell websites until you've checked this."
14. **Save this:** "Save this before you open Claude again."
15. **Relatable pain:** "If you've tried 5 side hustles and none worked, watch this."
16. **Time compression:** "4 hours of work in 6 minutes."
17. **Trend-jack:** "GTA 6 made billions in a day. Here's how normal people get paid from it."
18. **Myth bust:** "You don't need to be good at sales to sell websites."
19. **Specific number:** "5 clients × £150 = the maths nobody shows you."
20. **Behind the scenes:** "This whole account is run by a Claude skill. Here it is."
21. **Curiosity gap:** "I asked Claude to find my first client. It did something I didn't expect."

## Quality check before handing over
- Is it true and shown in the post? No bait.
- Is there no income promise? Prices are framed as prices or "if you land them".
- Would the "nothing ever works for me" person feel spoken to?
- Is there one clear next step?

## Owner rule (22 Nov 2026): the caption is a second layer of value
People read captions. A caption that says "here's how 👇" and then has nothing to read under it wastes the reader's attention. Example: the "3 services you can sell with Claude" carousel went out with **no caption at all**.
- **Never post with an empty or filename caption.**
- **Every 👇 / "here's how" / "the list" must be followed by the actual content:** each step, service or tool named, with a number (price, time, views, stars, % saved). Someone who never swipes or watches should still learn something.
- **Carousels:** restate every slide's item in the caption, one line each, with its data point (e.g. "1) AI receptionist: businesses pay £150–300/mo; Claude sets it up in an afternoon").
- **Reels:** list the steps shown in the video (1️⃣ 2️⃣ 3️⃣), then a proof line, then the CTA.
- **The CTA comes after the value, specific about what they get:** "💬 Comment CODE and I'll send you <exact thing>". Put the keyword in line 1 or 2 as well, so it shows before "more".
- Reels about 120–220 words is fine when every line carries value. Data beats adjectives.
