// Runs every "must work" check from SPEC.md in a headless browser at phone width (375px).
// Usage: node tests/must-work.mjs   (needs Playwright installed globally or locally, and Chrome)
import { createRequire } from 'module';
import { spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';

const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); } catch { playwright = require('/opt/node22/lib/node_modules/playwright'); }

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = path.join(ROOT, 'tests', 'screens');
fs.rmSync(SHOTS, { recursive: true, force: true });
fs.mkdirSync(SHOTS, { recursive: true });
const PORT = 3000 + Math.floor(Math.random() * 1000) + 1000;
const BASE = `http://localhost:${PORT}`;
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ic-'));
const storeFile = path.join(tmpDir, 'store.json');
// The test uses its own config.json so it never touches yours. These links are fake and
// are intercepted by the test browser, so no request leaves this machine.
const configFile = path.join(tmpDir, 'config.json');
const FAKE_STRIPE_LINK = 'https://buy.stripe.com/test_FAKE_LINK_123';
const FAKE_WHOP_LINK = 'https://whop.com/checkout/plan_FAKE123/';
const writeConfig = (c) => fs.writeFileSync(configFile, JSON.stringify(c, null, 2));
writeConfig({ PAYMENT_LINK: '', MANAGE_LINK: '', SUPPORT_EMAIL: '' });

const server = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
  env: { ...process.env, PORT: String(PORT), STORE_FILE: storeFile, CONFIG_FILE: configFile, RESEND_API_KEY: '' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
await new Promise((res, rej) => {
  server.stdout.on('data', (d) => { if (String(d).includes('http://localhost')) res(); });
  server.stderr.on('data', (d) => process.stderr.write(d));
  setTimeout(() => rej(new Error('server did not start')), 5000);
});

const results = [];
function record(id, name, checks, notes = '') {
  const pass = checks.every((c) => c[1]);
  results.push({ id, name, pass, checks: checks.map(([label, ok, detail]) => ({ label, ok: !!ok, detail: detail ?? '' })), notes });
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${id}. ${name}`);
  for (const [label, ok, detail] of checks) console.log(`      ${ok ? '✓' : '✗'} ${label}${detail ? ` (${detail})` : ''}`);
}
const outbox = async () => (await fetch(`${BASE}/api/outbox`)).json();
const pad = (n) => String(n).padStart(2, '0');
const isoLocal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const fmtDate = (iso) => new Date(iso + 'T00:00:00Z').toLocaleDateString('en-US', { timeZone: 'UTC', month: 'short', day: 'numeric', year: 'numeric' });

const browser = await playwright.chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/bin/google-chrome', headless: true });
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
// Stand in for the payment provider: record where the browser went, return a stub page.
const providerHits = [];
await ctx.route(/^https:\/\/(buy\.stripe\.com|whop\.com)\//, (route) => {
  providerHits.push(route.request().url());
  route.fulfill({ status: 200, contentType: 'text/html', body: '<!doctype html><meta name="viewport" content="width=device-width"><h1 id="provider-stub">Payment provider (stub)</h1>' });
});
const page = await ctx.newPage();
const consoleErrors = [];
page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
page.on('pageerror', (e) => consoleErrors.push(String(e)));
page.on('dialog', (d) => d.accept());

const overflow = {}; // screen -> {scrollWidth, width}
async function checkWidth(p, name) {
  const w = await p.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, width: window.innerWidth }));
  overflow[name] = w;
  await p.screenshot({ path: path.join(SHOTS, `${name}.png`), fullPage: true });
  return w.scrollWidth <= w.width;
}

const START = new Date();
await page.clock.install({ time: START });
const TODAY = isoLocal(START);
const USER = 'sam.fake.plumber@example.com';
const PW = 'correct horse 1';

try {
  // ---------- P. Pricing section + "Start your plan" opens the link in config.json ----------
  const startPlan = async () => {
    await page.goto(BASE + '/');
    await page.waitForFunction(() => window.__config !== undefined);
    await page.waitForSelector('#pricing #start-plan');
    return page.$eval('#start-plan', (el) => ({ tag: el.tagName, href: el.getAttribute('href'), disabled: el.disabled === true, text: el.textContent.trim() }));
  };
  const clickAndLand = async () => {
    const before = providerHits.length;
    await Promise.all([page.waitForURL(/^https:\/\//), page.click('#start-plan')]);
    await page.waitForSelector('#provider-stub');
    return { url: page.url(), hit: providerHits.slice(before)[0] };
  };
  const empty = await startPlan();
  const pricingText = await page.textContent('#pricing');
  const missingMsg = await page.textContent('#link-missing').catch(() => '');
  await checkWidth(page, '00-pricing-no-link');
  writeConfig({ PAYMENT_LINK: FAKE_STRIPE_LINK, MANAGE_LINK: '', SUPPORT_EMAIL: 'help@example.com' });
  const stripeBtn = await startPlan();
  await checkWidth(page, '00-pricing-with-link');
  const stripeLand = await clickAndLand();
  writeConfig({ PAYMENT_LINK: FAKE_WHOP_LINK, MANAGE_LINK: '', SUPPORT_EMAIL: 'help@example.com' }); // no server restart
  const whopBtn = await startPlan();
  const whopLand = await clickAndLand();
  writeConfig({ PAYMENT_LINK: 'javascript:alert(1)', MANAGE_LINK: '', SUPPORT_EMAIL: '' });
  const badBtn = await startPlan();
  writeConfig({ PAYMENT_LINK: FAKE_STRIPE_LINK, MANAGE_LINK: '', SUPPORT_EMAIL: 'help@example.com' });
  record('P', 'Pricing section and "Start your plan" button', [
    ['Pricing section shows $19 / month and the free vs paid list', /\$19/.test(pricingText) && /month/.test(pricingText) && /Unlimited/.test(pricingText)],
    ['With PAYMENT_LINK empty: button is disabled and says what to set', empty.disabled && /PAYMENT_LINK/.test(missingMsg), missingMsg.trim()],
    ['With a Stripe Payment Link in config.json: button points to exactly that link', stripeBtn.href === FAKE_STRIPE_LINK, stripeBtn.href],
    ['Clicking it opens that link', stripeLand.url === FAKE_STRIPE_LINK && stripeLand.hit === FAKE_STRIPE_LINK, stripeLand.url],
    ['After switching config.json to a Whop link (no restart): button points to it', whopBtn.href === FAKE_WHOP_LINK, whopBtn.href],
    ['Clicking it opens the Whop link', whopLand.url === FAKE_WHOP_LINK && whopLand.hit === FAKE_WHOP_LINK, whopLand.url],
    ['A non-https value (javascript:…) is refused: button stays disabled', badBtn.disabled && badBtn.href === null],
  ], 'The links are fake. The test browser intercepted them and returned a stub page, so nothing went to Stripe or Whop.');

  // ---------- 1. Sign up ----------
  await page.goto(BASE + '/');
  await checkWidth(page, '01-signup');
  await page.fill('#auth-email', USER);
  await page.fill('#auth-password', PW);
  await page.click('#auth-submit');
  const emptyAfterSignup = await page.waitForSelector('#empty-state', { timeout: 10000 }).then(() => true).catch(() => false);
  await checkWidth(page, '02-invoices-empty');
  await page.click('#logout');
  const backToAuth = await page.waitForSelector('#auth-form', { timeout: 5000 }).then(() => true).catch(() => false);
  await page.fill('#auth-email', USER);
  await page.fill('#auth-password', 'wrong password');
  await page.click('#auth-submit');
  const wrongPwRejected = await page.waitForSelector('#auth-error:not([hidden])', { timeout: 10000 }).then(() => true).catch(() => false);
  await page.fill('#auth-password', PW);
  await page.click('#auth-submit');
  const loggedBackIn = await page.waitForSelector('#empty-state', { timeout: 10000 }).then(() => true).catch(() => false);
  record(1, 'Sign up', [
    ['New email + password lands on an empty Invoices screen', emptyAfterSignup],
    ['Log out returns to the login form', backToAuth],
    ['Wrong password is rejected', wrongPwRejected],
    ['Logging back in works', loggedBackIn],
  ]);

  // set business name (needed for check 3)
  await page.goto(BASE + '/#/settings');
  await page.fill('#s-business', 'Fake Plumbing Co');
  await page.click('#save-settings');
  await page.waitForSelector('#flash');
  await checkWidth(page, '03-settings-free');

  // ---------- 2. Add invoice ----------
  async function addInvoice({ client, email, number, amount, due, payment }) {
    await page.goto(BASE + '/#/add');
    await page.waitForSelector('#add-form');
    await page.fill('#f-client', client);
    await page.fill('#f-email', email);
    await page.fill('#f-number', number);
    await page.fill('#f-amount', amount);
    await page.fill('#f-due', due);
    await page.fill('#f-payment', payment);
    await page.click('#save-invoice');
    await page.waitForSelector('#invoice-list');
  }
  const due1 = addDays(TODAY, -10);
  await page.goto(BASE + '/#/add');
  await page.waitForSelector('#add-form');
  await checkWidth(page, '04-add-invoice');
  await addInvoice({ client: 'Bob Fakeman', email: 'bob.fakeman@example.com', number: 'T-1', amount: '250', due: due1, payment: 'https://pay.example.com/T-1' });
  const t1Badge = await page.textContent('[data-invoice="T-1"] [data-status]');
  const total1 = await page.textContent('#outstanding');
  await checkWidth(page, '05-invoices-one');
  record(2, 'Add invoice', [
    ['Invoice with a past due date shows as Overdue', t1Badge === 'Overdue', `badge: ${t1Badge}`],
    ['Outstanding total updates', total1 === '$250.00', `total: ${total1}`],
  ]);

  // ---------- 3. Reminder arrives ----------
  await page.click('[data-invoice="T-1"]');
  await page.waitForSelector('#send-now');
  const before3 = (await outbox()).length;
  await page.click('#send-now');
  await page.waitForSelector('#flash');
  await checkWidth(page, '06-invoice-detail-sent');
  const box3 = await outbox();
  const mail = box3.find((m) => m.to === 'bob.fakeman@example.com' && m.kind === 'reminder');
  const t1Url = page.url();
  record(3, 'Reminder arrives', [
    ['"Send now" produces exactly one email', box3.length === before3 + 1],
    ['Sent to the client', !!mail],
    ['Shows the business name as sender', mail?.fromName === 'Fake Plumbing Co', mail?.fromName],
    ['Shows the amount', mail?.html.includes('$250.00')],
    ['Shows the due date', mail?.html.includes(fmtDate(due1)), fmtDate(due1)],
    ['Payment link is a clickable link to the right URL', mail?.html.includes('href="https://pay.example.com/T-1"')],
    ['Replies go to your email', mail?.replyTo === USER, mail?.replyTo],
    ['Free plan footer present', mail?.html.includes('Sent with Invoice Chaser')],
  ], 'Checked in the local dev outbox (/outbox). Delivery to a real inbox needs RESEND_API_KEY and EMAIL_FROM and was not tested.');

  // ---------- 4a. Schedule shows (default schedule, free plan) ----------
  const nextT1 = await page.$$eval('#next-reminders li', (els) => els.map((e) => e.dataset.date));
  const due2 = addDays(TODAY, 2);
  await addInvoice({ client: 'Dora Notreal', email: 'dora@example.com', number: 'T-2', amount: '99.99', due: due2, payment: 'https://pay.example.com/T-2' });
  const t2Badge = await page.textContent('[data-invoice="T-2"] [data-status]');
  await page.click('[data-invoice="T-2"]');
  await page.waitForSelector('#next-reminders');
  const t2Url = page.url();
  const nextT2 = await page.$$eval('#next-reminders li', (els) => els.map((e) => e.dataset.date));
  const checks4 = [
    ['T-1 (10 days overdue, reminder 1 sent now): next reminder is due date + 14', JSON.stringify(nextT1) === JSON.stringify([addDays(due1, 14)]), nextT1.join(', ')],
    ['T-2 (due in 2 days) shows as Not due', t2Badge === 'Not due', t2Badge],
    ['T-2 next reminders = due + 1, 7, 14 (default schedule)', JSON.stringify(nextT2) === JSON.stringify([1, 7, 14].map((n) => addDays(due2, n))), nextT2.join(', ')],
  ];

  // ---------- 6. Client "Already paid?" ----------
  const claimUrl = mail?.meta?.claimUrl;
  const client = await ctx.newPage();
  await client.goto(claimUrl);
  const claimPageOk = await client.waitForSelector('#confirm-paid', { timeout: 5000 }).then(() => true).catch(() => false);
  await checkWidth(client, '07-client-already-paid');
  await client.click('#confirm-paid');
  const thanks = await client.waitForSelector('#claim-thanks', { timeout: 5000 }).then(() => true).catch(() => false);
  await checkWidth(client, '08-client-thanks');
  await client.close();
  await page.goto(t1Url);
  await page.clock.runFor(31_000); // the app checks for client claims every 30s
  const banner = await page.waitForSelector('#claim-banner', { timeout: 5000 }).then(() => true).catch(() => false);
  const flag = await page.$('[data-flag="claim"]');
  const t1NoNext = await page.$('#no-next');
  await checkWidth(page, '09-invoice-client-says-paid');
  await new Promise((r) => setTimeout(r, 300));
  const box6 = await outbox();
  const notify = box6.find((m) => m.kind === 'notification' && m.to === USER);
  record(6, 'Client "Already paid?"', [
    ['Link in the email opens a confirmation page', claimPageOk],
    ['Confirming shows a thank-you', thanks],
    ['Invoice shows "Client says paid"', banner && !!flag],
    ['Reminders paused (no next reminders listed)', !!t1NoNext],
    ['You get a notification email', !!notify, notify?.subject],
  ], 'The client page asks for one extra click ("Yes, I\'ve paid") so email link-scanners that pre-open links can\'t pause reminders by themselves.');

  // ---------- 7. Free limit and upgrade ----------
  const due3 = addDays(TODAY, -3);
  await addInvoice({ client: 'Carl Placeholder', email: 'carl@example.com', number: 'T-3', amount: '1,200', due: due3, payment: 'https://pay.example.com/T-3' });
  await page.goto(BASE + '/#/add');
  const limitShown = await page.waitForSelector('#limit-prompt', { timeout: 5000 }).then(() => true).catch(() => false);
  const formHidden = !(await page.$('#add-form'));
  await page.waitForFunction(() => document.querySelector('#start-plan')?.getAttribute('href'));
  await checkWidth(page, '10-free-limit');
  const limitHref = await page.getAttribute('#start-plan', 'href');
  const limitLand = await clickAndLand();
  // the provider would now redirect the buyer to welcome.html
  await page.goto(BASE + '/welcome.html');
  const welcomeStatus = await page.textContent('#status');
  await checkWidth(page, '11-welcome-logged-in');
  await page.click('#continue');
  await page.waitForSelector('#invoice-list');
  await page.goto(BASE + '/#/billing');
  const paidPlan = await page.waitForSelector('#plan-name', { timeout: 10000 }).then(() => page.textContent('#plan-name')).catch(() => null);
  await page.waitForSelector('#manage-missing');
  const manageText = await page.textContent('#manage-missing');
  await checkWidth(page, '12-billing-paid');
  await addInvoice({ client: 'Erin Madeup', email: 'erin@example.com', number: 'T-4', amount: '75', due: addDays(TODAY, 20), payment: 'https://pay.example.com/T-4' });
  const t4Added = !!(await page.$('[data-invoice="T-4"]'));
  record(7, 'Free limit and upgrade', [
    ['With 3 unpaid invoices, adding a 4th shows the upgrade prompt with pricing', limitShown && formHidden],
    ['Its "Start your plan" opens the PAYMENT_LINK from config.json', limitHref === FAKE_STRIPE_LINK && limitLand.url === FAKE_STRIPE_LINK, limitLand.url],
    ['Landing on welcome.html (logged in) turns on paid features for that account', /Paid features are now on for/.test(welcomeStatus) && welcomeStatus.includes(USER), welcomeStatus.trim()],
    ['Billing then shows "Paid", with how to cancel (SUPPORT_EMAIL)', paidPlan === 'Paid' && manageText.includes('help@example.com'), paidPlan],
    ['The 4th invoice can now be added', t4Added],
  ], 'The payment itself was not made: the fake link went to a stub page. A real Stripe test-card payment needs your own test-mode Payment Link (see GET-PAID.md). welcome.html can\'t tell whether a payment really happened.');

  // ---------- 4b. Custom schedule (paid) ----------
  await page.goto(BASE + '/#/settings');
  await page.waitForSelector('#stages');
  await page.click('[data-action="remove-stage"][data-i="2"]');
  await page.fill('#st-days-0', '3');
  await page.fill('#st-days-1', '10');
  await page.click('#save-settings');
  await page.waitForSelector('#flash');
  await checkWidth(page, '13-settings-paid');
  await page.goto(t2Url);
  await page.waitForSelector('#next-reminders');
  const nextT2b = await page.$$eval('#next-reminders li', (els) => els.map((e) => e.dataset.date));
  checks4.push(['After changing the schedule to 3 and 10 days, T-2 shows due + 3 and due + 10', JSON.stringify(nextT2b) === JSON.stringify([addDays(due2, 3), addDays(due2, 10)]), nextT2b.join(', ')]);
  record(4, 'Schedule shows', checks4);

  // ---------- 5. Mark as paid stops it ----------
  const t3Link = await (await page.goto(BASE + '/#/invoices'), page.waitForSelector('[data-invoice="T-3"]'));
  await t3Link.click();
  await page.waitForSelector('#mark-paid');
  const t3HadNext = !!(await page.$('#next-reminders li'));
  await page.click('#mark-paid');
  await page.waitForSelector('#paid-note');
  const t3Status = await page.textContent('#detail-status [data-status]');
  const t3NoNext = !!(await page.$('#no-next'));
  await checkWidth(page, '14-invoice-paid');
  const carlBefore = (await outbox()).filter((m) => m.to === 'carl@example.com').length;
  const doraBefore = (await outbox()).filter((m) => m.to === 'dora@example.com').length;
  // jump 30 days ahead and let the app's once-a-minute scheduler run
  await page.clock.setSystemTime(new Date(START.getTime() + 30 * 864e5));
  await page.clock.runFor(61_000);
  await new Promise((r) => setTimeout(r, 1000));
  const carlAfter = (await outbox()).filter((m) => m.to === 'carl@example.com').length;
  const doraAfter = (await outbox()).filter((m) => m.to === 'dora@example.com').length;
  record(5, 'Mark as paid stops it', [
    ['Before: T-3 had scheduled reminders', t3HadNext],
    ['Status changes to Paid', t3Status === 'Paid', t3Status],
    ['Scheduled reminders disappear', t3NoNext],
    ['30 days later: no emails to the paid client', carlAfter === carlBefore, `${carlBefore} → ${carlAfter}`],
    ['Control: an unpaid invoice (T-2) did get its automatic reminder in the same run', doraAfter > doraBefore, `${doraBefore} → ${doraAfter}`],
  ], 'Time was moved forward 30 days with a fake browser clock so the scheduler would run.');

  // ---------- extra: sample CSV import on a fresh free account ----------
  const p2 = await (await browser.newContext({ viewport: { width: 375, height: 812 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true })).newPage();
  p2.on('pageerror', (e) => consoleErrors.push(String(e)));
  p2.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  p2.on('dialog', (d) => d.accept());
  await p2.goto(BASE + '/');
  await p2.fill('#auth-email', 'csv.tester@example.com');
  await p2.fill('#auth-password', PW);
  await p2.click('#auth-submit');
  await p2.waitForSelector('#empty-state');
  await p2.goto(BASE + '/#/add');
  await p2.setInputFiles('#csv-file', path.join(ROOT, 'sample-invoices.csv'));
  await p2.waitForSelector('#invoice-list');
  const freeCount = (await p2.$$('[data-invoice]')).length;
  const freeMsg = await p2.textContent('#flash');
  await checkWidth(p2, '15-csv-free');
  const sentOnImport = (await outbox()).filter((m) => /example\.(com|org)$|\.example$/.test(m.to) && m.to !== 'bob.fakeman@example.com' && /DEMO-/.test(m.subject)).length;
  // Buyer who pays BEFORE logging in on this device: log out, land on welcome.html, then log in.
  await p2.click('#logout');
  await p2.waitForSelector('#auth-form');
  await p2.goto(BASE + '/welcome.html');
  const pendingStatus = await p2.textContent('#status');
  const continueHref = await p2.getAttribute('#continue', 'href');
  await p2.click('#continue');
  await p2.waitForSelector('#auth-form');
  await p2.fill('#auth-email', 'csv.tester@example.com');
  await p2.fill('#auth-password', PW);
  await p2.click('#auth-submit');
  await p2.waitForSelector('#invoice-list');
  const welcomeFlash = await p2.textContent('#flash').catch(() => '');
  await p2.goto(BASE + '/#/billing');
  const p2Plan = await p2.textContent('#plan-name');
  await p2.goto(BASE + '/#/add');
  await p2.setInputFiles('#csv-file', path.join(ROOT, 'sample-invoices.csv'));
  await p2.waitForSelector('#invoice-list');
  const paidCount = (await p2.$$('[data-invoice]')).length;
  await checkWidth(p2, '16-csv-paid');
  await p2.goto(BASE + '/#/billing');
  await p2.click('#deactivate');
  await p2.waitForSelector('#pricing');
  const backToFree = await p2.textContent('#plan-name');
  record('W', 'welcome.html when the buyer isn\'t logged in yet', [
    ['Welcome page says to log in, and its button goes to the login screen', /Log in/.test(pendingStatus) && continueHref === '/#/login', `${pendingStatus.trim()} → ${continueHref}`],
    ['After logging in, the account is on the Paid plan, with a thank-you message', p2Plan === 'Paid' && /Thanks for paying/.test(welcomeFlash), p2Plan],
    ['"Switch this device back to Free" works', backToFree === 'Free', backToFree],
  ]);
  record('extra', 'Sample CSV import', [
    ['Free plan: imports the 2 paid + 3 unpaid, blocks the other 3 with an upgrade note', freeCount === 5 && /3 unpaid invoices were not imported/.test(freeMsg), `${freeCount} imported`],
    ['Import does not blast reminders for dates that already passed', sentOnImport === 0, `${sentOnImport} sent`],
    ['Paid plan: importing again adds the remaining 3 (8 total, no duplicates)', paidCount === 8, `${paidCount} total`],
  ]);

  // ---------- no secret keys in the code ----------
  const files = ['server.js', 'public/index.html', 'public/welcome.html', 'config.json', 'package.json'];
  const secretHits = files.filter((f) => /sk_(live|test)_|rk_(live|test)_|whsec_|STRIPE_SECRET|Bearer\s+[A-Za-z0-9_]{20,}/.test(fs.readFileSync(path.join(ROOT, f), 'utf8')));
  record('K', 'No secret keys in the code', [
    ['No Stripe secret/restricted/webhook keys or hard-coded tokens in the app files', secretHits.length === 0, secretHits.join(', ') || files.join(', ')],
  ]);

  // ---------- 8. Phone width ----------
  const widthChecks = Object.entries(overflow).map(([name, w]) => [`${name}: no sideways scroll`, w.scrollWidth <= w.width, `${w.scrollWidth}px content / ${w.width}px screen`]);
  widthChecks.unshift(['Added an invoice at 375px (checks 2, 4, 7)', true], ['Marked an invoice paid at 375px (check 5)', t3Status === 'Paid']);
  record(8, 'Phone width (375px)', widthChecks);
} catch (e) {
  console.error('Test run crashed:', e);
  results.push({ id: 'crash', name: 'Test run crashed', pass: false, checks: [{ label: String(e.stack || e), ok: false, detail: '' }] });
} finally {
  record('console', 'No JavaScript errors in the browser console', [['Console errors', consoleErrors.length === 0, consoleErrors.slice(0, 5).join(' | ')]]);
  await browser.close();
  server.kill();
  fs.writeFileSync(path.join(ROOT, 'tests', 'results.json'), JSON.stringify({ ranAt: new Date().toISOString(), today: TODAY, results }, null, 2));
  const failed = results.filter((r) => !r.pass).length;
  console.log(failed ? `\n${failed} FAILED` : '\nALL PASSED');
  process.exit(failed ? 1 : 0);
}
