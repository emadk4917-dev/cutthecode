// Invoice Chaser: tiny Node server, no dependencies.
// Invoice data lives in the user's browser (localStorage). The server only:
//   - serves the one app page (public/index.html)
//   - sends emails (Resend if RESEND_API_KEY + EMAIL_FROM are set, otherwise a local dev outbox at /outbox)
//   - records "Already paid?" clicks from clients (token -> claimed time)
//   - tells the page which payment link to use (PAYMENT_LINK in config.json: a Stripe Payment Link or Whop checkout link)
//   - serves welcome.html, the page buyers land on after paying
// No payment secret keys are used anywhere. See GET-PAID.md.
//
// Run: node server.js   (PORT defaults to 3000)

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const APP_NAME = 'Invoice Chaser';
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const EMAIL_FROM = process.env.EMAIL_FROM || ''; // e.g. reminders@yourdomain.com (verified in Resend)
const EMAIL_MODE = RESEND_API_KEY && EMAIL_FROM ? 'resend' : 'dev-outbox';
const STORE_FILE = process.env.STORE_FILE || path.join(__dirname, 'data', 'server-store.json');
const CONFIG_FILE = process.env.CONFIG_FILE || path.join(__dirname, 'config.json');

// config.json is re-read on every request, so pasting a new link needs no restart.
// Only public links live here (a payment link is meant to be shared); never put secret keys in it.
function readConfig() {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { /* missing or invalid: treat as empty */ }
  const httpsUrl = (v) => {
    try { const u = new URL(String(v || '').trim()); return u.protocol === 'https:' ? u.href : ''; } catch { return ''; }
  };
  const supportEmail = /^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/.test(String(c.SUPPORT_EMAIL || '').trim()) ? String(c.SUPPORT_EMAIL).trim() : '';
  return { paymentLink: httpsUrl(c.PAYMENT_LINK), manageLink: httpsUrl(c.MANAGE_LINK), supportEmail };
}

// ---------- tiny JSON store (claims, dev outbox) ----------
let store = { claims: {}, outbox: [] };
try { store = { ...store, ...JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')) }; } catch { /* first run */ }
function save() {
  fs.mkdirSync(path.dirname(STORE_FILE), { recursive: true });
  fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2));
}

// ---------- helpers ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const isEmail = (s) => typeof s === 'string' && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(s) && s.length < 255;
const isToken = (s) => typeof s === 'string' && /^[a-f0-9]{32}$/.test(s);

function send(res, status, body, type = 'text/html; charset=utf-8', extra = {}) {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', ...extra });
  res.end(body);
}
const json = (res, status, obj) => send(res, status, JSON.stringify(obj), 'application/json; charset=utf-8');

function readBody(req, limit = 2_000_000) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function originOf(req) {
  const proto = req.headers['x-forwarded-proto'] || 'http';
  return `${proto}://${req.headers.host}`;
}

// Very small per-IP rate limit for email sending (the send endpoint has no server-side login).
const sendLog = new Map();
function rateLimited(ip, max = 60, windowMs = 60 * 60 * 1000) {
  const now = Date.now();
  const list = (sendLog.get(ip) || []).filter((t) => now - t < windowMs);
  if (list.length >= max) { sendLog.set(ip, list); return true; }
  list.push(now); sendLog.set(ip, list); return false;
}

function page(title, inner) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title><style>
:root{--bg:#f6f7f9;--card:#fff;--text:#1a1d21;--muted:#5d6570;--accent:#1f6feb;--line:#dde1e6}
@media (prefers-color-scheme: dark){:root{--bg:#121417;--card:#1c1f24;--text:#eceff3;--muted:#9aa3ad;--accent:#5a9bff;--line:#30353c}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
main{max-width:560px;margin:0 auto;padding:24px 16px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:20px;margin-bottom:16px;overflow-wrap:anywhere}
h1{font-size:1.35rem;margin:0 0 12px}p{margin:0 0 12px}.muted{color:var(--muted);font-size:.9rem}
button,.btn{display:inline-block;background:var(--accent);color:#fff;border:0;border-radius:8px;padding:12px 18px;font:inherit;font-weight:600;cursor:pointer;text-decoration:none;min-height:44px}
.btn.secondary{background:transparent;color:var(--accent);border:1px solid var(--line)}a{color:var(--accent)}
iframe{width:100%;min-height:360px;border:1px solid var(--line);border-radius:8px;background:#fff}
</style></head><body><main>${inner}</main></body></html>`;
}

// ---------- email ----------
function linkify(escapedText) {
  return escapedText.replace(/https?:\/\/[^\s<]+/g, (u) => `<a href="${u}">${u}</a>`);
}

function renderEmail({ body, claimUrl, footer }) {
  const text = [body, claimUrl ? `\nAlready paid? Let us know so the reminders stop: ${claimUrl}` : '', footer ? `\n--\nSent with ${APP_NAME}` : ''].join('');
  const html = `<div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;font-size:16px;line-height:1.5;color:#1a1d21;max-width:560px">
<p>${linkify(esc(body)).replace(/\n/g, '<br>')}</p>
${claimUrl ? `<p style="margin-top:24px;padding-top:12px;border-top:1px solid #dde1e6">Already paid? <a data-claim href="${esc(claimUrl)}">Let us know so the reminders stop</a>.</p>` : ''}
${footer ? `<p style="color:#5d6570;font-size:13px">Sent with ${APP_NAME}</p>` : ''}</div>`;
  return { text, html };
}

async function deliver({ to, replyTo, fromName, subject, text, html, attachment, kind, meta }) {
  if (EMAIL_MODE === 'resend') {
    const payload = {
      from: `${String(fromName || APP_NAME).replace(/[<>"\r\n]/g, '').slice(0, 80)} <${EMAIL_FROM}>`,
      to: [to], subject, html, text,
    };
    if (replyTo) payload.reply_to = replyTo;
    if (attachment) payload.attachments = [{ filename: attachment.filename, content: attachment.contentBase64 }];
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.message || `Email provider error ${r.status}`);
    return { id: data.id, mode: 'resend' };
  }
  const id = crypto.randomUUID();
  store.outbox.unshift({
    id, at: new Date().toISOString(), kind, to, replyTo, fromName, subject, text, html,
    attachment: attachment ? { filename: attachment.filename, contentBase64: attachment.contentBase64 } : null, meta,
  });
  store.outbox = store.outbox.slice(0, 500);
  save();
  return { id, mode: 'dev-outbox' };
}

// ---------- routes ----------
async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const ip = req.socket.remoteAddress || '';

  if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
    return send(res, 200, fs.readFileSync(path.join(__dirname, 'public', 'index.html')), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  }
  if (req.method === 'GET' && p === '/sample-invoices.csv') {
    return send(res, 200, fs.readFileSync(path.join(__dirname, 'sample-invoices.csv')), 'text/csv; charset=utf-8');
  }
  if (req.method === 'GET' && p === '/favicon.ico') return send(res, 204, '', 'image/x-icon');
  if (req.method === 'GET' && p === '/api/config') {
    return json(res, 200, { emailMode: EMAIL_MODE, appName: APP_NAME, ...readConfig() });
  }
  if (req.method === 'GET' && (p === '/welcome.html' || p === '/welcome')) {
    return send(res, 200, fs.readFileSync(path.join(__dirname, 'public', 'welcome.html')), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  }

  // Send a reminder (or any app email). Body is plain text written by the user's templates.
  if (req.method === 'POST' && p === '/api/send-email') {
    if (rateLimited(ip)) return json(res, 429, { error: 'Too many emails from this connection. Try again later.' });
    let b;
    try { b = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: 'Bad request' }); }
    if (!isEmail(b.to)) return json(res, 400, { error: 'Client email address looks wrong.' });
    if (b.replyTo && !isEmail(b.replyTo)) return json(res, 400, { error: 'Reply-to email looks wrong.' });
    const subject = String(b.subject || '').replace(/[\r\n]+/g, ' ').slice(0, 200);
    const body = String(b.body || '').slice(0, 10_000);
    if (!subject || !body) return json(res, 400, { error: 'Subject and message are required.' });
    let claimUrl = '';
    if (b.claimToken) {
      if (!isToken(b.claimToken) || !isEmail(b.notifyEmail)) return json(res, 400, { error: 'Bad claim token.' });
      const existing = store.claims[b.claimToken];
      store.claims[b.claimToken] = {
        notifyEmail: b.notifyEmail,
        label: String(b.invoiceLabel || '').slice(0, 200),
        businessName: String(b.fromName || '').slice(0, 100),
        claimedAt: existing?.claimedAt || null,
      };
      save();
      claimUrl = `${originOf(req)}/paid/${b.claimToken}`;
    }
    let attachment = null;
    if (b.attachment) {
      const { filename, contentBase64 } = b.attachment;
      if (typeof filename !== 'string' || typeof contentBase64 !== 'string' || contentBase64.length > 1_400_000) {
        return json(res, 400, { error: 'Attachment too large (1 MB max).' });
      }
      attachment = { filename: filename.replace(/[^\w.\- ]/g, '_').slice(0, 100), contentBase64 };
    }
    const { text, html } = renderEmail({ body, claimUrl, footer: b.footer !== false });
    try {
      const r = await deliver({ to: b.to, replyTo: b.replyTo, fromName: b.fromName, subject, text, html, attachment, kind: 'reminder', meta: { claimUrl } });
      return json(res, 200, { ok: true, ...r });
    } catch (e) {
      return json(res, 502, { error: e.message });
    }
  }

  // Which of my invoices have clients said they've paid?
  if (req.method === 'GET' && p === '/api/claims') {
    const tokens = (url.searchParams.get('tokens') || '').split(',').filter(isToken).slice(0, 500);
    const out = {};
    for (const t of tokens) if (store.claims[t]?.claimedAt) out[t] = { claimedAt: store.claims[t].claimedAt };
    return json(res, 200, out);
  }

  // Client-facing "Already paid?" page. GET shows a confirm button (so email link-scanners
  // that pre-open links can't pause reminders by themselves); POST records it.
  const claimMatch = p.match(/^\/paid\/([a-f0-9]{32})$/);
  if (claimMatch) {
    const token = claimMatch[1];
    const c = store.claims[token];
    if (!c) return send(res, 404, page('Link not found', `<div class="card"><h1>This link isn't valid</h1><p>It may have expired. Please reply to the reminder email instead.</p></div>`));
    const who = esc(c.businessName || 'the business');
    if (req.method === 'GET') {
      if (c.claimedAt) return send(res, 200, page('Thanks', `<div class="card"><h1>Thanks, we've already told ${who}</h1><p>Reminders for ${esc(c.label)} are paused.</p></div>`));
      return send(res, 200, page('Already paid?', `<div class="card"><h1>Already paid?</h1>
<p>Tell ${who} you've paid <strong>${esc(c.label)}</strong> and the reminders will stop.</p>
<form method="post"><button type="submit" id="confirm-paid">Yes, I've paid</button></form>
<p class="muted" style="margin-top:16px">If you haven't paid yet, you can ignore this page.</p></div>`));
    }
    if (req.method === 'POST') {
      if (!c.claimedAt) {
        c.claimedAt = new Date().toISOString();
        save();
        const body = `Your client says they've paid ${c.label}.\n\nReminders for this invoice are paused. Open ${APP_NAME} to check your bank and mark it as paid, or resume the reminders if the money hasn't arrived.`;
        const { text, html } = renderEmail({ body, footer: false });
        deliver({ to: c.notifyEmail, fromName: APP_NAME, subject: `Client says paid: ${c.label}`, text, html, kind: 'notification', meta: { token } })
          .catch((e) => console.error('notify failed', e.message));
      }
      return send(res, 200, page('Thanks', `<div class="card"><h1 id="claim-thanks">Thanks, we've told ${who}</h1><p>The reminders for ${esc(c.label)} are paused while they check their account.</p></div>`));
    }
  }

  // ---------- dev outbox (only when no real email provider) ----------
  if (EMAIL_MODE === 'dev-outbox') {
    if (req.method === 'GET' && p === '/api/outbox') return json(res, 200, store.outbox);
    if (req.method === 'GET' && p === '/outbox') {
      const rows = store.outbox.map((m) => `<div class="card"><p class="muted">${esc(new Date(m.at).toLocaleString())} · ${esc(m.kind)}</p>
<p><strong>${esc(m.subject)}</strong></p><p class="muted">To ${esc(m.to)}${m.replyTo ? ` · Reply-to ${esc(m.replyTo)}` : ''}${m.attachment ? ` · 📎 ${esc(m.attachment.filename)}` : ''}</p>
<a href="/outbox/${esc(m.id)}">Open</a></div>`).join('') || '<div class="card"><p>No emails yet.</p></div>';
      return send(res, 200, page('Dev outbox', `<h1>Dev outbox</h1><p class="muted">Emails land here instead of being sent, because RESEND_API_KEY and EMAIL_FROM aren't set.</p>${rows}`));
    }
    const m1 = p.match(/^\/outbox\/([\w-]+)$/);
    if (req.method === 'GET' && m1) {
      const m = store.outbox.find((x) => x.id === m1[1]);
      if (!m) return send(res, 404, page('Not found', '<p>Not found</p>'));
      return send(res, 200, page(m.subject, `<p><a href="/outbox">← Outbox</a></p><div class="card">
<p><strong>${esc(m.subject)}</strong></p><p class="muted">From ${esc(m.fromName)} · To ${esc(m.to)}${m.replyTo ? ` · Reply-to ${esc(m.replyTo)}` : ''}</p>
${m.attachment ? `<p>📎 <a download="${esc(m.attachment.filename)}" href="data:application/pdf;base64,${esc(m.attachment.contentBase64)}">${esc(m.attachment.filename)}</a></p>` : ''}
<div class="email-body">${m.html}</div></div>`));
    }
  }

  send(res, 404, page('Not found', '<div class="card"><h1>Not found</h1><p><a href="/">Go to the app</a></p></div>'));
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => { console.error(e); if (!res.headersSent) json(res, 500, { error: 'Server error' }); });
});
if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`${APP_NAME} on http://localhost:${PORT}  (email: ${EMAIL_MODE}, payment link: ${readConfig().paymentLink || 'NOT SET, add PAYMENT_LINK to config.json'})`);
    if (EMAIL_MODE === 'dev-outbox') console.log(`Emails go to http://localhost:${PORT}/outbox`);
  });
}
module.exports = { server };
