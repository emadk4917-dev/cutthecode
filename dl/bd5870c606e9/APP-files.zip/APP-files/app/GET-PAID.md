# GET PAID: connecting a $19/month payment link

The app has no payment code and no secret keys. Payments work like this:

1. A visitor clicks **Start your plan**. It opens whatever link is in `config.json` → `PAYMENT_LINK`.
2. They pay on Stripe's or Whop's own checkout page.
3. The provider sends them to `https://YOUR-DOMAIN/welcome.html`, which turns on paid features in their browser.

```json
{
  "PAYMENT_LINK": "https://buy.stripe.com/...   or   https://whop.com/...",
  "MANAGE_LINK": "",
  "SUPPORT_EMAIL": "you@yourbusiness.com"
}
```
- `PAYMENT_LINK` must start with `https://`. Anything else is ignored and the button stays disabled.
- `MANAGE_LINK` (optional) is where paying users go to manage or cancel. If it's blank, Billing tells them to email `SUPPORT_EMAIL`.
- The server re-reads `config.json` on every request, so you don't need to restart after editing it.
- A payment link is meant to be public. **Never** put a secret key (`sk_…`, `rk_…`, `whsec_…`) in this file.

Menus and button names below are from memory and these dashboards change. If something isn't where this says, search the provider's help pages for the term in **bold**.

---

## A. Stripe: create a $19/month Payment Link in test mode

1. Sign in to the Stripe Dashboard and switch on **Test mode** (or a **sandbox**, if your account uses those). Everything below must be done there first.
2. Go to **Payment Links** and click **Create payment link** (or **+ New**).
3. Add a product:
   - Name: `Invoice Chaser Paid`
   - Price: `19.00`, currency USD (or your own currency; the app's page says "$19").
   - Billing: **Recurring**, period **Monthly**.
4. Find the **After payment** setting and choose **Don't show confirmation page** / **Redirect customers to your website**. Enter:
   `https://YOUR-DOMAIN/welcome.html`
   - Testing on your own computer? Try `http://localhost:3000/welcome.html`. If Stripe won't accept a localhost or `http://` address, deploy the app somewhere with https first and use that.
5. Optional settings, which are your call: collect the customer's email (helps you match payments to people), allow promotion codes, collect a billing address or tax ID.
6. Create the link and copy its URL. A test-mode link typically starts with `https://buy.stripe.com/test_`.
7. Paste it into `config.json` as `PAYMENT_LINK`.

**Letting customers cancel without emailing you (optional):** Stripe has a hosted **customer portal** that subscribers can use to cancel. Look for **Customer portal** in Billing settings. If it gives you a shareable login link, paste that into `MANAGE_LINK`.

## B. Whop: create a $19/month plan

1. In your Whop seller dashboard, create (or open) a product, e.g. `Invoice Chaser Paid`.
2. Add a **pricing plan**: **Recurring / subscription**, `$19`, billed **monthly**.
3. Look for a **redirect URL** / **after-checkout URL** setting on the plan or checkout link, and set it to `https://YOUR-DOMAIN/welcome.html`.
   - I'm not certain where Whop puts this or whether every plan type supports it. Check Whop's help docs for **"redirect after checkout"**. If there's no redirect option, put the welcome page address in the product's description or post-purchase message so buyers know to open it.
4. Copy the plan's **checkout link** and paste it into `config.json` as `PAYMENT_LINK`.
5. Check whether Whop has a **test mode** or test-payment option before taking real money. If it doesn't, a cheap real purchase that you refund is the fallback. Check Whop's docs for how refunds and fees work on that.
6. Subscribers usually manage Whop memberships from their own Whop account. Check Whop's docs for the right link to put in `MANAGE_LINK`.

---

## C. Test it end to end with Stripe's test card

1. Run the app: `node server.js`, then open http://localhost:3000.
2. Sign up with any email, then go to **Billing**. You should see **Pricing**, then click **Start your plan**.
3. The Stripe page should say it's in test mode. Pay with:
   - Card number `4242 4242 4242 4242`
   - Any future expiry date, any 3-digit CVC, any name and postcode.
4. You should land on **welcome.html**, which says "Paid features are now on for <your email>".
5. Click **Open Invoice Chaser** and go to **Billing**. It should say **Paid**. Add a 4th unpaid invoice: it should be allowed.
6. In the Stripe Dashboard (still in test mode), check that a **Customer** and a **Subscription** appeared for $19/month.
7. Also test **paying before you have an account**: log out, click **Start your plan** on the sign-up screen, pay, and on welcome.html click **Create your account**. The new account should start on Paid.
8. Stripe lists more test cards (declined, needs 3-D Secure authentication, etc.) under **Testing** in its docs. Try a declined card and check you are **not** sent to welcome.html.

Run `node tests/must-work.mjs` to repeat the automated checks. They use a fake link and never contact Stripe or Whop.

---

## D. Before switching to live mode

**Stripe account and money**
- [ ] Your Stripe account is **activated** for live payments: business details, bank account for payouts, identity verification. The dashboard will show what's missing.
- [ ] **Fees:** look up Stripe's current pricing page for your country. I haven't stated a figure because it varies and changes.
- [ ] **Tax / VAT / sales tax:** whether you must charge it on a $19 software subscription depends on where you and your customers are. Check with an accountant or tax adviser, and look at Stripe's **Tax** settings if you need to collect it.
- [ ] **Statement descriptor** (the name on customers' bank statements) is recognisable. Look in Stripe's public business settings.
- [ ] **Receipts:** check that Stripe's **customer emails** settings send receipts for successful payments.

**The live link**
- [ ] Create the product and Payment Link **again in live mode**. Test-mode products and links don't work for real cards; check Stripe's docs on test vs live mode if unsure.
- [ ] Set the live link's redirect to your **real https** `.../welcome.html` (not localhost).
- [ ] Paste the **live** link into `config.json` on the live server. It should start with `https://buy.stripe.com/` and **not** contain `test_`.
- [ ] Make one real purchase yourself, check it shows up and lands on welcome.html, then refund it from the dashboard.

**Your side**
- [ ] `SUPPORT_EMAIL` is set and you actually read that inbox.
- [ ] You have a way for people to cancel: a `MANAGE_LINK`, or you cancel by hand in the dashboard when they email.
- [ ] You've published **terms**, a **privacy policy** and a **refund policy**. Stripe or Whop may ask for these, and the rules depend on your country. Check, and get advice if you're unsure.
- [ ] Reminder emails really send: `RESEND_API_KEY` and `EMAIL_FROM` are set **as environment variables on the server** (not in any file), and the sending domain is verified with your email provider.
- [ ] You've read the next section and are OK with those limits for now.

---

## E. What this setup doesn't do yet (honestly)

- **It doesn't know who has paid.** The app never hears from Stripe or Whop. Paid features switch on when someone **opens welcome.html**, so anyone who finds or guesses that address gets them free. Someone could also switch them on by editing their browser's storage.
- **It doesn't know when someone cancels or a payment fails.** After a cancellation, the app keeps showing Paid on that device. You'd have to notice in Stripe or Whop and ask the person to switch back, and the app can't enforce it.
- **There's no account link between the payment and the app.** The email used to pay and the email used in the app can be different. The app can't look anyone up.
- **Paid status is per device.** A customer on a phone and a laptop has to open welcome.html on both.
- **Reminders only go out while the app is open in a browser tab** (see TEST-REPORT.md). That's the bigger problem for a product people pay for.

**What fixing it involves (the next version):** store accounts and invoices on the server. Add a **webhook** endpoint that Stripe or Whop calls when someone pays, cancels or fails to pay; it marks that account paid or free. That needs a webhook signing secret, kept in an environment variable and never in the code. Then run the reminder scheduler on the server, so it works with every browser closed. Until then, treat this as "pay to support / honour system" and keep an eye on your dashboard.
