# SPEC: Invoice Chaser (working name)

## 1. Who it's for and the one job it does
For sole-trader and small-crew tradespeople (plumbers, electricians, cleaners) who send invoices and then have to chase late payers themselves.
It does one job: once an invoice is overdue, it sends polite, escalating email reminders on a schedule until the client pays or the tradesperson marks it paid.

## 2. Screens
- **Sign up / Log in**: email and password, nothing else.
- **Invoices (home)**: list of invoices with status (Not due / Overdue / Paid) and the total amount outstanding at the top.
- **Add invoice**: client name, client email, invoice number, amount, due date, payment link or bank details, optional PDF attachment.
- **Invoice detail**: the reminder timeline (sent and scheduled), plus "Send now", "Pause" and "Mark as paid" buttons.
- **Reminder settings**: the schedule (for example 1, 7 and 14 days after the due date), the wording of each reminder, your business name and reply-to email.
- **Billing**: current plan, an Upgrade button (Stripe Checkout), and Cancel.
- **Client "Already paid?" page**: a link in every reminder that the client clicks to tell you they've paid. It pauses reminders and notifies you.

## 3. "Must work" checks (pass/fail in a browser)
1. **Sign up**: a new email and password lands you on an empty Invoices screen, and logging out and back in works.
2. **Add invoice**: add an invoice with a due date in the past and it appears in the list as **Overdue**, with the outstanding total updated.
3. **Reminder arrives**: on that invoice, click "Send now" and an email reaches a real test inbox within a few minutes. It shows your business name, the amount, the due date and a working payment link, and replies go to your email.
4. **Schedule shows**: the invoice detail screen lists the next reminder dates, and they match the schedule set in Reminder settings.
5. **Mark as paid stops it**: mark the invoice paid and its status changes to **Paid**, the scheduled reminders disappear, and no more emails arrive.
6. **Client "Already paid?"**: click the link in the email and you see a confirmation page. The invoice shows "Client says paid" with reminders paused, and you get a notification email.
7. **Free limit and upgrade**: on a free account, the invoice after the free limit is blocked with an upgrade prompt. Paying with a Stripe test card unlocks it right away, and Billing shows the paid plan.
8. **Phone width**: at 375px wide you can add an invoice and mark one paid with no sideways scrolling.

## 4. Pricing
One plan: **$19/month**, cancel anytime, no annual plan in v1.

| | Free | Paid ($19/mo) |
|---|---|---|
| Invoices being chased at once | 3 | Unlimited |
| Reminder schedule | Fixed default | Custom days and number of reminders |
| Reminder wording | Default templates | Edit every template |
| "Sent with [app name]" footer | Yes | Removed |
| "Already paid?" link and Mark as paid | Yes | Yes |

- CHECK: what existing invoice-chasing and accounts-receivable reminder tools charge per month, to confirm $19 is in a sensible range.
- CHECK: whether 3 free invoices is enough to show the value. Look at how many unpaid invoices a typical sole trader has open at once (trade forums, a few customer interviews).
- CHECK: Stripe's fee per transaction in your country, and what's left from $19 after fees and sales tax/VAT.
- CHECK: email sending cost per 1,000 emails from a provider (e.g. Postmark, Resend, SendGrid), to confirm the free tier doesn't cost you much.

## 5. Leave out of version 1
- **SMS reminders** (costs money per message and needs sender registration). CHECK: SMS cost per message and registration rules in your country before adding it.
- **Creating or designing invoices.** v1 chases invoices you already sent from your current tool.
- **Taking payments.** Clients pay through your own link or bank details, so no money passes through the app.
- **Accounting integrations** (QuickBooks, Xero, etc.) and automatic import of invoices.
- **Late fees and interest.** CHECK: the statutory late-payment interest rules where your customers are (e.g. the UK Late Payment of Commercial Debts Act) before offering this.
- **Teams and multiple users**, multiple businesses per account, multiple currencies, and an annual plan.
- **A native mobile app.** The mobile web version is enough.
- **AI-written reminders**, analytics dashboards and reports.
