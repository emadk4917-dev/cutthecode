# TEST REPORT: Invoice Chaser v1 (payment link version)

**Run on:** 2026-11-26, headless Chrome at phone size (375 × 812), via `node tests/must-work.mjs`
**Result:** all checks PASS. Read the notes on 3 and 7: no real email was sent and no real payment was made.
**Screenshots:** `tests/screens/` (all taken at 375px). Raw results: `tests/results.json`.

## Payment link (new)
| # | Check | Result | What was verified |
|---|---|---|---|
| P | Pricing section and "Start your plan" | **PASS** | The pricing section shows $19 / month and the free vs paid table. With `PAYMENT_LINK` empty, the button is disabled and says to set it. With a Stripe Payment Link in `config.json`, the button's link is exactly that URL and clicking it opens it. After switching `config.json` to a Whop link with no restart, the button opens the Whop link. A non-https value (`javascript:…`) is refused. |
| W | welcome.html when the buyer isn't logged in yet | **PASS** | The page says to log in, and logging in puts that account on Paid with a thank-you message. "Switch this device back to Free" works. |
| K | No secret keys in the code | **PASS** | No Stripe secret, restricted or webhook keys, and no hard-coded tokens, in `server.js`, `index.html`, `welcome.html`, `config.json` or `package.json`. |

The links used were fake (`https://buy.stripe.com/test_FAKE_LINK_123` and `https://whop.com/checkout/plan_FAKE123/`). The test browser intercepted them and showed a stub page, so nothing went to Stripe or Whop. To pay with Stripe's test card, follow GET-PAID.md section C with your own test-mode link.

## Must-work checks from SPEC.md
| # | Check | Result | What was verified |
|---|---|---|---|
| 1 | Sign up | **PASS** | New account lands on the empty Invoices screen. Log out works, a wrong password is rejected, and logging back in works. |
| 2 | Add invoice | **PASS** | An invoice due 10 days ago shows Overdue, and the outstanding total shows $250.00. |
| 3 | Reminder arrives | **PASS (local outbox)** | One email to the client, with the business name, amount, due date, a clickable payment link and reply-to set to you. **Not tested:** delivery to a real inbox, which needs `RESEND_API_KEY` and `EMAIL_FROM` set on the server. |
| 4 | Schedule shows | **PASS** | The default schedule shows +1, +7 and +14 days. A custom schedule of 3 and 10 days shows +3 and +10. |
| 5 | Mark as paid stops it | **PASS** | Status becomes Paid and scheduled reminders disappear. 30 days later (fake clock) the paid client got 0 emails, while an unpaid invoice did get its reminder. |
| 6 | Client "Already paid?" | **PASS** | Confirmation page and thank-you. The invoice shows "Client says paid", reminders pause and you get a notification email. |
| 7 | Free limit and upgrade | **PASS (no real payment)** | The 4th unpaid invoice is blocked with the pricing section. "Start your plan" opens the `PAYMENT_LINK`. Landing on welcome.html turns on Paid, Billing shows Paid with the support email for cancelling, and the 4th invoice can be added. |
| 8 | Phone width | **PASS** | 18 screens with no sideways scroll, including pricing, welcome.html and the client page. |
| extra | Sample CSV import | **PASS** | Free plan imports 5 and holds back 3 unpaid invoices with an upgrade note. Paid plan adds the remaining 3 with no duplicates. No reminders are sent for dates that had already passed. |
| extra | Browser console | **PASS** | No JavaScript errors. |

## Fixed in this round
- In the pricing table, "Default" was splitting mid-word at phone width ("Defa / ult"). Seen in a screenshot and fixed.
- Removed the old Stripe API checkout code (secret-key based) and its local stand-in checkout page. Payments now go only through the link in `config.json`.

## Known limits (details in GET-PAID.md, section E)
- **The app doesn't know who has paid.** Anyone who opens `/welcome.html` gets paid features on their device, and it never finds out about cancellations or failed payments.
- **Reminders only send while the app is open in a browser tab.**
- **The email-sending endpoint has no login.** It has a rate limit of 60 emails per hour per connection, but needs server accounts before you set a real email key on a public server.
- **Accounts and invoices live in one browser on one device.**
