# FIRST 10: getting the first 10 paying customers

The plan: get the tradespeople you already know to try it on their own overdue invoices, with you sitting next to them. Give them a free first month, then ask them to pay. Count someone as a customer only once they've paid for month two.

---

## 1. Before you message anyone
Don't start until each of these is true. A broken first session uses up a favour you can't get back.

- [ ] The app is online at an **https** address, not localhost.
- [ ] **Real emails send.** `RESEND_API_KEY` and `EMAIL_FROM` are set on the server, and a reminder has reached your own inbox and doesn't land in spam.
- [ ] `PAYMENT_LINK` is a **live** link and `SUPPORT_EMAIL` is an inbox you read (see GET-PAID.md).
- [ ] You've done the whole flow yourself on your own phone: sign up, add an invoice, Send now, open the email, "Already paid?", Mark as paid.
- [ ] You can explain the limits in one breath (see step 3 of the call). Customers will find them anyway, so it's better they hear it from you.

## 2. Who to contact first
1. Write down every tradesperson you know: plumbers, electricians, cleaners, builders, gardeners, decorators.
2. Put first anyone who has ever **complained to you about chasing payments**. They already have the problem.
3. Message 3–5 at a time, not everyone at once. You want to fix what the first ones run into before the next ones see it.

## 3. The message (56 words)
> Hi [Name], I've built a tool that emails polite reminders to customers who haven't paid an invoice, and stops when they pay. I'm looking for a few local trades to try it and tell me what's wrong with it. Could I show you in 15 minutes this week, using your own overdue invoices? First month free.

- If there's no reply, send **one** follow-up a week later ("No worries if it's not useful, just checking you saw this"), then leave it.
- If they say they don't have late payers, thank them and ask whether they know anyone who does.

## 4. The 15-minute call: in person, on *their* phone
Do it on their phone or laptop, not yours. The app stores invoices in the browser it's used on, and their clients' details shouldn't end up on your device.

**0–3 min: Ask, don't pitch.**
- "How do you chase people who pay late at the moment?"
- "Roughly how many invoices are overdue right now?"

Write down their answers word for word. If the answer is "none", you've found out it's not for them, which is fine.

**3–5 min: Set up.**
- Open the app and sign up with their email.
- **Settings:** fill in their business name. Set reply-to to the email they actually check.

**5–7 min: A safe test first.**
- Add a pretend invoice with **their own email** as the client, due last week.
- Press **Send now** and let them open the email on their phone.
- Show them the "Already paid?" link and what happens when it's clicked.
- Delete the test invoice.

**7–12 min: Their real overdue invoices.**
- Ask: "Shall we add a couple of the real ones?" Let them type the client name, email, amount, due date and payment link or bank details. If their invoicing software exports a CSV, use **Import from CSV** instead.
- Open one invoice and show **Next reminders**: the dates the emails will go out.
- **Ask before anything is sent to a real client.** Offer to read the wording together first. It's their customer relationship. If they'd rather wait, that's fine: the scheduled reminders will go out on their dates.

**12–14 min: Tell them the limits.**
- "Reminders go out when the app is open, so open it once a day. Saving it to your home screen helps."
- "It lives on this phone only. If you clear your browser data, it's gone."
- "It's early. Tell me anything that's confusing or wrong. That's the deal for the free month."

**14–15 min: The offer and the next step.**
- "The first month is free. Around day 25 I'll send you the payment link. If it's helped, it's $19 a month after that. If not, no hard feelings."
- Book a 5-minute check-in for **one week from today**.

## 5. Offering the first month free
**Recommended for people you know: no card up front.**
1. At the end of the call, open `https://YOUR-DOMAIN/welcome.html` on their phone. That turns on the paid features for their account.
2. Put a reminder in your calendar for **day 25**.
3. On day 25, send:
   > Hi [Name], your free month ends on [date]. If Invoice Chaser has been useful, here's the link to carry on at $19/month: [PAYMENT_LINK]. If it hasn't, just tell me why. That helps me more than anything. Either way, thanks for trying it.
4. If they don't pay, ask them (once) to tap **Billing → Switch this device back to Free**. The app can't do this by itself; see GET-PAID.md section E.

**Alternative: a free trial on the payment link itself.** This takes their card now and charges automatically after the trial.
- Stripe: look for a **free trial** option when creating the Payment Link, or in its recurring price settings. Check Stripe's docs for how it works on Payment Links.
- Whop: check whether your plan type supports a **free trial**.
- If you use this, tell them the **exact date** they'll be charged and how to cancel. Send a reminder a few days before.

## 6. Keep a simple tracker
| Name | Trade | Call date | Overdue invoices added | Reminders sent | Any paid after a reminder? | Day-25 message sent | Paid month 2? | What they said |
|---|---|---|---|---|---|---|---|---|

The last column matters most. After 3–5 people, read it and fix the most common problem before you message the next batch.

## 7. From the first few to 10
- When someone tells you it helped, ask: **"Who else do you know who chases invoices?"** Ask them to introduce you by message rather than give you a number.
- When someone doesn't pay, ask why, and write down their exact words. Don't try to talk them round.
- Fix the things people trip over between batches. Tell the earlier users when something they reported is fixed.
- Expect some people to say no or go quiet. That's normal. Keep going through your list and the referrals.

## 8. Rules for yourself
- **No income claims.** Don't say "you'll get paid faster" or "you'll recover $X". Say what it does: it sends polite reminders on a schedule and stops when they pay.
- **No fake urgency.** No "only 3 spots left" or "price goes up Friday". The free month is open to anyone you approach.
- **Nothing goes to their clients without their OK.**
- **Their clients' details stay on their device.** Don't copy them to your phone, your notes or screenshots.
- **Be honest about the limits** in section 4 every time, even when it might cost you the sale.
