# Pricing review: Cut The Code live offers

*Source: offers.md (copied from cutthecode.co.uk on 26 Nov 2026). Method: the `pricing` skill (value-based pricing, ladder and anchoring, rollout on new buyers first).*

## Before you read this

- **No sales data.** offers.md has prices and copy only. It has no conversion rates, units sold or refund rates, and the site says it's Day 5. Everything below is my judgement from how the offers are built, not from numbers. Treat each change as a test on new buyers.
- **The skill is written for SaaS.** It says services, courses and high-ticket offers belong to a separate `offers` skill, and that skill isn't installed. I used the general parts (value-based pricing, anchoring, recurring revenue, rollout) and ignored the SaaS-only parts (seats, usage metrics, annual toggles).

## What's on sale today

| Offer | Price | Type |
|---|---|---|
| 7 free tools (prompt pack, build plan, video skill, content machine guide/map, clipping guide, free twins list) | £0 | Lead magnets |
| Quickstart | £27 | One-off |
| Agency Kit | £67, or £40 on the one-time offer page after buying the Quickstart | One-off |
| Clipping Agent Kit / Content Machine Kit | £27 / £46 | One-off, one line under the pricing grid |
| 1:1 build call | £197 for 60 min | Service |
| Done-For-You content machine setup | £497 | Service |
| Local business website | £497 (£249 deposit + £248 on approval) | Service |
| Website care plan | £49/month, "optional, later" | **The only recurring revenue** |

---

## The 3 changes most likely to raise revenue

### 1. Offer the £49/month care plan when the client approves the site, not "later"

**Change:** At the approval and go-live step (when they pay the £248), show the care plan as the default choice with a clear opt-out. For example: "Keep it up to date: £49/month, cancel any time, first month included." Remove the word "later" from the /websites page.

**Why:**
- It's the only recurring revenue in the business. A client who stays 12 months pays £588, which is more than the £497 build. One care-plan client is worth more than a second website sale.
- Approval is when they trust you most. They've just seen the preview, asked for changes and said yes. Asking "later" means a cold follow-up weeks afterwards, when most people won't reply.
- It's what you teach. The Agency Kit tells students to sell "delivery and monthly care". Your own website offer should do the same.
- The skill's main rule is to price on value delivered over time, not one-off cost. Edits, updates and keeping the Google listing current are ongoing value, and right now nobody is asked to pay for them.

**Test:** Track what share of approved sites take the plan. If it's under about 30%, try a 3-month prepay (£147) as the default instead.

### 2. Give the content-machine leads their own paid next step

**Change:** Copy the /upgrade pattern, which already exists for Quickstart buyers, to the content funnel. After someone signs up for the Content Machine Setup, Content Machine Map, Clipping Setup or video skill, show a thank-you-page offer: **Content Machine Kit + Clipping Agent Kit, £73 → £47, this page only.** Move both kits out of the "Also on Whop" footnote and into the pricing grid.

**Why:**
- 4 of the 7 free tools are about content machines and clipping, and the homepage leads with the "6 AI employees" story. Most of your lead flow is probably interested in content. But the only paid follow-up after a signup is the website and agency path (Quickstart → Agency Kit). The two content products sit in a single line of small print.
- Someone who just downloaded a content-machine guide is most likely to buy the content-machine kit straight away. Selling them a website course is a mismatch.
- You already have a one-time offer page with a struck-through anchor price. Building a second one is little work.
- Bundling both kits gives these leads a larger first purchase than either kit alone. If £47 sells well, they're a natural audience for the £497+ Done-For-You service in change 3.

### 3. Raise Done-For-You to £997 for new buyers, and make it the top step of the content path

**Change:** Price the Done-For-You content machine setup at **£997** for new buyers. Present it as the top step of the content path (free guide → kits → DFY), not as "Step 4" after the website path.

**Why:**
- It's underpriced against your own offers. A 60-minute call is £197. DFY means brand, voice, first videos and auto-posting, "handed over working", which is many hours of custom work, but it costs only 2.5x the call. It's also the same £497 as a local-business website, which is a simpler build.
- Value-based pricing sets the ceiling at what the buyer gets. For DFY that's an automated content system they don't have to build themselves. That's not a £497 purchase for a business owner. The skill also warns against pricing low to "reduce friction": cheap DFY buyers tend to ask for the most support.
- A higher top price works as an anchor. At £997, the £197 call and £46 kit look like obvious first steps, which should help those offers convert too.
- It also fixes a ladder that doesn't connect. Steps 1–3 teach people to sell websites, then Step 4 is a different product. Two clear ladders (website/agency and content) are easier to choose from.

**Rollout (following the skill):** New buyers only. Nobody has paid the old price yet, so there's no one to protect. If two or three enquiries in a row accept £997 easily, that suggests it's still low. If nobody books after real traffic, drop to £797 rather than going back to £497.

---

## What I'd leave alone: the website price and deposit setup

**£497 total, £249 deposit, £248 on approval, deposit refunded if they don't like the preview.**

- The deposit and refund are what get a cold local business owner to pay a stranger online. Their risk is 2 minutes and a refundable £249, and they see the work before paying the rest. Changing this would put conversion at risk to fix something that isn't broken.
- There's no data saying the price is wrong. Change 1 adds lifetime value through the care plan without touching the number they see on day one.
- £497 also fits the "typical UK market rates" the Agency Kit teaches. If you priced your own websites very differently, the course would look less credible.

Look at the website price again after roughly 10 sales. If nearly everyone pays the deposit without asking about price, test £597 on new enquiries.

---

*None of the above is a promise of revenue. They're the changes I'd test first, with no sales data yet.*
