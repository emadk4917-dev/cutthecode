# CRO fixes: websites.html (£497 done-for-you website)

**Page type:** Service landing page. Traffic is mostly social (TikTok / IG / YouTube), so mostly on phones.
**Current goal on the page:** Pay a £249 deposit. That is the only action.
**Your goal:** More enquiries.

That gap is the main problem. A cold visitor from a reel has two options: hand over £249 to someone they found 30 seconds ago, or leave. Most leave. The three fixes below are ranked by how many enquiries I expect each to win. All three are applied in `websites-v2.html`.

---

## 1. Give people a way to enquire without paying (highest impact)

**Problem:** There is no form, no phone number, no WhatsApp and no email anywhere on the page. The only contact line is in the footer, and it's a leftover from the lead-magnet page that tells cold visitors to reply to an email they never received:

- **Line 183:** `<p class="ctc-legal">© 2026 Cut The Code · Questions? Reply to the email we sent you.</p>`

Anyone with a single question ("can you use my existing domain?", "do you do electricians?") has nowhere to ask it. At £497 most local business owners want to talk to someone before they pay.

**Change:**
- **After line 157** (the "£497 in full" note in the hero card), add a collapsed *"Not ready to pay? Ask us a question first"* panel with 3 fields: name, phone or email, and business, town and question. Collapsed by default, so the deposit button stays the main action.
- **Line 183:** change to `Questions? <a href="#ask">Ask us here</a>, no payment needed.`

**Before publishing:** set the form's `action="[REPLACE_FORM_ENDPOINT]"` to your real handler (Formspree, Netlify Forms, ActiveCampaign form, etc.). Until you do, the form won't send anything.

---

## 2. Show real sites you've built (proof)

**Problem:** The page sells a visual product but shows no examples, screenshots, testimonials or review scores. The `.proof` style exists in the CSS (lines 47–48) but nothing uses it. "Show me one you've made" is the first thing a tradesperson will ask, and right now the page can't answer it.

**Change:**
- **Between line 160 (end of hero) and line 161 (`<section>` "What you get")**, add a "Sites we've built / See our work before you pay" section: 3 cards, each with a phone screenshot, business name, trade and town, and a link to the live site. Under them goes one attributed customer quote.

**Before publishing:** every `[REPLACE: …]` in that section must be a real client site and a real quote, used with the client's permission. If you only have one or two real examples, delete the extra cards. Don't publish the placeholders and don't make anything up. If you have no client sites yet, a live demo site you built for a made-up business is honest as long as it's labelled "Demo site".

---

## 3. Answer the objections, then ask again at the bottom

**Problem:** The page ends at line 170 with "we can't promise rankings or sales", and then there's nothing: no FAQ and no final button. On phones it's worse. The nav CTA is hidden under 860px (`site.css` line 46) and the hero bullet list is hidden under 900px (line 121), so a visitor who scrolls to the end has no button in view and their doubts are still unanswered. There are FAQ and closing-CTA styles in the CSS (`details`, `.final`, lines 115–119), but nothing uses them.

**Change:**
- **After line 170 (`</section>`), before line 171 (`</div>`)**, add:
  - A 5-question FAQ: What if I don't like the preview? Who owns the domain? Are there monthly fees? What do I need to send? Can you get me to the top of Google? Every answer only repeats something the page already promises (refund, domain in your name, one-off £497 with an optional £49/month care plan, 10 minutes to send details, no ranking promises).
  - A closing block: "Your preview in 48 hours", the deposit button again, and a secondary link "Or ask us a question first, no payment needed" that jumps to and opens the form from fix 1.

---

## Runner-ups (not applied)

- **Line 157:** "£497 in full" links to `https://whop.com/cutthecode/`, which is the store homepage, not a checkout. Point it at the actual full-payment product.
- **Line 41 / 91 / 112:** the headings use `font-family:Anton`, but Anton is never loaded (line 19 only loads Inter and JetBrains Mono). The H1 falls back to a generic sans-serif. Add `family=Anton&` to the Google Fonts URL.
- **Line 121:** `.points{display:none}` hides the 5-item "what you get" list on mobile, so phone visitors see the payment steps before they see what they're buying. Test showing a 3-item version.
- **Line 6 vs line 7 / 135:** the title says "live in 48 hours" but the description and eyebrow say "48–72 hours". Pick one.

## How to measure

Track 3 numbers for 2–4 weeks before and after: enquiry form submissions, deposit payments, and visits. Low social traffic means you probably can't run a proper A/B test, so compare before and after and keep an eye on deposits. The enquiry form should add conversations without taking away deposits.
