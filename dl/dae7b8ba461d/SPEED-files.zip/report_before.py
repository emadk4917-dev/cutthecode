# Top customers report for the shop dashboard. Users say this page is slow.
import time
from db import DB
def top_customers(db):
    rows = []
    for cid, name in db.query('SELECT id, name FROM customers'):
        orders = db.query('SELECT total FROM orders WHERE customer_id = ?', (cid,))
        rows.append((name, len(orders), round(sum(t for (t,) in orders), 2)))
    return sorted(rows, key=lambda r: -r[2])[:5]
if __name__ == '__main__':
    db = DB(); t = time.time(); top = top_customers(db)
    for r in top: print(r)
    print(f'{time.time() - t:.2f}s, {db.queries} database calls')
