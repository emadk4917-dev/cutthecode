# made-up sample data: 100 customers, 2,000 orders (random, seeded)
import random, sqlite3
random.seed(7); db = sqlite3.connect('shop.db'); c = db.cursor()
c.executescript('DROP TABLE IF EXISTS customers; DROP TABLE IF EXISTS orders;'
                'CREATE TABLE customers(id INTEGER PRIMARY KEY, name TEXT);'
                'CREATE TABLE orders(id INTEGER PRIMARY KEY, customer_id INTEGER, total REAL);')
names = ['Ava', 'Ben', 'Cara', 'Dev', 'Ella', 'Finn', 'Gita', 'Hugo', 'Isla', 'Jack']
for i in range(1, 101): c.execute('INSERT INTO customers VALUES (?,?)', (i, f'{random.choice(names)} {i}'))
for i in range(1, 2001): c.execute('INSERT INTO orders VALUES (?,?,?)', (i, random.randint(1, 100), round(random.uniform(5, 120), 2)))
db.commit(); print('shop.db: 100 customers, 2000 orders')
