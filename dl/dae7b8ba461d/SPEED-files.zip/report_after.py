# Top customers report for the shop dashboard. Users say this page is slow.
import time
from db import DB
def top_customers(db):
    # One round trip: aggregate per customer in the database instead of one query per customer (N+1).
    rows = db.query('SELECT c.name, COUNT(o.id), COALESCE(SUM(o.total), 0) '
                    'FROM customers c LEFT JOIN orders o ON o.customer_id = c.id '
                    'GROUP BY c.id ORDER BY c.id')
    rows = [(name, n, round(total, 2)) for name, n, total in rows]
    return sorted(rows, key=lambda r: -r[2])[:5]
if __name__ == '__main__':
    db = DB(); t = time.time(); top = top_customers(db)
    for r in top: print(r)
    print(f'{time.time() - t:.2f}s, {db.queries} database calls')
