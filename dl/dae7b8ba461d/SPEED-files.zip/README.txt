SPEED sample app (made up, for practice). Cut The Code, 26 Nov 2026.
python3 make_db.py      -> builds shop.db (100 customers, 2,000 random orders)
python3 report_before.py -> the slow version (one query per customer: 101 calls)
python3 report_after.py  -> the version Claude Code wrote (one query)
db.py adds a 20 ms wait to every query to act like a hosted database. Rename report_before.py to report.py and try the prompt yourself.
