# Sample app's database helper. The sleep stands in for the network round trip to a hosted database
# (about 20 ms per query), so the sample behaves like a real web app talking to Postgres in the cloud.
import sqlite3, time
LATENCY = 0.02
class DB:
    def __init__(self, path='shop.db'): self.c = sqlite3.connect(path); self.queries = 0
    def query(self, sql, args=()):
        time.sleep(LATENCY); self.queries += 1
        return self.c.execute(sql, args).fetchall()
