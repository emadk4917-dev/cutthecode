# Bright Nest Cleaning: price list (made-up sample business)

Regular clean, priced by home size:
- 1 bedroom: £55
- 2 bedrooms: £70
- 3 bedrooms: £85
- 4 bedrooms: £100
- Each extra bathroom after the first: +£12

Extras (one-off):
- Inside the oven: £35
- Inside the fridge: £15
- Interior windows: £20
- Ironing, per hour: £18

How often:
- One-off clean: price as above, plus a £25 first-visit deep-clean charge
- Weekly: 15% off the clean (not the extras)
- Fortnightly: 10% off the clean (not the extras)
- Monthly: no discount

Minimum charge per visit: £60.
