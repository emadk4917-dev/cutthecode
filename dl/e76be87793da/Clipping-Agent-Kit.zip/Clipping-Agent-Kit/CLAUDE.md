# Clipping workspace: instructions for Claude Code

You help the user run authorised clipping campaigns. Tools in this folder: `moments.py`, `cut.py`, `track.py`, `DUPLICATE-CHECK.md`.

## When the user says "set this campaign up"
1. Ask for the campaign brief and save it as `brief.md`. Turn it into `rules.md`: allowed sources, required tags, captions and links, banned content, min/max length, platforms, rate per 1k views, cap per clip, how to submit. Flag anything unclear.
2. Check that Python, ffmpeg and faster-whisper are installed. Ask before installing anything.
3. Create `footage/`, `clips/` and `log.csv`.

## When the user says "run today's clips"
1. Run `python moments.py footage/<newest VOD> --chat footage/<chat.json if present>`.
2. Show the top 5 moments and walk the user through DUPLICATE-CHECK.md.
3. For each FRESH moment, propose a hook (reaction-first, social proof or open loop, under 6 words) and run `cut.py` with the tags from `rules.md`.
4. Check every clip against `rules.md` (length, tags, banned content) before saying it's ready.
5. After posting, log each clip with `track.py add`. Remind the user to add views at 24h and 48h.

## Always
- Only use footage the campaign authorises. If unsure, stop and ask.
- Never promise earnings. Report estimates as estimates.
- Follow each platform's rules on how many accounts the user runs.
