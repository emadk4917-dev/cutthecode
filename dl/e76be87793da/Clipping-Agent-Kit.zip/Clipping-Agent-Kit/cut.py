"""Cut a moment into a vertical clip with burned-in word-by-word captions and a hook.

Usage:  python cut.py footage/stream.mp4 m01 --start 754 --end 786 --hook "HE DID NOT SEE THAT COMING"
        [--layout center|stack] [--tags "#gta6 #campaignTag"]
Needs transcript.json from moments.py. Output: clips/<id>.mp4 and clips/<id>.txt (caption text).
layout=center: 9:16 crop from the middle. layout=stack: gameplay on top, facecam (top-right corner) below.
"""
import argparse, json, os, subprocess

def ts(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("id"); ap.add_argument("--start", type=float, required=True); ap.add_argument("--end", type=float, required=True)
    ap.add_argument("--hook", default=""); ap.add_argument("--layout", default="center"); ap.add_argument("--tags", default="")
    a = ap.parse_args()
    os.makedirs("clips", exist_ok=True)
    s0 = max(0, a.start - 1)
    words = [w for w in json.load(open("transcript.json")) if s0 <= w[0] < a.end]
    # ASS subtitles: 3 words at a time, bold, centred, middle of the screen
    lines = ["[Script Info]", "PlayResX: 1080", "PlayResY: 1920", "", "[V4+ Styles]",
             "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Outline, Shadow, Alignment, MarginV",
             "Style: Cap,Arial Black,78,&H00FFFFFF,&H00000000,&H64000000,1,6,0,5,0",
             "Style: Hook,Arial Black,70,&H0066D1FF,&H00000000,&H64000000,1,6,0,8,260", "", "[Events]",
             "Format: Layer, Start, End, Style, Text"]
    if a.hook:
        lines.append(f"Dialogue: 0,{ts(0)},{ts(1.6)},Hook,{a.hook.upper()}")
    for i in range(0, len(words), 3):
        chunk = words[i:i + 3]; st = chunk[0][0] - s0; en = (words[i + 3][0] if i + 3 < len(words) else chunk[-1][1]) - s0
        lines.append(f"Dialogue: 0,{ts(st)},{ts(en)},Cap,{' '.join(w[2] for w in chunk).upper()}")
    ass = f"clips/{a.id}.ass"; open(ass, "w", encoding="utf-8").write("\n".join(lines))
    if a.layout == "stack":
        vf = ("[0:v]split[g][f];[g]crop=ih*9/16*1.8:ih,scale=1080:-2,crop=1080:1150[top];"
              "[f]crop=iw*0.25:ih*0.3:iw*0.75:0,scale=1080:770[bot];[top][bot]vstack,ass=" + ass.replace("\\", "/"))
        cmd = ["ffmpeg", "-y", "-ss", str(s0), "-to", str(a.end), "-i", a.video, "-filter_complex", vf]
    else:
        vf = f"crop=ih*9/16:ih,scale=1080:1920,ass={ass}"
        cmd = ["ffmpeg", "-y", "-ss", str(s0), "-to", str(a.end), "-i", a.video, "-vf", vf]
    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "20", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", f"clips/{a.id}.mp4"]
    subprocess.run(cmd, check=True)
    open(f"clips/{a.id}.txt", "w", encoding="utf-8").write(f"{a.hook}\n\n{a.tags}\n")
    print(f"saved clips/{a.id}.mp4")

if __name__ == "__main__":
    main()
