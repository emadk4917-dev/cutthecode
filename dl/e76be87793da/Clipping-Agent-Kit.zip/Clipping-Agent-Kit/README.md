# Clipping Agent Kit: the working scripts behind the Claude Clipping Setup

The free guide gives you the prompts. This kit gives you **the finished tools**, tested and ready to run, so you skip the hours of getting Claude to build them.

> Honest bit: clipping pays through **authorised campaigns** only (they give you the footage or the permission). Rates vary by campaign (roughly $0.20–$6 per 1,000 approved views, typically about $1), payouts are capped, budgets run out, and most clips earn little. This kit saves you time; it doesn't promise earnings.

## What's inside
| File | What it does |
|---|---|
| `moments.py` | Scans a stream VOD (+ chat log if you have one) and scores every 30-second window on chat spike, loudness peak and hype words. Gives you `moments.csv` with the top 15 and `transcript.json`. |
| `cut.py` | Turns a moment into a 1080×1920 vertical clip: centre crop or gameplay + facecam stack, **word-by-word captions** burned in, and your hook text for the first 1.6s. Writes the caption file too. |
| `track.py` | Logs every post, views at 24h and 48h, and the expected payout at your campaign's rate and cap. |
| `DUPLICATE-CHECK.md` | The exact Claude prompt and routine to make sure a moment isn't already posted 3+ times before you cut it. |
| `CLAUDE.md` | Drop this in your folder and Claude Code knows the whole workflow. Just say "run today's clips". |

## Setup (about 15 minutes)
1. Install **Python 3.10+** and **ffmpeg**.
2. `pip install faster-whisper numpy`
3. Make a folder per campaign: `campaigns/gta6-xyz/` with `footage/`, and put these files in it.
4. Open the folder in **Claude Code** and paste: *"Read CLAUDE.md and set this campaign up."*

## Daily routine (about 45 minutes)
```
python moments.py footage/stream.mp4 --chat footage/chat.json      # 1. find the hype
# 2. duplicate check: follow DUPLICATE-CHECK.md for the top 5
python cut.py footage/stream.mp4 m01 --start 754 --end 786 --hook "HE DID NOT SEE THAT COMING" --tags "#gta6 #yourCampaignTag"
python track.py add m01 tiktok @youraccount https://...                # after posting
python track.py views m01 tiktok 41200 --at 48                          # 48h later
python track.py report --rate 1.00 --cap 100                            # what you're owed (estimate)
```

## Hooks that work for clips
- Reaction first: "He did NOT expect that…"
- Social proof: "Chat lost it when…"
- Open loop: "Wait for it…" (payoff in the last 2 seconds)
- Put the most extreme frame first. No intros.

Questions: reply to the email you got this from, or DM "HELP" to @cuthecode.
