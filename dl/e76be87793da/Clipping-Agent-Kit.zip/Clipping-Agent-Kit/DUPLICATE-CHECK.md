# Duplicate check: don't post what's already been posted

Run this for your top 5 moments before cutting anything.

**1. Paste into Claude Code:**
```
Read moments.csv. For the top 5 moments, write 3 search phrases each that a viewer
would type to find that moment (streamer name + the key quote or event). Output a table:
moment id, phrase 1, phrase 2, phrase 3.
```

**2. Search each phrase** on TikTok and YouTube Shorts, filtered to the last 48 hours. Copy the titles, captions and view counts of the matching results into a file called `found.md`, under each moment id.

**3. Paste into Claude Code:**
```
Compare found.md against moments.csv. Mark each moment FRESH (0 matches),
POSTED ONCE, or POSTED 3+ (skip). For POSTED ONCE, suggest a different angle/hook
we could use. Update moments.csv with a "status" column.
```

**Rules:** keep FRESH moments, plus POSTED ONCE only if your angle is clearly different. Never repost someone else's edit. Cut your own from the authorised footage.
