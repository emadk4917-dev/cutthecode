"""Find the most-hyped moments in a stream VOD.

Usage:  python moments.py footage/stream.mp4 [--chat footage/chat.json] [--window 30] [--top 15]
Output: moments.csv (start, end, score, hype words, transcript snippet) + transcript.json

Score per window = 0.45 * chat spike + 0.35 * loudness peak + 0.20 * hype words (each 0-1).
Chat JSON: a list of {"t": seconds, "msg": "..."} (most chat-export tools can give you this).
Only use footage you're authorised to clip.
"""
import argparse, csv, json, math, os, subprocess, sys, wave
import numpy as np

HYPE = ["clip", "no way", "lmao", "lol", "insane", "crazy", "w ", "omg", "what", "bro", "nah", "let's go", "lets go", "oh my"]

def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def loudness(path):
    tmp = "_audio.wav"
    run(["ffmpeg", "-y", "-i", path, "-ac", "1", "-ar", "16000", tmp])
    w = wave.open(tmp); sr = w.getframerate()
    a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768; w.close()
    n = len(a) // sr
    rms = np.sqrt(np.mean(a[: n * sr].reshape(n, sr) ** 2, axis=1) + 1e-12)
    return tmp, 20 * np.log10(rms + 1e-9)  # dB per second

def transcribe(wav):
    from faster_whisper import WhisperModel
    m = WhisperModel("small", device="cpu", compute_type="int8")
    segs, _ = m.transcribe(wav, word_timestamps=True, vad_filter=True)
    return [(w.start, w.end, w.word.strip()) for s in segs for w in s.words]

def norm(x):
    x = np.asarray(x, float)
    if x.max() - x.min() < 1e-9: return np.zeros_like(x)
    return (x - x.min()) / (x.max() - x.min())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("--chat"); ap.add_argument("--window", type=int, default=30); ap.add_argument("--top", type=int, default=15)
    a = ap.parse_args()
    wav, db = loudness(a.video)
    print("transcribing (this takes a while for long VODs)...", file=sys.stderr)
    words = transcribe(wav); os.remove(wav)
    json.dump(words, open("transcript.json", "w"))
    dur = len(db); W = a.window; n = max(1, dur // W)
    loud = [np.percentile(db[i * W:(i + 1) * W], 90) for i in range(n)]
    hype = [0] * n; text = [""] * n
    for s, e, w in words:
        i = min(n - 1, int(s // W)); text[i] += w + " "
    for i, t in enumerate(text):
        tl = t.lower(); hype[i] = sum(tl.count(h) for h in HYPE)
    chat = [0] * n
    if a.chat and os.path.exists(a.chat):
        for m in json.load(open(a.chat, encoding="utf-8")):
            i = min(n - 1, int(float(m["t"]) // W)); chat[i] += 1
            if any(h in str(m.get("msg", "")).lower() for h in HYPE): hype[i] += 0.5
    base = np.median(chat) if any(chat) else 0
    spike = [c / (base + 1) for c in chat]
    score = 0.45 * norm(spike) + 0.35 * norm(loud) + 0.20 * norm(hype) if any(chat) else 0.6 * norm(loud) + 0.4 * norm(hype)
    order = np.argsort(-score)[: a.top]
    with open("moments.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f); wr.writerow(["id", "start", "end", "score", "chat_spike", "hype_words", "snippet"])
        for k, i in enumerate(order, 1):
            wr.writerow([f"m{k:02d}", i * W, (i + 1) * W, round(float(score[i]) * 100), round(spike[i], 1), hype[i], text[i][:140].strip()])
    print(f"saved moments.csv with the top {len(order)} moments")

if __name__ == "__main__":
    main()
