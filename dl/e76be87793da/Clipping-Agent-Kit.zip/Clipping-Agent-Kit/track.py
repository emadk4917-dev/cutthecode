"""Track clips, views and expected payout for a campaign.

Usage:
  python track.py add  <clip_id> <platform> <account> <post_url>
  python track.py views <clip_id> <platform> <views_24h_or_48h> [--at 48]
  python track.py report --rate 1.00 --cap 100
Data: log.csv. Rate = campaign $ per 1,000 approved views; cap = max $ per clip (0 = no cap).
Expected payout is an estimate: campaigns pay only on approved views.
"""
import csv, os, sys, datetime as dt

F = "log.csv"; COLS = ["clip", "platform", "account", "url", "posted_at", "views_24h", "views_48h", "approved"]

def load():
    if not os.path.exists(F): return []
    return list(csv.DictReader(open(F, encoding="utf-8")))

def save(rows):
    w = csv.DictWriter(open(F, "w", newline="", encoding="utf-8"), fieldnames=COLS); w.writeheader(); w.writerows(rows)

def main():
    a = sys.argv[1:]; rows = load()
    if not a: print(__doc__); return
    if a[0] == "add":
        rows.append(dict(clip=a[1], platform=a[2], account=a[3], url=a[4], posted_at=dt.datetime.now().isoformat(timespec="minutes"), views_24h="", views_48h="", approved="pending"))
    elif a[0] == "views":
        col = "views_48h" if "--at" in a and a[a.index("--at") + 1] == "48" else "views_24h"
        for r in rows:
            if r["clip"] == a[1] and r["platform"] == a[2]: r[col] = a[3]
    elif a[0] == "report":
        rate = float(a[a.index("--rate") + 1]) if "--rate" in a else 1.0
        cap = float(a[a.index("--cap") + 1]) if "--cap" in a else 0
        tot_v = tot_p = 0
        print(f"{'clip':<12}{'platform':<10}{'views':>10}{'est $':>10}")
        for r in rows:
            v = int(r["views_48h"] or r["views_24h"] or 0); p = v / 1000 * rate
            if cap: p = min(p, cap)
            tot_v += v; tot_p += p
            print(f"{r['clip']:<12}{r['platform']:<10}{v:>10,}{p:>10.2f}")
        print(f"{'TOTAL':<22}{tot_v:>10,}{tot_p:>10.2f}  (estimate at ${rate}/1k, cap {cap or 'none'})")
        return
    save(rows); print("saved", F)

if __name__ == "__main__":
    main()
