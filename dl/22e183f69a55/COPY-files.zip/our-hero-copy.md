# Hero copy: cutthecode.co.uk homepage

**Diagnosis:** B, real voice present. "This business is run by 6 AI employees" is the page's strongest line and also the og:title, so it stays. The rewrite changes the part that's about us into a line about the reader, removes the subheadline's repeat of the org chart, and makes the button say what the visitor actually gets.

## Final pick

**Headline (h1):** This business is run by **6 AI employees.**
**Second line (.then):** Build yours with Claude.

**Subheadline:** Each is a Claude agent with one job, from spotting what's working to posting the videos. You don't need to code to build your own. Start with 6 free prompts that get Claude to build a real business website in about 10 minutes.

**Primary button:** Get the free website prompts →
(Secondary button "See all free tools" is unchanged.)

## Three headline options

### Option 1 (picked): "This business is run by 6 AI employees. Build yours with Claude."
- Keeps the hook that already works and matches the og:title, so people arriving from social links see the same promise they clicked.
- "Build yours" makes the reader the subject. The old line ("We teach you to build the same with Claude") was about us and took 9 words to say what 4 now say.
- The reader can picture it: the org chart sits right next to it and shows the six employees.

### Option 2: "Meet the 6 AI employees who run this business. Then build your own with Claude."
- Points the eye straight at the org chart, so headline and visual work as one unit.
- Why it lost: "Meet" is softer and adds a step. The reader is introduced before they hear what's in it for them.

### Option 3: "Build AI employees with Claude, like the 6 that run this business."
- Leads with the reader's outcome, which follows the "Now you can" test most directly.
- Why it lost: it hides the hook. "This business is run by AI" makes people curious and is proven right there on the page. Moving it into a subordinate clause gives up the line's best asset.

## Why the subheadline and button changed
- **Old subheadline** named all six agents in six sentences. The org chart beside it already does that, so the words were spent twice. The new version says how it works in one line ("one job" each), handles the main objection ("You don't need to code"), and hands off to the CTA with real numbers from the pack (6 prompts, about 10 minutes).
- **Bridge:** the hero sells AI employees but the lead magnet teaches websites. The subheadline now makes that step explicit ("Start with…") so the button doesn't feel like a switch.
- **Button:** "Get the free prompt pack" became "Get the free website prompts". It follows the action + what-they-get formula and matches the pack's content. The nav CTA and the #code section still say "prompt pack", so both names point at the same thing.

## Claims check
- "Run by 6 AI employees": supported by the page itself, which also notes that a human checks the work before anything posts. That note stays in the org chart.
- "6 prompts", "about 10 minutes", "real business website": taken word for word from the prompt-pack section.
- No earnings, customer or result claims added. If you want a proof line in the hero (for example videos posted or followers gained so far), that needs the real numbers: `[NEED: building-in-public stats to date]`.
