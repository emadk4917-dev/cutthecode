# Chase emails — drafts, not sent

Drafted 26 Nov 2026 from invoices.csv. 16 overdue invoices, 10 clients, **£7,020** outstanding.
Fill in `[Your name]` and `[payment details]` before sending.

---

## Blue Door Cafe — £240

**Subject:** Overdue invoice INV-1037 (£240)

Hi Blue Door Cafe team,

I hope you're well. Our records show invoice INV-1037 for £240, due on 4 August 2026, is still unpaid. Could you take a look and arrange payment when you can? Payment details: [payment details].

If you've already paid, please ignore this and let me know so I can update my records.

Many thanks,
[Your name]

---

## Harbour Bakery — £240

**Subject:** Overdue invoice INV-1032 (£240)

Hi Harbour Bakery team,

I hope all's well. Invoice INV-1032 for £240, due on 26 August 2026, is still showing as unpaid on my side. Could you arrange payment when you have a moment? Payment details: [payment details].

If this has already gone through, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## Kestrel Plumbing — £990

**Subject:** Two overdue invoices (£990 total)

Hi Kestrel Plumbing team,

I hope you're well. Two invoices are currently past their due date:

- INV-1033 — £750, due 30 September 2026
- INV-1025 — £240, due 6 November 2026

That's £990 in total. Could you arrange payment when you can? Payment details: [payment details].

If either has already been paid, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## Marlow Yoga — £480

**Subject:** Overdue invoice INV-1016 (£480)

Hi Marlow Yoga team,

I hope you're well. Invoice INV-1016 for £480, due on 22 August 2026, is still unpaid on my records. Could you arrange payment when convenient? Payment details: [payment details].

If you've already paid, please let me know so I can update my records.

Many thanks,
[Your name]

---

## Northside Dental — £1,700

**Subject:** Two overdue invoices (£1,700 total)

Hi Northside Dental team,

I hope all's well. Two invoices are currently past their due date:

- INV-1003 — £950, due 24 August 2026
- INV-1020 — £750, due 15 November 2026

That's £1,700 in total. Could you arrange payment when you can? Payment details: [payment details].

If either has already been paid, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## Oak & Ivy Florist — £480

**Subject:** Friendly reminder: invoice INV-1009 (£480)

Hi Oak & Ivy team,

Just a quick, friendly reminder that invoice INV-1009 for £480 was due on 25 November 2026. When you have a moment, could you arrange payment? Payment details: [payment details].

If it's already on its way, thank you, and please ignore this.

Many thanks,
[Your name]

---

## Penny Lane Books — £530

**Subject:** Two overdue invoices (£530 total)

Hi Penny Lane Books team,

I hope you're well. Two invoices are currently past their due date:

- INV-1017 — £350, due 30 August 2026
- INV-1021 — £180, due 23 September 2026

That's £530 in total. Could you arrange payment when you can? Payment details: [payment details].

If either has already been paid, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## Riverside Vets — £180

**Subject:** Overdue invoice INV-1038 (£180)

Hi Riverside Vets team,

I hope all's well. Invoice INV-1038 for £180, due on 2 October 2026, is still showing as unpaid. Could you arrange payment when you have a moment? Payment details: [payment details].

If it's already been paid, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## The Copper Kettle — £1,760

**Subject:** Four overdue invoices (£1,760 total)

Hi Copper Kettle team,

I hope you're well. A few invoices are currently past their due date:

- INV-1036 — £480, due 18 August 2026
- INV-1028 — £750, due 3 September 2026
- INV-1022 — £180, due 16 October 2026
- INV-1027 — £350, due 24 November 2026

That's £1,760 in total. Could you arrange payment, or let me know if it would help to talk about a payment plan? Payment details: [payment details].

If any of these have already been paid, please let me know and I'll update my records.

Many thanks,
[Your name]

---

## Willow Nursery — £420

**Subject:** Overdue invoice INV-1013 (£420)

Hi Willow Nursery team,

I hope all's well. Invoice INV-1013 for £420, due on 31 July 2026, is still unpaid on my records. Could you arrange payment when you can? Payment details: [payment details].

If you've already paid, please let me know so I can update my records.

Many thanks,
[Your name]
