Subject: Website agreement – three small changes

Hi,

Thanks for sending the agreement over. I'm looking forward to building the new site. Before I sign, could we make three changes? They're standard for this kind of project and keep things fair for both of us.

**1. Liability (clauses 4.1 and 4.2)**
Could we cap my liability at the total fee (£2,400) and exclude loss of profits and loss of business? Could we also confirm that the £100 limit in 4.2 doesn't apply to my fees?

**2. Payment and revisions (clauses 1.2, 2.2, 2.3 and 5.3)**
- 50% (£1,200) up front and the remaining 50% on completion, each paid within 30 days of invoice.
- If the agreement ends early, you pay for the work done up to that point.
- Two rounds of revisions included, with any extra rounds at an hourly rate agreed in advance.

**3. Ownership (clause 3.1)**
Ownership of the website passes to you once it's paid in full. My own templates, tools and code libraries that existed before this project stay mine, and you get a permanent, free licence to use them as part of your website.

If you're happy with these, I'll send back an updated copy to sign. I'm also happy to have a quick call if that's easier.

Best wishes,
Sam
