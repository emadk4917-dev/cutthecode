# Website Design Services Agreement

**Made-up sample for a demo. Not a real company or person.**

Between **Brightside Dental Group Ltd** ("the Client") and **Sam Taylor** ("the Designer").
Date: 20 November 2026

## 1. The work
1.1 The Designer will design and build a 6-page website for the Client ("the Website").
1.2 The Client may request revisions to the Website. The Designer will make all revisions requested by the Client until the Client is satisfied.
1.3 The Designer will also provide ongoing support for the Website as reasonably required by the Client.

## 2. Fees and payment
2.1 The total fee is £2,400.
2.2 The Designer will invoice the full fee on completion of the Website.
2.3 The Client will pay each invoice within 90 days of the end of the month in which it is received.
2.4 The Client may withhold payment of any invoice it disputes, in whole or in part, until the dispute is resolved.

## 3. Ownership
3.1 All work, designs, code, drafts and materials created by the Designer, including the Designer's pre-existing templates, tools and code libraries used in the Website, become the property of the Client on creation.

## 4. Liability
4.1 The Designer is liable for any loss suffered by the Client arising from the Website, including loss of profits and loss of business.
4.2 The Client's total liability under this agreement is limited to £100.

## 5. Term and ending the agreement
5.1 This agreement continues for 12 months and renews automatically for further 12-month periods.
5.2 The Client may end this agreement at any time on 7 days' notice. The Designer may end this agreement on 6 months' written notice.
5.3 If the Client ends the agreement, no fees are payable for work not yet completed.

## 6. Non-compete
6.1 For 2 years after this agreement ends, the Designer will not provide website services to any dental practice in the United Kingdom.

## 7. General
7.1 This agreement is governed by the law of England and Wales.
