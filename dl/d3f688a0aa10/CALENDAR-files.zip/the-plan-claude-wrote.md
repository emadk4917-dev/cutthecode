# Next week: meetings to cut, shorten or merge

**Week of Mon 30 Nov – Fri 4 Dec 2026** · source: `week.ics` (25 meetings)

| | Hours |
|---|---|
| Booked now | **23.5 h** |
| Hours back with this plan | **9.0 h** |
| Booked after changes | **14.5 h** |

## The changes

| # | Meeting(s) | Change | Why | Hours back |
|---|---|---|---|---|
| 1 | **Project Atlas status** ×3 (Mon 16:00, Tue 15:00, Thu 13:00) | **Merge** into one 30-min check-in on Thu. Cut Tue, cut Mon. | Tue is a duplicate invite from Tom. Mon already says "read the status doc first", so the doc can do the update. | **2.5 h** |
| 2 | **Weekly sync** ×3 (Mon 10:00, Wed 10:00, Fri 10:00) | **Merge** into the Wed one. Cut Mon and Fri. | Mon has no agenda and looks like it moved to Wed with both copies left in. Fri is "recap of the week", which the Fri retro right after it covers. | **2.0 h** |
| 3 | **Website review** (Thu 10:00–12:00) | **Shorten** from 2 h to 30 min (10:00–10:30). | Only 2 pages changed. | **1.5 h** |
| 4 | **Brainstorm: newsletter names** (Wed 11:00) | **Cut**: collect names in a shared doc instead. | No agenda. Naming works well done async. | **1.0 h** |
| 5 | **Vendor demo: CRM** (Tue 14:00) | **Cut** (decline). | Same vendor already demoed in October. | **1.0 h** |
| 6 | **Lunch & learn: AI tools** (Mon 13:00) | **Skip** (decline). | Marked optional. Ask for the recording. | **1.0 h** |
| | | | **Total** | **9.0 h** |

### Where the free time lands

- **Mon:** 10:00–11:00, 13:00–14:00, 16:00–17:00 (3 h)
- **Tue:** 14:00–16:00 (2 h in one block)
- **Wed:** 11:00–12:00 (1 h)
- **Thu:** 10:30–12:00, 13:30–14:00 (2 h)
- **Fri:** 10:00–11:00 (1 h)

### Kept as they are

Daily stand-ups, 1:1s with Sam and Alex, hiring debrief, budget check-in, team retro, coffee chat with the new joiner (Jordan) and Friday demo. Each is short, has a clear purpose or involves a person who needs the time.

### Possible extras (not counted above)

- **Q1 planning parts 1 + 2** (Tue 10:00–13:00): 3 h back to back with the same 5 leads. If you share a pre-read, it could fit in 2 h. **+1.0 h**
- **1:1 with Priya** (Mon 15:00): 1 h while the other 1:1s are 30 min. Shorten only if Priya agrees. **+0.5 h**

---

## The 3 messages

### 1. To the Atlas team (and Tom): Project Atlas status → 2.5 h

> Hi all, I have three Atlas status meetings next week (Mon, Tue, Thu), and Tom's Tuesday one looks like a duplicate. Proposal: we skip Monday and Tuesday, everyone posts their update in the status doc by Wednesday end of day, and we keep one 30-min call on Thursday at 13:00 for blockers only. I'll update the Thursday invite. Shout if anything can't wait until then.

### 2. To the team: Weekly sync → 2 h

> Hi team, the weekly sync is on my calendar three times next week (Mon, Wed, Fri). I think it moved to Wednesday and the old copies stayed. Let's keep **Wednesday 10:00** only and drop Monday and Friday. The Friday recap can go into the retro straight after. Please add agenda items to the Wednesday invite so we use the hour well.

### 3. To marketing (+ agency): Website review and newsletter brainstorm → 2.5 h

> Hi both, two quick changes for next week. **Website review (Thu):** since only 2 pages changed, can we make it 30 min (10:00–10:30)? If you send the links beforehand I'll come with comments ready. **Newsletter names (Wed):** rather than a meeting, let's drop ideas into a shared doc by Wednesday and vote on Thursday. I'll start the doc today.

*Plus two one-click declines, no message needed:* the **CRM vendor demo** (already seen in October) and the optional **Lunch & learn** (ask for the recording).
