// Invoice Chaser — tiny zero-dependency local server.
// Serves the single HTML page and the sample CSV. Invoice data never leaves the
// browser: parsing, the dashboard and the reminder emails all happen client-side.
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "127.0.0.1";
const ROOT = __dirname;

const ROUTES = {
  "/": ["public/index.html", "text/html; charset=utf-8"],
  "/index.html": ["public/index.html", "text/html; charset=utf-8"],
  "/sample-invoices.csv": ["sample-invoices.csv", "text/csv; charset=utf-8"],
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const route = ROUTES[url.pathname];
  if (req.method !== "GET" || !route) {
    res.writeHead(404, { "Content-Type": "text/plain" });
    return res.end("Not found");
  }
  fs.readFile(path.join(ROOT, route[0]), (err, data) => {
    if (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      return res.end("Could not read file");
    }
    res.writeHead(200, {
      "Content-Type": route[1],
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`Invoice Chaser running at http://${HOST}:${PORT}`);
});
