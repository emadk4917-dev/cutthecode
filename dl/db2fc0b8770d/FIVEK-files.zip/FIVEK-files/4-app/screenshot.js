// Starts the server, loads sample-invoices.csv through the UI, and saves dashboard.png.
// Usage: node screenshot.js   (needs Playwright; set CHROME_PATH to use a system Chrome)
const { spawn } = require("child_process");
const path = require("path");
let playwright;
try { playwright = require("playwright"); }
catch { playwright = require(require("child_process").execSync("npm root -g").toString().trim() + "/playwright"); }

const PORT = process.env.PORT || 3123;
const URL = `http://127.0.0.1:${PORT}/`;

(async () => {
  const server = spawn(process.execPath, [path.join(__dirname, "server.js")], { env: { ...process.env, PORT }, stdio: "inherit" });
  try {
    for (let i = 0; i < 50; i++) {
      try { if ((await fetch(URL)).ok) break; } catch {}
      await new Promise(r => setTimeout(r, 100));
    }
    const browser = await playwright.chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 2 });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    page.on("console", m => m.type() === "error" && errors.push(m.text()));
    await page.goto(URL);
    await page.fill("#your-name", "Sam Carter");
    await page.fill("#biz-name", "Carter Plumbing & Heating");
    await page.click("#btn-sample");
    await page.waitForSelector("#rows .pill");
    console.log("Status:", await page.textContent("#msg"));
    await page.locator("#dashboard").screenshot({ path: path.join(__dirname, "dashboard.png") });
    await page.screenshot({ path: path.join(__dirname, "full-page.png"), fullPage: true });
    if (errors.length) console.error("Page errors:", errors);
    await browser.close();
    console.log("Saved dashboard.png and full-page.png");
  } finally {
    server.kill();
  }
})().catch(e => { console.error(e); process.exit(1); });
