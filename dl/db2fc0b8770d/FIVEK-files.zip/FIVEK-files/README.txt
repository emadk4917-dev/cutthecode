The $5K Maths Sheet: the exact files from our Claude Code runs (26 Nov 2026).
Each folder has prompt.txt (what we pasted) and what Claude Code made. All businesses are made up.
1-website     one-page site for a made-up Tampa plumber
2-automation  instant enquiry reply server for a made-up dog groomer (TEST MODE, nothing sent)
3-product     notes.md -> a 10-page PDF guide + sales page
4-app         invoice chaser with a $19/month pricing section (Stripe Payment Link placeholder, no keys)
5-clipping    the 5 prompts in order + the clipper skill Claude wrote + tracker + the DM. Only clip videos you have permission to use.
Results vary. Nothing here is a promise of earnings. cutthecode.co.uk/fivek
