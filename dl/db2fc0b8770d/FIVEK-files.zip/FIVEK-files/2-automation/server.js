// Instant enquiry reply automation — demo for "Sudsy Pup Grooming" (a made-up dog groomer).
// TEST MODE: replies are written to ./outbox as .eml files. Nothing is really sent.
// Zero dependencies: run with `node server.js`.

const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const LEADS_CSV = path.join(__dirname, "leads.csv");
const OUTBOX = path.join(__dirname, "outbox");

const BUSINESS = {
  name: "Sudsy Pup Grooming",
  owner: "Jess",
  email: "hello@sudsypup.example",
  phone: "(555) 010-2468",
  bookingLink: "https://sudsypup.example/book",
};

// What we say about each service. Keys are matched loosely against what the customer typed.
const SERVICES = {
  "full groom": { label: "Full Groom", price: "from $65", time: "about 2 hours", note: "bath, haircut, nail trim, ear clean and a bandana to finish" },
  "bath & brush": { label: "Bath & Brush", price: "from $40", time: "about 1 hour", note: "a deep-clean bath, blow-dry and a thorough brush-out" },
  "nail trim": { label: "Nail Trim", price: "$15", time: "about 15 minutes", note: "walk-ins are welcome for this one too" },
  "puppy intro": { label: "Puppy Intro Groom", price: "$35", time: "about 45 minutes", note: "a gentle first visit so your pup learns grooming is fun" },
  "de-shedding": { label: "De-shedding Treatment", price: "from $55", time: "about 90 minutes", note: "great for double-coated breeds, cuts shedding way down" },
};

function matchService(text = "") {
  const t = text.toLowerCase();
  for (const [key, svc] of Object.entries(SERVICES)) {
    const words = key.split(/[^a-z]+/).filter(Boolean);
    if (words.every((w) => t.includes(w))) return svc;
  }
  if (t.includes("bath")) return SERVICES["bath & brush"];
  if (t.includes("nail")) return SERVICES["nail trim"];
  if (t.includes("puppy")) return SERVICES["puppy intro"];
  if (t.includes("shed")) return SERVICES["de-shedding"];
  if (t.includes("groom") || t.includes("haircut") || t.includes("cut")) return SERVICES["full groom"];
  return null;
}

// ---------- leads.csv ----------
const CSV_HEADER = ["received_at", "id", "name", "email", "phone", "dog_name", "service", "message", "reply_file"];

function csvCell(v) {
  const s = String(v ?? "");
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function saveLead(row) {
  if (!fs.existsSync(LEADS_CSV)) fs.writeFileSync(LEADS_CSV, CSV_HEADER.join(",") + "\n");
  fs.appendFileSync(LEADS_CSV, CSV_HEADER.map((k) => csvCell(row[k])).join(",") + "\n");
}

// ---------- reply email ----------
function firstName(name) {
  const f = String(name).trim().split(/\s+/)[0] || "there";
  return f.charAt(0).toUpperCase() + f.slice(1);
}

function writeReply(lead) {
  const name = firstName(lead.name);
  const svc = matchService(lead.service);
  const dog = lead.dog_name ? lead.dog_name.trim() : "your pup";
  const serviceLabel = svc ? svc.label : lead.service || "a grooming appointment";

  const subject = `Re: your ${serviceLabel} enquiry — ${BUSINESS.name}`;

  const serviceBlock = svc
    ? `Our ${svc.label} is ${svc.price} and takes ${svc.time}: ${svc.note}.`
    : `I'll check exactly what ${dog} needs and send you a quote for "${serviceLabel}" today.`;

  const body = `Hi ${name},

Thanks so much for getting in touch about a ${serviceLabel} for ${dog}! 🐾

${serviceBlock}

The quickest way to grab a spot is to pick a time here:
${BUSINESS.bookingLink}

Or just reply to this email with a couple of days/times that suit you and I'll lock it in.

Looking forward to meeting ${dog}!

${BUSINESS.owner}
${BUSINESS.name}
${BUSINESS.phone}
`;

  return { subject, body };
}

function saveToOutbox(lead, reply) {
  fs.mkdirSync(OUTBOX, { recursive: true });
  const safe = String(lead.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "lead";
  const file = `${lead.id}-${safe}.eml`;
  const eml = [
    `X-Test-Mode: true (NOT SENT)`,
    `From: ${BUSINESS.name} <${BUSINESS.email}>`,
    `To: ${lead.name} <${lead.email}>`,
    `Subject: ${reply.subject}`,
    `Date: ${new Date(lead.received_at).toUTCString()}`,
    `Content-Type: text/plain; charset=utf-8`,
    ``,
    reply.body,
  ].join("\n");
  fs.writeFileSync(path.join(OUTBOX, file), eml);
  return path.join("outbox", file);
}

// ---------- HTTP ----------
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => {
      data += c;
      if (data.length > 1e5) reject(new Error("Body too large"));
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function send(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(obj, null, 2) + "\n");
}

let counter = 0;

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/") return send(res, 200, { ok: true, business: BUSINESS.name, mode: "TEST" });
  if (req.method !== "POST" || req.url !== "/enquiry") return send(res, 404, { error: "Use POST /enquiry" });

  let input;
  try {
    const raw = await readBody(req);
    input = (req.headers["content-type"] || "").includes("application/x-www-form-urlencoded")
      ? Object.fromEntries(new URLSearchParams(raw))
      : JSON.parse(raw || "{}");
  } catch {
    return send(res, 400, { error: "Body must be JSON or form-encoded" });
  }

  const missing = ["name", "email"].filter((k) => !String(input[k] || "").trim());
  if (missing.length) return send(res, 400, { error: `Missing: ${missing.join(", ")}` });
  if (!/^\S+@\S+\.\S+$/.test(input.email)) return send(res, 400, { error: "Invalid email" });

  const lead = {
    received_at: new Date().toISOString(),
    id: `${Date.now()}-${++counter}`,
    name: String(input.name).trim(),
    email: String(input.email).trim(),
    phone: String(input.phone || "").trim(),
    dog_name: String(input.dog_name || "").trim(),
    service: String(input.service || "").trim(),
    message: String(input.message || "").trim(),
  };

  const reply = writeReply(lead);
  lead.reply_file = saveToOutbox(lead, reply);
  saveLead(lead);

  console.log(`[enquiry] ${lead.name} <${lead.email}> — ${lead.service || "(no service)"} → ${lead.reply_file} (TEST MODE, not sent)`);
  send(res, 201, { ok: true, id: lead.id, reply_file: lead.reply_file, subject: reply.subject, sent: false, mode: "TEST" });
});

server.listen(PORT, () => console.log(`${BUSINESS.name} enquiry bot listening on http://localhost:${PORT} (TEST MODE — nothing is sent)`));
