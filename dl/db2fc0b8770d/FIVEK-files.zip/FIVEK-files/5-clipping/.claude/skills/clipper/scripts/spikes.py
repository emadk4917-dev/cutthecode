#!/usr/bin/env python3
"""Step 2: find spikes = loudest seconds + wild words, and dump the transcript
around each one so Claude can read it and pick moments.

Usage: spikes.py VIDEO WORKDIR [--top 15] [--context 35]
Needs WORKDIR/transcript.json (from transcribe.py).
Writes WORKDIR/spikes.json and WORKDIR/spikes.md (readable context windows).
"""
import argparse, json, os, re, subprocess
import numpy as np

# phrase -> weight. Multi-word phrases are matched on the joined word stream.
HYPE = {
    "no way": 3, "oh my god": 3, "oh my gosh": 2, "omg": 3, "what the": 3, "wtf": 3,
    "holy": 3, "let's go": 3, "lets go": 3, "are you kidding": 3, "you're kidding": 2,
    "bro": 2, "bruh": 2, "dude": 1.5, "yo": 1.5, "insane": 2, "crazy": 2, "oh no": 2.5,
    "clip that": 3, "clip it": 3, "chat": 1, "what": 1, "wait": 1.5, "dead": 1.5,
    "run": 1, "help": 1.5, "shit": 2, "fuck": 2, "damn": 1.5, "hell": 1, "jesus": 2,
    "screaming": 2, "lmao": 2, "hahaha": 2, "haha": 1, "nah": 1.5, "why": 1,
}


def loudness_per_second(video, sr=16000):
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", video, "-vn", "-ac", "1", "-ar", str(sr),
         "-f", "s16le", "-"], capture_output=True, check=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    n = len(x) // sr
    rms = np.sqrt((x[: n * sr].reshape(n, sr) ** 2).mean(1) + 1e-10)
    return 20 * np.log10(rms)  # dBFS per second


def norm(w):
    return re.sub(r"[^a-z' ]", "", w.lower()).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("workdir")
    ap.add_argument("--top", type=int, default=15, help="how many spikes to report")
    ap.add_argument("--context", type=float, default=35, help="seconds of transcript each side")
    ap.add_argument("--gap", type=float, default=25, help="min seconds between spikes")
    a = ap.parse_args()

    tr = json.load(open(os.path.join(a.workdir, "transcript.json")))
    words = [w for s in tr["segments"] for w in s["words"]]
    db = loudness_per_second(a.video)
    n = len(db)

    # loudness score: robust z-score against the stream's own level
    med, mad = np.median(db), np.median(np.abs(db - np.median(db))) + 1e-6
    loud_z = np.clip((db - med) / (1.4826 * mad), 0, None)

    # hype score: weighted wild words/phrases landing in each second
    hype = np.zeros(n)
    hits = [[] for _ in range(n)]
    toks = [norm(w["word"]) for w in words]
    for i, w in enumerate(words):
        for phrase, wt in HYPE.items():
            k = len(phrase.split())
            if " ".join(toks[i:i + k]) == phrase:
                sec = min(int(w["start"]), n - 1)
                hype[sec] += wt
                hits[sec].append(phrase)

    # smooth over a 3s window so a burst of reaction counts as one spike
    kern = np.ones(3)
    score = np.convolve(loud_z, kern, "same") / 3 + np.convolve(hype, kern, "same")

    picked = []
    for sec in np.argsort(-score):
        if score[sec] <= 0 or len(picked) >= a.top:
            break
        if all(abs(sec - p) >= a.gap for p in picked):
            picked.append(int(sec))
    picked.sort()

    spikes, md = [], [f"# Spikes in {os.path.basename(a.video)} "
                      f"(median loudness {med:.1f} dBFS)\n"]
    for sec in picked:
        lo, hi = max(0, sec - 3), min(n, sec + 4)
        sp = {"t": sec, "score": round(float(score[sec]), 2),
              "peak_db": round(float(db[lo:hi].max()), 1),
              "words_hit": sorted({h for s in range(lo, hi) for h in hits[s]})}
        spikes.append(sp)
        c0, c1 = max(0, sec - a.context), sec + a.context
        md.append(f"## Spike @ {sec // 60}:{sec % 60:02d} ({sec}s)  score {sp['score']}  "
                  f"peak {sp['peak_db']} dB  words: {', '.join(sp['words_hit']) or '-'}")
        for s in tr["segments"]:
            if s["end"] >= c0 and s["start"] <= c1:
                mark = " <<<" if s["start"] - 2 <= sec <= s["end"] + 2 else ""
                md.append(f"  [{s['start']:7.2f}-{s['end']:7.2f}] {s['text']}{mark}")
        md.append("")

    json.dump(spikes, open(os.path.join(a.workdir, "spikes.json"), "w"), indent=1)
    open(os.path.join(a.workdir, "spikes.md"), "w").write("\n".join(md))
    print(f"{len(spikes)} spikes -> {a.workdir}/spikes.md")


if __name__ == "__main__":
    main()
