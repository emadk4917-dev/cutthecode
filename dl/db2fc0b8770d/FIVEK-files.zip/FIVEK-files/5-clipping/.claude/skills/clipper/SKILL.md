---
name: clipper
description: Turns a long stream VOD into 5 vertical 1080x1920 short-form clips (face cam on top, gameplay below, big word-by-word burned-in captions, streamer credit line) plus clips.csv. Transcribes with faster-whisper, finds loudness and wild-word spikes ("no way", "bro", "oh my god"), then Claude reads the transcript around each spike and picks the 5 best self-contained 20-45s moments. Use whenever the user wants clips, shorts, reels or TikToks cut from a stream, VOD or gameplay recording, or says "clip this", even if they don't say "skill".
---

# Clipper

Scripts live in `.claude/skills/clipper/scripts/` (call that `$S`). Needs ffmpeg,
Python 3 and faster-whisper (the `small.en` model downloads on first use).

Pick a work dir per stream, e.g. `work/<video-name>/`. Final output goes to the
directory the user is in (or wherever they ask): `clips/` + `clips.csv`.

## 1. Transcribe

```bash
python3 $S/transcribe.py STREAM.mp4 work/NAME
```
Writes `transcript.json` (words with timestamps) and `transcript.txt`.
Runs roughly 3-5x faster than real time on 4 CPUs, so a 1-hour VOD takes
15-20 minutes. Run it in the background for long streams.

## 2. Find spikes

```bash
python3 $S/spikes.py STREAM.mp4 work/NAME --top 15
```
Scores every second by loudness relative to the stream's median plus weighted wild
words (edit `HYPE` in `spikes.py` to tune them). Writes `spikes.json` and
`spikes.md`, which holds the transcript ±35s around each spike, with `<<<` marking
the spike line.

## 3. YOU pick the 5 best moments (do not skip or automate this)

Read `work/NAME/spikes.md` in full. Open `transcript.txt` too if you need more context.
For each candidate ask:
- **Does it stand alone?** A viewer with no context must understand the setup.
  Start where the setup starts (the question, the plan, the "watch this"), not mid-sentence.
- **Is there a payoff?** It should end right after the reaction or punchline lands,
  not trail into dead air or a new topic.
- **Is it 20-45 seconds?** Snap start and end to segment boundaries in the transcript.
- **Is it varied?** Prefer 5 different kinds of moments over 5 of the same.

A loud spike with no story loses to a quieter moment that's funny or has a clear arc.
Write `work/NAME/picks.json`, best first:
```json
[{"start": 312.4, "end": 341.0,
  "hook": "On-screen/title hook, under 10 words",
  "why": "One sentence: setup, payoff, and why it works without context"}]
```

## 4. Find the face cam, then cut

Grab a frame and look at it to find the face cam box and the streamer's channel
(overlays usually show the handle):
```bash
ffmpeg -v error -ss 60 -i STREAM.mp4 -frames:v 1 work/NAME/frame.jpg
```
Read the image, estimate the cam box in source pixels as `X:Y:W:H`, then crop it
(`-vf crop=W:H:X:Y`) and check that the crop is tight around the cam. Ask the user
for the channel if it isn't visible on the overlay.

```bash
python3 $S/cut.py STREAM.mp4 work/NAME/picks.json \
  --cam X:Y:W:H --credit "twitch.tv/CHANNEL" --out .
```
- The top 700px is the face cam. The bottom 1220px is gameplay, scaled to fill and
  center-cropped. Use `--game-x 0.3` (left) or `0.7` (right) to follow the action.
- Captions show 3 words at a time, uppercase, with the spoken word in yellow, on the seam.
- It rejects picks outside 20-45s. `--min-len/--max-len` override this, for tests only.

Afterwards, pull a frame from one clip and look at it: check the cam framing,
that the captions are readable, and that the credit isn't covered. Report the
clips.csv rows to the user.
