#!/usr/bin/env python3
"""Step 4: cut picked moments into 1080x1920 vertical clips.

Layout: face cam (cropped from the stream) on top, gameplay below, big
word-by-word captions on the seam, credit line at the bottom.

Usage:
  cut.py VIDEO WORKDIR/picks.json --cam X:Y:W:H --credit "twitch.tv/name" \
         [--transcript WORKDIR/transcript.json] [--out .] [--game-x 0.5]

picks.json: [{"start": 312.4, "end": 341.0, "hook": "...", "why": "..."}, ...]
Writes OUT/clips/clip_01.mp4 ... and OUT/clips.csv (file,start,end,hook,why).
"""
import argparse, csv, json, os, subprocess, sys, tempfile

W, H = 1080, 1920
TOP_H = 700            # face cam band
BOT_H = H - TOP_H      # gameplay band
CAPTION_Y = TOP_H + 30  # captions straddle the seam, just below it
FONT_DIR = "/usr/share/fonts/opentype/inter"
FONT = "Inter ExtraBold"


def ts(t):
    t = max(t, 0)
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


def esc(s):
    return s.replace("\\", "").replace("{", "(").replace("}", ")")


def build_ass(words, credit, dur, per_chunk=3):
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{FONT},96,&H00FFFFFF,&H00FFFFFF,&H00000000,&H96000000,1,0,0,0,100,100,0,0,1,9,4,8,60,60,0,1
Style: Credit,{FONT},44,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,3,10,0,2,40,40,70,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    if credit:
        ev.append(f"Dialogue: 1,{ts(0)},{ts(dur)},Credit,,0,0,0,,{esc(credit)}")
    chunks = [words[i:i + per_chunk] for i in range(0, len(words), per_chunk)]
    for ci, ch in enumerate(chunks):
        nxt = chunks[ci + 1][0]["start"] if ci + 1 < len(chunks) else ch[-1]["end"] + 0.4
        for wi, w in enumerate(ch):
            st = w["start"]
            en = ch[wi + 1]["start"] if wi + 1 < len(ch) else min(nxt, w["end"] + 0.6)
            if en <= st:
                continue
            txt = " ".join(
                (r"{\c&H00E5FF&\fscx112\fscy112}" + esc(x["word"].upper()) + r"{\r}")
                if j == wi else esc(x["word"].upper())
                for j, x in enumerate(ch))
            ev.append(f"Dialogue: 0,{ts(st)},{ts(en)},Cap,,0,0,0,,"
                      rf"{{\pos({W // 2},{CAPTION_Y})\an8}}{txt}")
    return head + "\n".join(ev) + "\n"


def clip_words(transcript, start, end):
    out = []
    for s in transcript["segments"]:
        for w in s["words"]:
            if w["start"] >= start - 0.05 and w["end"] <= end + 0.3:
                out.append({"word": w["word"], "start": w["start"] - start,
                            "end": min(w["end"], end) - start})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("picks")
    ap.add_argument("--cam", required=True, help="face cam box in source pixels X:Y:W:H")
    ap.add_argument("--credit", required=True, help='e.g. "twitch.tv/boeshi"')
    ap.add_argument("--transcript", help="defaults to transcript.json next to picks")
    ap.add_argument("--out", default=".", help="writes OUT/clips/ and OUT/clips.csv")
    ap.add_argument("--game-x", type=float, default=0.5,
                    help="horizontal centre of the gameplay crop, 0=left 1=right")
    ap.add_argument("--min-len", type=float, default=20)
    ap.add_argument("--max-len", type=float, default=45)
    a = ap.parse_args()

    picks = json.load(open(a.picks))
    tr_path = a.transcript or os.path.join(os.path.dirname(os.path.abspath(a.picks)),
                                           "transcript.json")
    transcript = json.load(open(tr_path))
    cx, cy, cw, ch = (int(v) for v in a.cam.split(":"))

    for p in picks:
        d = p["end"] - p["start"]
        if not a.min_len <= d <= a.max_len:
            sys.exit(f"pick {p['start']}-{p['end']} is {d:.1f}s, outside "
                     f"{a.min_len}-{a.max_len}s. Fix picks.json.")

    clips_dir = os.path.join(a.out, "clips")
    os.makedirs(clips_dir, exist_ok=True)
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, p in enumerate(picks, 1):
            start, end = float(p["start"]), float(p["end"])
            dur = end - start
            ass = os.path.join(tmp, f"c{i}.ass")
            open(ass, "w").write(build_ass(clip_words(transcript, start, end), a.credit, dur))
            name = f"clip_{i:02d}.mp4"
            dst = os.path.abspath(os.path.join(clips_dir, name))
            # gameplay: scale to band height, crop 1080 wide around --game-x
            gx = f"(iw-{W})*{a.game_x}"
            fg = (f"[0:v]crop={cw}:{ch}:{cx}:{cy},scale={W}:{TOP_H}:force_original_aspect_ratio=increase,"
                  f"crop={W}:{TOP_H},setsar=1[top];"
                  f"[0:v]scale=-2:{BOT_H},crop={W}:{BOT_H}:{gx}:0,setsar=1[bot];"
                  f"[top][bot]vstack,ass=c{i}.ass:fontsdir={FONT_DIR},format=yuv420p[v]")
            cmd = ["ffmpeg", "-v", "error", "-y", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}",
                   "-i", os.path.abspath(a.video), "-filter_complex", fg,
                   "-map", "[v]", "-map", "0:a?", "-c:v", "libx264", "-preset", "medium",
                   "-crf", "20", "-r", "30", "-c:a", "aac", "-b:a", "160k",
                   "-movflags", "+faststart", dst]
            print(f"[{i}/{len(picks)}] {start:.1f}-{end:.1f}s -> clips/{name}", flush=True)
            subprocess.run(cmd, check=True, cwd=tmp)
            rows.append({"file": f"clips/{name}", "start": f"{start:.2f}", "end": f"{end:.2f}",
                         "hook": p.get("hook", ""), "why": p.get("why", "")})

    with open(os.path.join(a.out, "clips.csv"), "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=["file", "start", "end", "hook", "why"])
        wr.writeheader()
        wr.writerows(rows)
    print(f"done: {len(rows)} clips in {clips_dir}, index in {a.out}/clips.csv")


if __name__ == "__main__":
    main()
