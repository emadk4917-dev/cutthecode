#!/usr/bin/env python3
"""Step 1: transcribe a stream with faster-whisper (small.en, word timestamps).

Usage: transcribe.py VIDEO WORKDIR [--model small.en]
Writes WORKDIR/transcript.json  (segments + words, seconds)
       WORKDIR/transcript.txt   ([mm:ss] line per segment, for reading)
"""
import argparse, json, os, sys, time


def fmt(t):
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("workdir")
    ap.add_argument("--model", default="small.en")
    a = ap.parse_args()
    os.makedirs(a.workdir, exist_ok=True)

    import subprocess
    import numpy as np
    from faster_whisper import WhisperModel

    # Decode with ffmpeg ourselves: avoids faster-whisper's PyAV decoder, which
    # breaks when the installed PyAV version doesn't match.
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", a.video, "-vn", "-ac", "1",
                          "-ar", "16000", "-f", "s16le", "-"],
                         capture_output=True, check=True).stdout
    audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768

    model = WhisperModel(a.model, device="cpu", compute_type="int8")
    t0 = time.time()
    segments, info = model.transcribe(
        audio, language="en", word_timestamps=True, vad_filter=True,
        condition_on_previous_text=False,
    )
    out, lines = [], []
    for s in segments:
        words = [{"start": round(w.start, 2), "end": round(w.end, 2), "word": w.word.strip()}
                 for w in (s.words or []) if w.word.strip()]
        out.append({"start": round(s.start, 2), "end": round(s.end, 2),
                    "text": s.text.strip(), "words": words})
        lines.append(f"[{fmt(s.start)}-{fmt(s.end)}] {s.text.strip()}")
        print(lines[-1], file=sys.stderr)

    json.dump({"duration": info.duration, "segments": out},
              open(os.path.join(a.workdir, "transcript.json"), "w"), indent=1)
    open(os.path.join(a.workdir, "transcript.txt"), "w").write("\n".join(lines) + "\n")
    print(f"transcribed {info.duration:.0f}s of audio in {time.time() - t0:.0f}s, "
          f"{len(out)} segments -> {a.workdir}/transcript.json")


if __name__ == "__main__":
    main()
