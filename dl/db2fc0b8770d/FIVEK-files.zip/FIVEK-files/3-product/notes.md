# The $5K Maths Sheet
What it actually takes to make $5,000 with Claude Code: 4 routes, every prompt, every message, the real prices and the maths.
From the Cut The Code video "What It Actually Takes to Make $5,000 With Claude Code" (27 Nov 2026).

Honest note: this is not income advice and nothing here is guaranteed. The maths below is an illustration: $5,000 divided by a price equals the number of sales you need. Every market price has its source and the date we checked it. None of these routes is passive.

## The one-line plan
$5,000 ÷ your price = the number of yeses you need.

## What you need
- Claude Pro (includes Claude Code): $20 a month billed monthly, or $17 a month billed yearly (claude.com/pricing, checked 26 Nov 2026).
- A laptop, a folder, and a free place to host what you build.

## Route 1: websites for local businesses
Who pays: local service businesses (plumbers, barbers, dentists, dog groomers) that live on calls and bookings.
Market prices (checked 26 Nov 2026):
- WebFX (US agency), 2026 pricing guide from 250 US marketing professionals: web design $1,000 to $30,000+.
- DotGO (UK): from £499 + VAT one-off, then £45 a month for support. Same page: freelancers £500 to £3,000, agencies £3,000 to £10,000+.
Steps:
1. Pick one trade in one town (for example "plumbers in Tampa"). That is your whole market for now.
2. Build: make a folder, open Claude Code in it, paste the prompt below.
3. Position: sell "more calls from people searching on their phone", not "a website". Say "I build websites for plumbers in Tampa".
4. Find them: Google Maps, your trade + your town. List 10 businesses with no website or a site that breaks on a phone (name, phone, what is wrong).
5. Build first, ask second: make the first business its own homepage before you message them.
6. Get paid, then go live: send a Stripe payment link, publish on a free host when it is paid, and the business pays for its own domain.
Prompt:
"Build a one-page website for a local business. Client: [business name], a [trade] in [town]. Mobile first. Sections: hero with a big tap-to-call button, services with prices "from", service area, a quote request form, and opening hours. Do NOT invent reviews, awards or certifications. One index.html file, fast, no frameworks. When it's done, open it in a headless browser, check it at phone and desktop width, and tell me the page weight."
Message to send:
"Hi [name]. I build websites for [trade] in [town]. I noticed you don't have one, so I made you a homepage. Here's the link: [link]. If you want it live, it's $500, then $50 a month and I keep it updated."
The maths (illustration): $500 a site + $50 a month. $5,000 ÷ $500 = 10 websites. Those 10 clients at $50 a month = $500 every month.
Our real run: Claude Code built the demo site and checked it at phone and desktop width in under two minutes.

## Route 2: automations
Who pays: the same local businesses. An enquiry at 9pm that waits until morning is often a lost booking.
Market price (checked 26 Nov 2026): BeepBack, a missed-call text-back tool for US local businesses, lists $79 a month flat (GetApp listing).
Steps:
1. Build: new folder, Claude Code, paste the prompt below. Test mode first: nothing is really sent.
2. Position: "every enquiry answered in under a minute, even at midnight".
3. Who to ask: your website clients first (you already built their form).
4. The message (below).
5. Go live safely: connect a real email service, send the first test to yourself, read every reply it writes for a week.
6. Charge a setup fee and a monthly fee: it has to keep running and someone has to watch it.
Prompt:
"Build an instant enquiry reply automation for a small business (demo: [business type]). A tiny Node server with a POST /enquiry webhook. For every enquiry: save it to leads.csv, write a friendly reply email that uses their name and the service they asked about, and put it in an outbox folder (TEST MODE: nothing is really sent). Then send it 3 test enquiries with curl and show me leads.csv and one reply."
Message to send:
"How many enquiries came in after 6pm last week? I can make sure every one gets a reply within a minute, and you see them all in one sheet."
The maths (illustration): $300 setup + $100 a month. 10 clients = $3,000 up front + $1,000 a month. By the end of month two: $5,000.
Our real run: Claude Code built it and answered 3 test enquiries in under a minute.

## Clipping (a quick note)
Market prices (checked 26 Nov 2026): Castos sells 4 short clips per podcast episode for $990 a month. On Content Rewards, the median listed rate across 710 live campaigns on 16 Nov 2026 was $1.00 per 1,000 views (before their 10% fee).
The maths (illustration): at $1 per 1,000 views, $5,000 = 5,000,000 views.
Our real run: Claude Code built a clipper that cut 3 vertical captioned clips from our own episode in about ten minutes.
Prompt:
"Build me a clipping tool. Input: source.mp4 in this folder. Transcribe it with faster-whisper (small.en, CPU), pick the 3 strongest 20 to 40 second moments that make sense on their own, and cut each one into a 1080x1920 vertical clip with big burned-in captions, using ffmpeg. Save them in clips/ with a clips.csv of start, end and the hook line. Then show me the list."
Only clip videos you have permission to use.

## Route 3: digital products
Who pays: people who want a shortcut you have already taken.
Market prices (checked 26 Nov 2026): on Getly, the median price of a Claude or Cursor prompt listing was $4.99 (measured 6 Nov 2026). On Selar, a Claude Code starter kit is listed at $29.
Steps:
1. Pick what you actually know (5 plumber sites built = "the plumber website kit").
2. Build: put your notes in notes.md and paste the prompt below.
3. Get paid: Whop or Gumroad host the file and take the payment.
4. First sale: post the process as short videos, show the real result, one link in your bio.
5. Price like the market, then add what only you have: templates, checklist, real examples.
Prompt:
"Turn notes.md into a digital product I can sell: a clean 8 to 10 page PDF guide with a cover, a contents page and a checklist at the end, plus a one-page sales page (sales.html) with the price, what's inside and a buy button. Use HTML and a headless browser to print the PDF. Keep every fact from the notes; add no claims that aren't in them. Show me the page count when done."
The maths (illustration): $5,000 ÷ $29 = 173 sales. At $4.99 it is more than 1,000 sales.

## Route 4: your own app
Proof: the founder of Cut The Code built an app with Claude Code. Its real dashboard (26 Nov 2026, app name and customers blurred) shows MRR of £9,734.41 (over $12,000 a month at the 26 Nov mid-market rate of £1 = $1.3104), 1,258 new customers in the last 12 months and 615 paid active members. This is the founder's app, not Cut The Code's revenue.
Steps:
1. Pick a boring problem someone already pays to fix (for example chasing unpaid invoices).
2. Build: paste the prompt below.
3. Get paid: a Stripe payment link sells the monthly plan. Stripe US: 2.9% + 30¢ per successful domestic card payment, no monthly fee (stripe.com/pricing, checked 26 Nov 2026).
4. Position: launch to the 10 businesses you already know from routes 1 and 2.
5. First 10 customers: load their own overdue invoices into the app in front of them, first month free.
6. Keep them: answer every support email fast and build what they ask for.
Prompt:
"Build a small paid web app for tradespeople: an invoice chaser. They paste or upload a CSV of unpaid invoices (client, email, amount, due date), the app shows a dashboard of what's overdue and by how many days, and writes a polite reminder email for each one, firmer the later it is. Node + one HTML page, data stays local. Add a pricing section with a $19 a month plan and a Stripe Payment Link placeholder (no real keys). Load sample-invoices.csv, run it, and screenshot the dashboard to dashboard.png."
The maths (illustration): $19 a month. $5,000 in one month = 264 paying customers. 100 customers = $1,900 every month.
Our real run: Claude Code built the dashboard and reminders and checked them in a browser in under three minutes.

## The honest catch
Websites and automations pay fastest, but you have to talk to businesses. Products need an audience. Apps take months, and customers can cancel. No route is passive.

## Start today (checklist)
- [ ] Pick one trade in one town.
- [ ] Find 10 businesses on Google Maps; note name, phone, what is wrong.
- [ ] Build the first one a homepage with the Route 1 prompt.
- [ ] Send the message.
- [ ] Send a Stripe payment link when they say yes.
- [ ] Offer the instant-reply automation to every website client.
- [ ] Write down what you learned: that is your first digital product.
