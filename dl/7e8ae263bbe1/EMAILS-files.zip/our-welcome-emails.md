# Welcome Emails: The Claude Content Machine Setup

## Sequence overview

```
Sequence name:   Content Machine Setup – Welcome
Trigger:         Email submitted on cutthecode.co.uk/setup (ActiveCampaign form u=3, f=3)
Goal:            Get the guide opened and the prompts used, then show the machine's output
Length:          3 emails
Timing:          Immediately → Day 2 → Day 4
Exit conditions: Unsubscribes. Anyone who signs up again from /setup should not restart the sequence.
```

**Merge fields:** the form only collects an email address, so these emails use no first name. Adding `%FIRSTNAME%` would just show the fallback for everyone.

**Sender:** Cut The Code. The page is written in the first person ("my entire setup"), so the emails are too.

---

## Email 1: Deliver the guide

**Send:** Immediately after signup

**Subject:** Your Claude content machine setup (PDF inside)
**Preview:** The 10-page guide and 6 copy-paste prompts behind every Cut The Code video.

**Body:**

> Here's the guide you asked for.
>
> **[Download The Claude Content Machine Setup (PDF)]**
>
> It's the full setup I use to make short-form videos with Claude. One Claude skill writes, voices, animates, captions and posts each video to Instagram, TikTok and YouTube Shorts.
>
> Inside the 10 pages:
>
> - The 8-step pipeline, from idea to posted video
> - Every tool I use and what it really costs
> - 6 copy-paste prompts to make Claude build your own
>
> If you only have five minutes today, read the 8-step pipeline first. The rest of the guide makes more sense once you've seen the whole flow.
>
> I'll also send you prompts, builds and offers from Cut The Code. You can unsubscribe in one click at the bottom of any email.
>
> Cut The Code

**CTA:** Download the setup guide → `https://www.cutthecode.co.uk/content-machine-setup.pdf`
**Words:** ~120 (transactional length)

---

## Email 2: Use the prompts

**Send:** Day 2, 48 hours after Email 1, at the subscriber's local morning if your plan supports it

**Subject:** Paste these 6 prompts into Claude
**Preview:** They're in the guide you downloaded. Here's how to start building your own content machine with them.

**Body:**

> The most useful part of the setup guide is near the end: the 6 copy-paste prompts.
>
> They're there to make Claude build your own version of the machine.
>
> Here's a simple way to start:
>
> 1. Open the guide and go to the 6 prompts.
> 2. Copy the first prompt into Claude.
> 3. Work through the rest in order.
>
> Keep the tools and costs section open while you do it. It lists every tool in the pipeline and what each one really costs, so you know what you're signing up for before you build.
>
> If you've lost the PDF, it's here:
>
> **[Open the setup guide]**
>
> Cut The Code

**CTA:** Open the setup guide → `https://www.cutthecode.co.uk/content-machine-setup.pdf`
**Words:** ~140

---

## Email 3: See what it makes, plus three more free tools

**Send:** Day 4, 48 hours after Email 2

**Subject:** Every video on our page was made by this machine
**Preview:** Nobody edited them. Watch a few, then grab three more free Claude tools.

**Body:**

> The guide you downloaded describes the real system behind every Cut The Code video. Every video on our page was made by this machine, and nobody edited them.
>
> The quickest way to judge the setup is to watch what it produces:
>
> **[Watch the videos on TikTok]**
>
> They're on [Instagram](https://www.instagram.com/cuthecode) and [YouTube](https://www.youtube.com/@cutthecodeuk) too.
>
> While you're building, these three free downloads pair well with the guide. None of them need an email.
>
> - **[The AI business blueprint](https://www.cutthecode.co.uk/dl/091352ce9dbe/AI-Business-Blueprint.pdf):** the 6-agent map, with a starter prompt for every agent.
> - **[The Claude limit checklist](https://www.cutthecode.co.uk/dl/9a14b77b2776/Stop-Hitting-Your-Claude-Limit.pdf):** 9 fixes from Anthropic's own Claude Code docs, on one page.
> - **[The business brief template](https://www.cutthecode.co.uk/dl/602ed87eea15/Claude-Business-Brief-Template.pdf):** a one-page project file for your Claude project knowledge. There's an [editable .md version](https://www.cutthecode.co.uk/dl/602ed87eea15/Claude-Business-Brief-Template.md) too.
>
> Cut The Code
>
> *Cut The Code is independent and not affiliated with Anthropic. Claude is a trademark of Anthropic.*

**CTA:** Watch the videos → `https://www.tiktok.com/@cutthecode`
**Secondary links:** Instagram, YouTube, three free PDFs (text links)
**Words:** ~170

---

## Claim check

Every claim in the three emails maps to a line on `setup.html`:

| Claim in emails | Source on setup.html |
|---|---|
| 10-page guide + 6 copy-paste prompts | line 138, line 153 |
| One Claude skill writes, voices, animates, captions and posts to Instagram, TikTok, YouTube Shorts | line 140 |
| The real system behind every Cut The Code video | line 140 |
| 8-step pipeline, idea → posted video | line 142 |
| Every tool and what it really costs | line 142–143 |
| 6 prompts to make Claude build your own | line 144 |
| Every video on our page was made by this machine. Nobody edited them. | line 146 |
| Emails with prompts, builds and offers; one-click unsubscribe | line 167 |
| AI business blueprint: 6-agent map, starter prompt per agent, no email needed | line 164 |
| Claude limit checklist: 9 fixes from Anthropic's Claude Code docs, one page | line 165 |
| Business brief template: one-page project file for Claude project knowledge, editable .md | line 166 |
| Social handles (@cutthecode TikTok, @cuthecode Instagram, @cutthecodeuk YouTube) | lines 184–186 |
| Not affiliated with Anthropic; Claude is a trademark of Anthropic | line 189 |

**Deliberately left out** because the page doesn't support them:
- What the guide's individual prompts say, which section each sits in, or what any tool costs. The page doesn't give the PDF's contents beyond the summary. ("Near the end" for the prompts in Email 2 is an assumption. Check it against the PDF and edit if it's wrong.)
- Any paid offer or price. The page mentions "offers" and links to `/#pricing`, but it doesn't say what's sold. When you have an offer, add it as Email 4 (Day 7+) instead of putting it into these three.
- Results, follower counts, views or time saved. The page makes no such claims.

---

## Before you switch it on

1. **Confirm the PDF URL.** The page downloads `content-machine-setup.pdf` from a relative path, so the emails assume `https://www.cutthecode.co.uk/content-machine-setup.pdf`. Click it from a real inbox.
2. **Check the Instagram handle.** The page links `instagram.com/cuthecode` (missing a "t"), while TikTok uses `@cutthecode`. Both emails copy the page exactly. If the Instagram handle is a typo, fix it on the page too.
3. **Add UTM tags** to every link (`utm_source=activecampaign&utm_medium=email&utm_campaign=setup-welcome&utm_content=e1` etc.) so clicks show up per email.
4. **Plain styling.** Short paragraphs and one button per email. Most of these will be read on a phone.

## Metrics plan

| Metric | Target | Notes |
|---|---|---|
| Email 1 PDF click rate | As high as possible, at least 30% | This is a delivery email, so it should be the highest-clicked email. Low clicks usually mean the download didn't work or the email landed in spam. |
| Email 2 & 3 click rate | 2–5% | Standard benchmark for nurture emails |
| Unsubscribe rate | Under 0.5% per email | Above that, look at Email 3's length or the send timing |
| Open rate | Trend only | Apple Mail Privacy Protection inflates it. Compare emails against each other, not against industry numbers. |
| Spam complaints | Under 0.1% | Watch Email 1 closely. People who signed up only for the PDF may not remember the consent line. |

**First test to run:** the Email 3 subject line. Test the proof line ("Every video on our page was made by this machine") against a more direct one ("Watch what the content machine makes").
