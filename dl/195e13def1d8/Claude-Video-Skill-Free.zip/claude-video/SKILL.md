---
name: claude-video
description: Make short vertical videos (TikTok, Instagram Reels, YouTube Shorts, 1080x1920) in a clean "UI explainer" style, with no video editor. Claude writes the script, designs every scene as an HTML page with a render(t) function, adds word-by-word captions timed to a voiceover, renders frames with Playwright and stitches them with ffmpeg, with sound effects and optional ducked music. Use whenever the user asks for a video, reel, short or TikTok, wants a script turned into a video, wants "another one in the same style", or says something like "make me a 20-second video about X", even if they don't say "skill".
---

# Claude video (free starter skill, by Cut The Code)

This skill turns an idea into a finished 1080×1920 MP4. Nobody opens an editor: each video is a single HTML page whose `render(t)` function draws the frame at time `t`. Playwright screenshots it 30 times a second, ffmpeg turns the frames into a video and mixes the voice, sound effects and music.

Read `references/style-guide.md` before designing scenes. It has the colours, motion rules, scene recipes and the bugs we already hit so you don't.

## Rules that make the videos work
- **Hook in the first 2 seconds.** Frame 0 already shows tension: the focal object plus a "problem" sticker. Never fade in from an empty screen. Frame 0 is also the cover image.
- **One idea per sentence, one scene per sentence.** The picture changes every 1–1.5 seconds, but each scene has one focal card, so it never looks cluttered.
- **Everything lands on a spoken word.** Stickers, highlights, chips and counters are anchored to the timestamp of the word that names them.
- **A natural voice.** Write normal sentences. No "..." for drama, no over-acted emphasis.
- **Music sits under the voice** (about 17% volume, ducked), never competing with it.
- **Honest claims.** No income promises. "Businesses typically pay £150/month for this" is fine; "you'll make £3k" is not. Don't use other creators' footage, faces or logos.
- **Show the user a few still frames before the full render,** and the finished MP4 before anything gets posted.

## Pipeline

### 0. Set up the project (first run only)
Check the tools exist: `node -v`, `ffmpeg -version`, `python3 --version`. If Playwright is missing, run `npm i playwright && npx playwright install chromium` inside the project folder (or once globally). Make a project folder such as `~/videos/<slug>/` and work there. `<skill>` below means the folder this SKILL.md is in.

### 1. Script
- Length: about 50–60 words for a 20s video, 90–120 words for 30–40s.
- Structure: **hook / promise → "here's how" → 2–5 steps, one sentence each → proof or result → call to action** (e.g. "Follow for more" or "Comment WORD and I'll send you …").
- Show the script to the user and wait for an OK before making audio.

### 2. Voice → `vo.wav` + `words.json`
You need one audio file of the whole script read in a single take. Ask the user which they prefer:
- **Their own voice:** record on a phone (voice memo), send the file.
- **Any text-to-speech tool** they already use (ElevenLabs, OpenAI TTS, etc.), downloaded as MP3/WAV.
- **Quick test voice, free:** on a Mac, `say -v Daniel -o take.aiff "<script>"`; on Linux, `espeak-ng -w take.wav "<script>"` if installed. Fine for testing, robotic for posting.

Then run:
```
bash <skill>/scripts/prep_voice.sh take.mp3 <project_dir>
```
It trims silence, speeds the take up 4%, normalises loudness to −14 LUFS, and writes `vo.wav` and `words.json` (word-level timings from faster-whisper, which it installs on first use; the model downloads once from huggingface.co). It prints the words with their times.

Fix `words.json` by hand where the transcription is wrong: brand names ("clawed" → "Claude"), numbers ("150" → "£150"). Anchor scenes on what's actually in the file.

### 3. Scenes → `scene.html`
- Copy `<skill>/assets/scene-template.html` to `<project_dir>/scene.html`.
- Make the sound effects once: `python3 <skill>/scripts/make_sfx.py <project_dir>/sfx` (six synthesised UI sounds: click, pop, hit, whoosh, success, ding; no licence needed).
- The template is a complete working example (a "website in 10 minutes" video; `example/words.json` is its timing file). **Keep its engine:** `setup()`, `render(t)`, the caption system, light/dark backgrounds, pixel-dissolve transition, and the `popIn`, `stick`, `tagIn` and `at()` helpers plus the `SFX` list. **Rewrite** the scene markup and the per-scene blocks for the new script.
- In `setup()`, define the `SC` list `[id, start, end, 'L'|'D']` (light or dark scene), anchoring each scene start on a spoken word with `at('word', n)` (n = which occurrence).
- Anchor every sticker, highlight, chip and counter on its word. Add a matching `SFX` entry `[time, 'pop'|'hit'|'whoosh'|'success'|'click'|'ding', volume]` for each.
- Update the `ACC` set (accent words: nouns, numbers, the CTA keyword) for the new script.
- Change the end card to the user's own name/website and CTA.

### 4. Check, then render
- Render check frames first:
  `node <skill>/scripts/render.js <project_dir> --stills 0 1 <one time per scene>`
  This writes `still-<t>.png` files. **Look at them** (tile them into one contact sheet with ffmpeg if there are many). Check: frame 0 isn't empty, nothing overlaps, hidden scenes don't bleed through, no single orphan caption word, all content inside the safe area (y 520–1500).
- Fix, then render the full video:
  `node <skill>/scripts/render.js <project_dir> --out video.mp4`
- **Music (optional):** `--music track.mp3 --music-start 15` mixes a track at ~17% under the voice with sidechain ducking, starting 15s in (skip the intro). Only use music you have the rights to (your own, a royalty-free library, or a platform's commercial library). For TikTok/Reels you can also render without music and add a trending sound in the app.
- A 20-second video is about 600 frames; expect a few minutes on a laptop.

### 5. Deliver
Give the user the MP4 path, a one-line summary per scene, and posting notes (which version for which platform, suggested caption with the CTA). Ask what to change. Keep the structure unless they say otherwise.

## Quick test (no voice needed)
To see the engine work before making anything: copy `assets/scene-template.html` to a folder as `scene.html`, copy `example/words.json` next to it, and run `node <skill>/scripts/render.js <folder> --stills 0 6 12 20`. You'll get four frames of the example video.

## Troubleshooting
- `Cannot find module 'playwright'`: run `npm i playwright && npx playwright install chromium` in the project folder, or `npm i -g playwright` and set `NODE_PATH=$(npm root -g)`.
- Fonts look wrong: the template loads Inter and JetBrains Mono from Google Fonts, so the machine needs internet while rendering.
- `faster-whisper` won't install: use Python 3.9–3.12 and `pip install faster-whisper` manually.
- Captions out of sync: the words in `words.json` drive everything. Re-check the times there, not in the HTML.
