#!/usr/bin/env bash
# Prepare a downloaded voiceover take and transcribe it with word timings.
# Usage: prep_voice.sh <take.mp3> <project_dir> [tempo=1.04]
# Produces <project_dir>/vo.wav and <project_dir>/words.json
set -euo pipefail
IN="$1"; DIR="$2"; TEMPO="${3:-1.04}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$DIR"
ffmpeg -v error -y -i "$IN" -af "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,atempo=${TEMPO},loudnorm=I=-14:TP=-1.5" -ar 44100 -ac 1 "$DIR/vo.wav"
ffmpeg -v error -y -i "$DIR/vo.wav" -ac 1 -ar 16000 "$DIR/vo16.wav"
python3 -c "import faster_whisper" 2>/dev/null || pip install -q faster-whisper
python3 -I "$HERE/transcribe.py" "$DIR/vo16.wav" "$DIR/words.json"
rm -f "$DIR/vo16.wav"
python3 -c "import json,sys;w=json.load(open(sys.argv[1]));print(' '.join(f'[{x[0]}]{x[2]}' for x in w))" "$DIR/words.json"
