#!/usr/bin/env python3
"""Synthesise the six UI sound effects the scene template uses, from scratch.

Usage:  python3 make_sfx.py <out_dir>
Writes click.wav, pop.wav, hit.wav, whoosh.wav, success.wav and ding.wav.

Every sound is generated with maths (sine waves, noise, envelopes), so there is
no licence to worry about: they're yours. Prefer your own sound pack? Drop WAV
files with the same six names into <project_dir>/sfx/ and they'll be used instead.
Standard library only, no installs needed.
"""
import math, random, struct, sys, wave, os

SR = 44100
rnd = random.Random(7)


def save(path, xs):
    peak = max(1e-9, max(abs(x) for x in xs))
    g = 0.89 / peak
    with wave.open(path, "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, x * g)) * 32767)) for x in xs))


def env(i, n, attack=0.002, decay=8.0):
    t = i / SR
    a = min(1.0, t / attack) if attack > 0 else 1.0
    return a * math.exp(-decay * t / (n / SR))


def click():
    n = int(SR * 0.03)
    return [(rnd.uniform(-1, 1) * 0.6 + math.sin(2 * math.pi * 3200 * i / SR)) * env(i, n, 0.0005, 9) for i in range(n)]


def pop():
    n = int(SR * 0.12); out = []; ph = 0.0
    for i in range(n):
        f = 900 - 600 * (i / n)            # quick downward blip
        ph += 2 * math.pi * f / SR
        out.append(math.sin(ph) * env(i, n, 0.001, 6))
    return out


def hit():
    n = int(SR * 0.25); out = []; ph = 0.0
    for i in range(n):
        f = 140 * math.exp(-6 * i / n) + 50  # kick-style thump
        ph += 2 * math.pi * f / SR
        noise = rnd.uniform(-1, 1) * math.exp(-40 * i / n) * 0.5
        out.append((math.sin(ph) + noise) * env(i, n, 0.001, 5))
    return out


def whoosh():
    n = int(SR * 0.4); out = []; lp = 0.0
    for i in range(n):
        p = i / n
        cut = 0.02 + 0.25 * math.sin(math.pi * p)   # filter opens then closes
        lp += cut * (rnd.uniform(-1, 1) - lp)
        out.append(lp * math.sin(math.pi * p) ** 1.5)
    return out


def tone(freqs, dur, decay=5.0, start=0.0):
    n = int(SR * dur); out = [0.0] * n
    for k, f in enumerate(freqs):
        off = int(SR * start * k)
        for i in range(n - off):
            e = env(i, n - off, 0.004, decay)
            out[off + i] += (math.sin(2 * math.pi * f * i / SR) + 0.3 * math.sin(4 * math.pi * f * i / SR)) * e
    return out


def success():
    return tone([784, 988, 1319], 0.6, decay=4.5, start=0.07)   # G5-B5-E6 arpeggio


def ding():
    return tone([1568, 2349], 0.5, decay=4.0)                   # bell-ish


if __name__ == "__main__":
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "sfx"
    os.makedirs(out_dir, exist_ok=True)
    for name, fn in [("click", click), ("pop", pop), ("hit", hit), ("whoosh", whoosh), ("success", success), ("ding", ding)]:
        save(os.path.join(out_dir, name + ".wav"), fn())
    print("wrote 6 sounds to", out_dir)
