import sys,json,wave
import numpy as np
from faster_whisper import WhisperModel
w=wave.open(sys.argv[1]); a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768.0
m=WhisperModel("base.en",device="cpu",compute_type="int8")
segs,_=m.transcribe(a,word_timestamps=True)
words=[]
for s in segs:
    for x in s.words: words.append([round(x.start,2),round(x.end,2),x.word.strip()])
json.dump(words,open(sys.argv[2],"w"))
print(len(words),"words")
