# Video style guide

The style is the "UI explainer": clean product-UI motion graphics that illustrate every sentence of a natural voiceover. It's the style Cut The Code uses for its own videos. This file is the detail behind SKILL.md. Read it before designing scenes.

## Contents
1. Brand tokens
2. The look: light and dark scenes
3. Captions
4. UI components
5. Stickers
6. Motion rules
7. Transitions
8. Sound
9. Scene recipes
10. Known pitfalls (bugs we've hit)

## 1. Brand tokens
These are the default (Cut The Code) colours. Swap them for your own brand: change the CSS variables at the top of `scene-template.html`.

| Token | Value | Use |
|---|---|---|
| Cobalt | `#2340FF` → `#5B74FF` gradient | accent on light scenes, buttons, stickers |
| Ink | `#0B1033` | text on light, dark-scene base |
| Paper | `#F5F6FF` / light bg `#F3F4FC` | light scenes, text on dark |
| Marker | `#FFE14D` | accent on dark scenes, yellow stickers, one highlight max per moment |
| Red / Green | `#FF4D5E` / `#18B46B` | problem ✕ / fixed ✓ only |

Fonts: **Inter** 800–900 for captions and UI. **JetBrains Mono** for code, labels and the `</>` mark. Anton is for carousels, not these videos.

Logo: the template uses a simple `</>` text mark on a cobalt tile. Replace it with your own. Never use other companies' logos (Anthropic, Google, etc.); use a generic icon instead, e.g. a map-pin for "Google listing".

**Handle on screen:** if your @handle differs per platform, show your website instead: it's the same everywhere.

## 2. The look
- **Light scene:** `#F3F4FC` with a faint cobalt pixel grid (60px squares, 2–7% alpha, slow twinkle) and a soft radial cobalt glow behind the focal card.
- **Dark scene:** radial `#16206A` → `#070A22`, drifting square particles (cobalt, periwinkle, about 12% yellow) rising slowly, plus a faint pixel grid.
- Alternate light and dark to reset attention: dark for the "how it works" roadmap, the build moment and the big number.
- Frame is 1080×1920. Keep content between y≈520 and y≈1500. The top 240px and bottom 400px are covered by TikTok and Instagram UI.

## 3. Captions
- Top-centre at y=250, Inter 800, 66px, tracking −1.5px, at most 2 lines, `text-wrap: balance`.
- **Words appear only as they're spoken.** Each word fades from 15% to 100% opacity, from 8px blur to sharp, rising 10px, over about 0.2s starting 0.12s before the word. Upcoming words stay hidden, so the line isn't given away.
- Groups break at punctuation or after 6 words.
- Accent words use a cobalt gradient on light scenes and solid yellow on dark ones, with a small scale pop (1.12 → 1). Keep an `ACC` set of the words that matter: nouns, numbers, the CTA keyword.
- Show the CTA keyword in capitals ("CODE").
- Hide captions on the end card.

## 4. UI components (all in the template)
- `.card`: white, radius 30, soft cobalt-tinted shadow, a window bar with three dots and a label ("Page plan", "Comments").
- `.tag`: step pill at y=520 ("STEP 2 · PLAN") with a numbered cobalt chip. `.tag.dk` is for dark scenes.
- Browser mock (old ugly site vs new site, swapped with a scan line), phone mock, Google-listing card with highlightable rows, brief card with flying chips, wireframe blocks, a checklist whose ✕ rows flip to ✓, a message bubble that types itself, a big number counter, a comment box typing the keyword, a DM with a PDF chip, and the end card (pulsing ring, logo, "Follow for a Claude tip every day", CTA pill).

Use real, specific details, such as a believable business name, rating and review quote. Specifics look like proof; generic placeholders look like an ad.

## 5. Stickers
Tilted pills (±4–8°), uppercase Inter 900, a 5px white border (an ink border on yellow ones). They slam in from scale 1.6 → 1 with an overshoot, exactly on the payoff word.
- Cobalt: positive outcomes ("BRAND NEW", "0 ISSUES LEFT")
- Yellow: numbers and time ("~10 MIN", "MOBILE-READY", "PER CLIENT")
- Red: the problem in the hook ("BUILT IN 2009")
- One or two per scene at most.

## 6. Motion rules
- **Frame 0 must already show tension.** The focal object and a problem sticker are visible at t=0; nothing fades in from empty. Frame 0 is the cover image and the scroll-stopper.
- Every on-screen change is tied to the timestamp of a spoken word, never to even spacing.
- Elements enter with a spring: rise about 40px, scale 0.85 → 1, an overshoot ease, about 0.38s.
- Each scene slowly zooms 1.00 → 1.025 so nothing is ever static.
- The image changes at least every 1–1.5s: chips, rows, stickers, typing.

## 7. Transitions
- **Light ↔ dark:** a pixel dissolve. 12×21 cells fill with the incoming background in random order over 0.26s (about 18% of cells use an accent colour), the scene switches, then the cells clear over 0.3s.
- **Light → light:** the new scene springs in (scale 0.97 → 1). No dissolve.

## 8. Sound
- **Voice:** 100%, normalised to −14 LUFS, sped up 4%.
- **Music:** about 17% volume, sidechain-ducked under the voice. It starts at the track's groove (15s into the deep-house preview), not the intro.
- **SFX** (generated by `scripts/make_sfx.py` into `<project_dir>/sfx/`, or your own WAVs with the same names), about 55% × each event's volume:
  - `hit` + `pop` at t=0
  - `whoosh` 0.25s before every scene cut
  - `pop` for each card or chip
  - `hit` for each sticker
  - `success` for each ✓
  - `click` per typed letter of the keyword
  - `ding` on the DM arriving
- **On TikTok,** post a copy without baked-in music and pick the track in the publish card, so the post registers the trending sound.

## 9. Scene recipes (map one per sentence)
| Sentence type | Visual |
|---|---|
| Hook / promise | Bad "before" object with a red sticker → scan-line transform into the "after" + 1–2 stickers |
| "Here's how" | Dark roadmap: numbered rows (01 READ, 02 PLAN…) popping in, plus a yellow sticker |
| "It reads/finds X" | Source card with rows that light up on each spoken item; chips fly into a "brief" card |
| "It plans/organises" | Wireframe blocks dropping in one per beat |
| "It builds" | Dark: finished artefact + scrolling code behind; device mock slides in on the key word |
| "It checks/fixes" | Checklist of red ✕ problems flipping to green ✓ on "fixes", then "0 ISSUES LEFT" |
| "It writes/sends" | Message bubble typing itself in time with the sentence, then a "READY TO SEND" sticker |
| Money / proof | Dark big number counting up on the spoken number, plus supporting chips |
| CTA | Comment box typing the keyword letter by letter → DM with the lead magnet file |
| End | Pulsing logo ring, "Follow for a Claude tip every day", CTA pill (about 2.2s after the voice ends) |

## 10. Known pitfalls
- **Repeated anchor words.** `at('local')` returns the first occurrence. If a word is spoken twice ("a local business" … "Local businesses"), use `at('local',2)`. Check every anchor against the transcript.
- **Transcription errors.** Whisper hears "Claude" as "clawed" and writes numbers as digits ("10", "150"). Fix words.json before rendering, and anchor on what's actually in the file.
- **Hidden scenes bleeding through.** Set `visibility:hidden` as well as `opacity:0` on inactive scenes. Avoid `background-clip:text` gradients and `backdrop-filter` on big elements, because they can show through hidden layers in screenshots.
- **First frame empty.** Never fade the focal card in from opacity 0 at t=0.
- **Orphan caption words.** Keep chunks to at most 3 words in segment-synced captions; merge a trailing single word into the previous chunk.
