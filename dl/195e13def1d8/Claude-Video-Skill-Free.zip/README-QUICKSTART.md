# Claude video skill (free) — quickstart

The Claude skill behind Cut The Code's videos, starter version. You ask Claude Code for a video; it writes the script, designs the scenes, times the captions to your voiceover and renders a vertical MP4 (1080×1920) for TikTok, Reels and Shorts. No video editor.

## 3 steps

1. **Install Claude Code** (needs a paid Claude plan): follow https://docs.claude.com/en/docs/claude-code/setup, then run `claude` in a terminal once to log in.
2. **Put this folder in your skills folder.** Move the whole `claude-video` folder to `~/.claude/skills/`, so you end up with `~/.claude/skills/claude-video/SKILL.md`.
   - Mac/Linux: `mkdir -p ~/.claude/skills && mv claude-video ~/.claude/skills/`
   - Windows: `%USERPROFILE%\.claude\skills\claude-video\`
3. **Ask for a video.** Open a terminal in an empty folder, run `claude`, and say:
   > make me a 20-second video about X

   Claude will show you the script, ask for a voice file (your phone voice memo or any text-to-speech tool), show you a few still frames, then render `video.mp4`.

## Requirements
| Tool | Why | Install |
|---|---|---|
| Node.js 18+ | runs the renderer | https://nodejs.org |
| Playwright + Chromium | draws the frames | `npm i playwright && npx playwright install chromium` (Claude can do this for you) |
| ffmpeg | turns frames + audio into MP4 | Mac `brew install ffmpeg` · Windows `winget install ffmpeg` · Linux `sudo apt install ffmpeg` |
| Python 3.9–3.12 | word-timed captions (faster-whisper, installed on first use) | https://python.org |

An internet connection is needed while rendering (fonts load from Google Fonts; the caption model downloads once).

## Try it in 1 minute (no voice needed)
```
mkdir test && cp ~/.claude/skills/claude-video/assets/scene-template.html test/scene.html
cp ~/.claude/skills/claude-video/example/words.json test/
node ~/.claude/skills/claude-video/scripts/render.js test --stills 0 6 12 20
```
You'll get four PNG frames of the example video in `test/`.

## What's inside
- `SKILL.md`: the workflow Claude follows (script → voice → scenes → check frames → render).
- `references/style-guide.md`: colours, captions, motion rules, scene recipes and known bugs.
- `assets/scene-template.html`: a complete example video as one HTML page with a `render(t)` function.
- `scripts/render.js`: Playwright frames + ffmpeg (voice, sound effects, optional ducked music).
- `scripts/prep_voice.sh` + `transcribe.py`: clean up your voice file and get word timings.
- `scripts/make_sfx.py`: generates 6 UI sound effects from scratch (no licence issues). Prefer your own? Put `click/pop/hit/whoosh/success/ding.wav` in your project's `sfx/` folder.
- `example/words.json`: timings for the example video.

## Good to know
- Music isn't included. Use tracks you have the rights to, or add a trending sound inside TikTok/Instagram when you post.
- Change the colours, logo and end card in the template to your own brand.
- This is the free starter version. It's free to use for your own and your clients' videos; please don't resell the skill itself.

Made by Cut The Code · cutthecode.co.uk · Independent, not affiliated with Anthropic. Claude is a trademark of Anthropic.
