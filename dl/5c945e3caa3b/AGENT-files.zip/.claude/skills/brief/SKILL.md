---
name: brief
description: Writes a one-page research brief on a person or business before a call or meeting, with five questions to ask. Use when I type /brief or ask for a brief before a call.
---
# Brief before a call

I'll give you a business (and sometimes a person's public role) and what the call is about.

1. Search the web. Open at least three sources, preferring the company's own site and recent news.
2. Write a one-page brief and save it as briefs/<name>-<YYYY-MM-DD>.md with:
   - **In one line:** what they do and for whom.
   - **What's new:** the last 3 to 6 months, with dates.
   - **How they make money**, if it's public.
   - **What they might need from me**, based on what the call is about.
   - **Five questions to ask**, specific to them, not generic.
   - **Sources:** every link you used.
3. Only public, work-related information. No home addresses, family or personal social media.
4. If something isn't clear from the sources, write "not found" rather than guessing.
