# SEO fixes for index.html (homepage): top 3 for Google

Audited: `index.html` (static source, 399 lines). Not checked, because they aren't in this folder: robots.txt, sitemap.xml, Search Console, live speed data. Since the site is about a week old ("Day 5"), first confirm the homepage is submitted and indexed in Search Console. None of the fixes below matter until it is.

What's already fine: the canonical (line 8), meta description (line 7, 157 chars), viewport, `lang="en-GB"`, a single H1, image width/height attributes, lazy loading below the fold, and the OG tags.

---

## 1. Rewrite the title tag so it leads with a searchable phrase

**Impact: High · Effort: 2 minutes**

**Line 6:**
```html
<title>Cut The Code | A business run by 6 AI employees. Learn to build yours with Claude.</title>
```

**Problem**
- At 82 characters, Google cuts it off at about 60, around "...6 AI employees. Learn to…"
- It opens with the brand name. For a new brand, nobody searches "Cut The Code" yet, and "cut the code" is a generic phrase anyway.
- The rest is a hook ("a business run by 6 AI employees"), not something people type into Google. The only searchable word is "Claude", and it sits at the very end, past the cut-off.

**Fix** (53 chars, query first, brand last):
```html
<title>Build Websites & AI Agents with Claude | Cut The Code</title>
```
The exact phrase is a suggestion. Once Search Console shows which queries already bring impressions, use the strongest one (for example "Claude website prompts" or "Claude AI agents no code"). Keep the hook in `og:title` (line 12), where it works well for social shares.

---

## 2. Match the H1 to the title by putting the keyword in the H1

**Impact: High · Effort: 2 minutes**

**Line 195:**
```html
<h1>This business is run by <mark>6 AI employees.</mark><span class="then">We teach you to build the same with Claude.</span></h1>
```

**Problem**
The H1 is the page's main topic signal. "Build the same" doesn't say what is being built, so the H1 and title don't name a shared topic. The intro (line 196) is mostly agent names (Scout, Scriptwriter...), so the first 100 words never say "websites" or "AI agents" plainly.

**Fix:** keep the hook and make the subline in the H1 specific:
```html
<h1>This business is run by <mark>6 AI employees.</mark><span class="then">Learn to build websites and AI agents with Claude. No coding.</span></h1>
```
Also, in line 196, change "you can build your own without writing code" to "you can build your own AI agents with Claude, without writing code".

---

## 3. Add Organization + WebSite structured data

**Impact: Medium-High · Effort: 10 minutes**

**Where it goes:** the file contains no `application/ld+json` at all. This is the raw source, so it's a real absence, not a crawler blind spot. Insert the block after **line 18**:
```html
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```

**Problem**
Google can't confidently link the name "Cut The Code", the domain, and your TikTok/Instagram/YouTube profiles. That affects the site name shown in results, brand-query results and any future knowledge panel. It matters more here because the brand name is a common phrase.

**Fix:**
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://www.cutthecode.co.uk/#org",
      "name": "Cut The Code",
      "url": "https://www.cutthecode.co.uk/",
      "logo": "https://www.cutthecode.co.uk/apple-touch-icon.png",
      "email": "hello@cutthecode.co.uk",
      "sameAs": [
        "https://www.tiktok.com/@cutthecode",
        "https://www.instagram.com/cuthecode",
        "https://www.youtube.com/@cutthecodeuk"
      ]
    },
    {
      "@type": "WebSite",
      "@id": "https://www.cutthecode.co.uk/#website",
      "name": "Cut The Code",
      "url": "https://www.cutthecode.co.uk/",
      "publisher": { "@id": "https://www.cutthecode.co.uk/#org" }
    }
  ]
}
</script>
```
The logo needs to be at least 112×112px. The header image `/img/ctc-head.png` is only 36px, so use the apple-touch-icon (usually 180px) or a larger square logo. Check the result with Google's Rich Results Test after deploying.

---

## Also noticed (lower priority)

> (Removed by Cut The Code: a "worth checking" note about our Instagram link. Our handle really is @cuthecode, so the link is correct.)
- **Two URLs for the privacy page:** line 252 links `privacy.html`, but the footer (line 368) links `/privacy`. Use one everywhere (`/privacy`).
- **Fonts block rendering:** line 20 loads 8 font weights from Google Fonts before the page paints. Cut Inter to the 3–4 weights you use, or self-host them, to help LCP on mobile.
- **Mixed relative/absolute download links:** line 248 uses `/dl/...` while lines 250–251 use `dl/...`. Both work on `/`, but make them all start with `/` so they don't break if this markup gets reused on another page.
